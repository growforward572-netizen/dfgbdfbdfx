# Human Behavior Layer

The extension no longer drives YouTube with `element.click()` and `location.href`.
Every action now goes through `scripts/human.js`, and `scripts/stealth.js` cleans up
the automation fingerprints before YouTube boots.

Goal: a session that looks like a person on a mouse and keyboard, so accounts warm
up instead of getting flagged.

## What changed

### `scripts/stealth.js` (MAIN world, `document_start`)

Runs in the page's own JS context before YouTube starts, so the values are already
patched when its checks run.

- `navigator.webdriver` → `false`
- deletes `cdc_*` / Selenium / Playwright / Nightmare leftovers
- `navigator.languages`, `platform`, `vendor`, `pdfViewerEnabled`, `maxTouchPoints`
- `hardwareConcurrency` / `deviceMemory` raised to normal desktop values
- `navigator.connection` stub when missing
- `Notification.permission` `denied` → `default`
- `Permissions.query()` reports `prompt` for notifications
- WebGL vendor/renderer spoofed **only** when the real one is SwiftShader/llvmpipe
- `outerWidth` / `outerHeight` / `screenX` / `screenY` filled in when `0`
- `chrome.runtime`, `chrome.app`, `chrome.csi`, `chrome.loadTimes` stubs
- `document.hasFocus()` true while the tab is visible

### `scripts/human.js` (isolated world)

- **Pointer**: curved bezier travel with easing, hand tremor, overshoot, hover
  dwell, and a ~7% miss-then-correct before clicking. Never clicks the exact center.
- **Clicks**: `pointerover` → `pointerdown` → 35-120 ms hold → `pointerup` → `click`,
  with real coordinates.
- **Typing**: 62-118 WPM, per-character jitter, thinking pauses, punctuation
  pauses, ~2% typos with backspace correction. Used for search and comments.
- **Scrolling**: wheel events plus eased momentum, multi-burst, occasional
  overshoot and scroll-back.
- **Navigation**: clicks the real link or logo so YouTube does an in-page SPA
  transition instead of a hard reload. Search uses the actual search box.
- **Watching**: random pause/resume, seek-back, volume drift, occasional 1.25x/1.5x,
  occasional fullscreen, hovering the player, scrolling to comments and back.
- **Idle**: micro mouse movement every 9-26 s so the cursor is never frozen.
- **Breaks**: every 35-95 minutes the video pauses for 45 s-3.5 min.
- **Warm-up**: engagement chances start at 60% and reach 100% after ~10 sessions.
- **Feed**: occasionally opens a card menu and clicks "Not interested".

### `scripts/content.js`

All click/scroll/navigation/typing call sites were routed through `HUMAN.*`.
Watch time now varies like a real viewer: 12% bail early, most leave part-way,
13% watch most of it, 5% watch to the end.

## Settings

Popup → Tune → **Human behavior** and **Human pace**.

| Pace | Effect |
| --- | --- |
| Brisk | 0.6x dwell, fastest |
| Normal | 1x |
| Relaxed | 1.5x |
| Very slow | 1.9x |

Turning **Human behavior** off makes every action a plain `click()` / `scrollBy()`
again, for speed.

## Notes

- `world: "MAIN"` needs Chrome 111+ (`minimum_chrome_version` is set).
- Synthetic events are still untrusted. The stealth layer plus the behavior
  patterns are what make the difference; nothing here fakes `isTrusted`.
- If `human.js` fails to load, `content.js` falls back to a no-op shim and the
  extension keeps working.
