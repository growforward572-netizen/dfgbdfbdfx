# Installation & Testing Guide

## 🚀 Installation Steps

### 1. Load Extension in Chrome

1. **Open Chrome Extensions Page**
   ```
   chrome://extensions/
   ```
   Or: Menu → More Tools → Extensions

2. **Enable Developer Mode**
   - Toggle the "Developer mode" switch in the top-right corner

3. **Load Unpacked Extension**
   ```
   Click "Load unpacked" button
   → Navigate to: C:\Users\Computer House\.gemini\antigravity\scratch\youtube-ai-assistant
   → Click "Select Folder"
   ```

4. **Verify Installation**
   - Extension should appear in the list
   - Icon should appear in Chrome toolbar
   - If not visible, click the puzzle piece icon to pin it

### 2. Initial Setup

1. **Open Extension Popup**
   - Click the extension icon

2. **Configure API Key** (if needed)
   - Click ⚙️ Settings
   - Enter your NVIDIA API key in "API Key" field
   - The extension comes with a default key, but you can use your own

3. **Test Brain Connection** (Optional)
   - In Settings panel
   - Click "🧪 Test Brain Connection"
   - Should see "Brain connected successfully!"

## 🧪 Testing Custom Categories

### Test 1: Add Custom Category WITH Keywords

1. Open Settings (⚙️)
2. Scroll to "🏷️ Custom Categories"
3. Enter:
   ```
   Category Name: Cooking
   Keywords: recipe, chef, food, cooking, kitchen, baking
   ```
4. Click "➕ Add Category"
5. **Expected Result:**
   - Success message: "Category 'Cooking' added!"
   - Category appears in list below
   - Category appears in dropdown with 🏷️ icon

### Test 2: Add Custom Category WITHOUT Keywords

1. In Custom Categories section:
   ```
   Category Name: Photography
   Keywords: (leave empty)
   ```
2. Click "➕ Add Category"
3. **Expected Result:**
   - Category added successfully
   - Keywords show as "AI-generated keywords" in list

### Test 3: Use Custom Category

1. Close Settings panel
2. Select your custom category from dropdown (e.g., "🏷️ Cooking")
3. Open YouTube.com in a new tab
4. Go to YouTube home page (youtube.com)
5. Click "Scan Feed" in extension popup
6. **Expected Result:**
   - Status shows: "AI analyzing Cooking..."
   - Should find and open a cooking video
   - Video starts playing automatically
   - Watch timer appears
   - Activity log shows actions

### Test 4: Delete Custom Category

1. Open Settings
2. In custom categories list, find "Cooking"
3. Click 🗑️ (delete button)
4. Confirm deletion
5. **Expected Result:**
   - Success message: "Category deleted"
   - Category removed from list
   - Category removed from dropdown

### Test 5: Persistence Test

1. Add a custom category
2. Close the popup
3. Close Chrome completely
4. Reopen Chrome
5. Open extension popup
6. **Expected Result:**
   - Custom category still in dropdown
   - Custom category still in list (in Settings)

### Test 6: Duplicate Prevention

1. Add a category: "Travel"
2. Try to add another category: "Travel"
3. **Expected Result:**
   - Warning message: "Category already exists"
   - Category not added twice

### Test 7: Multiple Categories

1. Add 5 different categories:
   ```
   - Cooking
   - Travel
   - Woodworking
   - Photography
   - Gardening
   ```
2. **Expected Result:**
   - All appear in dropdown
   - All appear in scrollable list
   - Dropdown shows separator between default and custom
   - List is scrollable if needed

## ✅ Verification Checklist

### UI Tests
- [ ] Custom category section visible in Settings
- [ ] Input fields present and functional
- [ ] Add button works
- [ ] Delete button works
- [ ] List scrolls when many categories
- [ ] Categories appear in dropdown
- [ ] 🏷️ icon shows for custom categories
- [ ] Separator appears in dropdown

### Functionality Tests
- [ ] Can add category with keywords
- [ ] Can add category without keywords
- [ ] Can delete category
- [ ] Can select custom category
- [ ] Scan Feed works with custom category
- [ ] AI analyzes correctly
- [ ] Categories persist after restart
- [ ] Duplicate prevention works
- [ ] Enter key adds category

### Integration Tests
- [ ] Content script receives custom category
- [ ] Brain analyzes custom category videos
- [ ] Engagement works on custom category videos
- [ ] Stats track custom category sessions
- [ ] Activity log shows correct category name

## 🐛 Common Issues & Fixes

### Issue: "Add Category" button does nothing
**Fix:**
1. Open Chrome DevTools (F12)
2. Check Console tab for errors
3. Make sure category name is filled in
4. Try refreshing the popup

### Issue: Categories not appearing in dropdown
**Fix:**
1. Close and reopen popup
2. Check if category is in the list (Settings)
3. Try reloading the extension:
   - Go to chrome://extensions/
   - Click reload icon under extension

### Issue: Scan Feed not working
**Fix:**
1. Make sure you're on YouTube.com
2. Make sure you're on the home feed (not watch page)
3. Check if category has keywords (add some if not)
4. Try a different category

### Issue: Videos not matching category
**Fix:**
1. Add more specific keywords
2. Make category name more specific
3. Check Activity Log for Brain analysis results

## 📊 Success Criteria

Extension is working correctly if:

1. ✅ Can add custom categories
2. ✅ Categories persist after restart
3. ✅ Can select custom categories from dropdown
4. ✅ Scan Feed finds videos matching custom category
5. ✅ AI analyzes videos correctly
6. ✅ Can delete custom categories
7. ✅ No console errors
8. ✅ All UI elements visible and functional

## 🔍 Debug Mode

To see detailed logs:

1. **Open DevTools**
   - Right-click popup → Inspect
   - Or: F12 while popup is open

2. **Check Console Tab**
   - Should see: `[YouTube Niche Filter] Content script loaded...`
   - Watch for custom category actions

3. **Check Storage**
   - Console → Application tab
   - Storage → Local Storage → chrome-extension://...
   - Look for `customCategories` key

## 📝 Test Log Template

```
Date: _______________
Tester: _______________

Test 1 - Add Category WITH Keywords:    [ PASS / FAIL ]
Test 2 - Add Category WITHOUT Keywords:  [ PASS / FAIL ]
Test 3 - Use Custom Category:            [ PASS / FAIL ]
Test 4 - Delete Category:                [ PASS / FAIL ]
Test 5 - Persistence:                    [ PASS / FAIL ]
Test 6 - Duplicate Prevention:           [ PASS / FAIL ]
Test 7 - Multiple Categories:            [ PASS / FAIL ]

Notes:
_________________________________________________
_________________________________________________
_________________________________________________
```

## 🎯 Next Steps

After successful testing:

1. Use the extension with your custom categories
2. Monitor video matching quality
3. Adjust keywords if needed
4. Add more categories for different accounts
5. Track stats for each category

---

**Having issues?** Check the Chrome DevTools console for error messages!
