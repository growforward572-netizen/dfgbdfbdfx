/**
 * YouTube Data API v3 wrapper for youtube-ai-assistant.
 * Exposes self.youtubeApi with channel resolution and video fetching.
 */
(function initYoutubeApi(globalScope) {
    const API_ROOT = 'https://www.googleapis.com/youtube/v3';
    const RETRYABLE_STATUSES = new Set([429, 500, 502, 503, 504]);

    async function sleep(ms) {
        if (!Number.isFinite(ms) || ms <= 0) return;
        await new Promise((resolve) => setTimeout(resolve, ms));
    }

    function toPositiveInt(value, fallback = 0) {
        const num = Number.parseInt(String(value ?? ''), 10);
        if (!Number.isFinite(num) || num < 0) return fallback;
        return num;
    }

    function normalizeErrorMessage(payload, fallback) {
        return payload?.error?.message || payload?.message || fallback;
    }

    function createApiError(message, status, payload) {
        const error = new Error(message || 'YouTube API request failed');
        error.status = status || 0;
        error.payload = payload || null;
        return error;
    }

    // ---- HTTP layer ----

    async function fetchJsonWithRetry(url, maxAttempts = 3) {
        let attempt = 0;
        let lastError = null;

        while (attempt < maxAttempts) {
            try {
                const response = await fetch(url, { method: 'GET' });
                let payload = null;
                try {
                    payload = await response.json();
                } catch (_) {
                    payload = null;
                }

                if (!response.ok) {
                    const message = normalizeErrorMessage(payload, `YouTube API error (${response.status})`);
                    const err = createApiError(message, response.status, payload);

                    if (RETRYABLE_STATUSES.has(response.status) && attempt < maxAttempts - 1) {
                        const waitMs = (450 * (2 ** attempt)) + Math.floor(Math.random() * 180);
                        await sleep(waitMs);
                        attempt += 1;
                        continue;
                    }

                    throw err;
                }

                return payload || {};
            } catch (error) {
                lastError = error;
                const status = error?.status || 0;
                const canRetry = (status === 0 || RETRYABLE_STATUSES.has(status)) && attempt < maxAttempts - 1;
                if (!canRetry) break;
                const waitMs = (450 * (2 ** attempt)) + Math.floor(Math.random() * 180);
                await sleep(waitMs);
                attempt += 1;
            }
        }

        throw lastError || createApiError('YouTube API request failed');
    }

    async function request(endpoint, params, apiKey) {
        if (!apiKey || typeof apiKey !== 'string') {
            throw createApiError('YouTube API key is required');
        }

        const searchParams = new URLSearchParams();
        Object.entries(params || {}).forEach(([key, value]) => {
            if (value === undefined || value === null || value === '') return;
            searchParams.set(key, String(value));
        });
        searchParams.set('key', apiKey.trim());

        const url = `${API_ROOT}/${endpoint}?${searchParams.toString()}`;
        return await fetchJsonWithRetry(url);
    }

    // ---- Channel resolution ----

    function parseChannelInput(rawInput) {
        const input = String(rawInput || '').trim();
        if (!input) return { raw: '', type: 'empty', value: '' };

        const withProtocol = /^https?:\/\//i.test(input) ? input : `https://${input}`;

        if (/^UC[a-zA-Z0-9_-]{22}$/.test(input)) {
            return { raw: input, type: 'channel_id', value: input };
        }

        if (/^@[a-zA-Z0-9._-]+$/.test(input)) {
            return { raw: input, type: 'handle', value: input.slice(1) };
        }

        try {
            const url = new URL(withProtocol);
            const host = url.hostname.toLowerCase();
            if (!host.includes('youtube.com') && !host.includes('youtu.be')) {
                return { raw: input, type: 'query', value: input };
            }

            const path = url.pathname.replace(/\/+$/, '');
            const segments = path.split('/').filter(Boolean);

            if (segments.length === 0) {
                return { raw: input, type: 'query', value: input };
            }

            if (segments[0].startsWith('@')) {
                return { raw: input, type: 'handle', value: segments[0].slice(1) };
            }

            if (segments[0] === 'channel' && /^UC[a-zA-Z0-9_-]{22}$/.test(segments[1] || '')) {
                return { raw: input, type: 'channel_id', value: segments[1] };
            }

            if (segments[0] === 'user' && segments[1]) {
                return { raw: input, type: 'username', value: segments[1] };
            }

            if (segments[0] === 'c' && segments[1]) {
                return { raw: input, type: 'query', value: segments[1] };
            }

            return { raw: input, type: 'query', value: segments.join(' ') };
        } catch (_) {
            return { raw: input, type: 'query', value: input };
        }
    }

    async function resolveByHandle(handle, apiKey) {
        const clean = String(handle || '').replace(/^@/, '').trim();
        if (!clean) return null;

        try {
            const payload = await request('channels', {
                part: 'snippet',
                forHandle: clean
            }, apiKey);
            const item = Array.isArray(payload.items) ? payload.items[0] : null;
            if (!item?.id) return null;
            return {
                channelId: item.id,
                title: item?.snippet?.title || '',
                resolvedBy: 'forHandle'
            };
        } catch (_) {
            return null;
        }
    }

    async function resolveByUsername(username, apiKey) {
        const clean = String(username || '').trim();
        if (!clean) return null;
        try {
            const payload = await request('channels', {
                part: 'snippet',
                forUsername: clean
            }, apiKey);
            const item = Array.isArray(payload.items) ? payload.items[0] : null;
            if (!item?.id) return null;
            return {
                channelId: item.id,
                title: item?.snippet?.title || '',
                resolvedBy: 'forUsername'
            };
        } catch (_) {
            return null;
        }
    }

    async function resolveBySearch(query, apiKey) {
        const clean = String(query || '').replace(/^@/, '').trim();
        if (!clean) return null;

        const payload = await request('search', {
            part: 'snippet',
            q: clean,
            type: 'channel',
            maxResults: 5
        }, apiKey);

        const items = Array.isArray(payload.items) ? payload.items : [];
        const best = items.find((item) => item?.id?.channelId) || null;
        if (!best) return null;

        return {
            channelId: best.id.channelId,
            title: best?.snippet?.channelTitle || best?.snippet?.title || '',
            resolvedBy: 'search'
        };
    }

    async function resolveChannelId(input, apiKey) {
        const parsed = parseChannelInput(input);
        if (parsed.type === 'empty') {
            throw createApiError('Channel input is empty');
        }

        if (parsed.type === 'channel_id') {
            return { channelId: parsed.value, title: '', resolvedBy: 'channel_id' };
        }

        if (parsed.type === 'handle') {
            const byHandle = await resolveByHandle(parsed.value, apiKey);
            if (byHandle) return byHandle;
            const bySearch = await resolveBySearch(parsed.value, apiKey);
            if (bySearch) return bySearch;
            throw createApiError(`Unable to resolve channel handle: @${parsed.value}`);
        }

        if (parsed.type === 'username') {
            const byUsername = await resolveByUsername(parsed.value, apiKey);
            if (byUsername) return byUsername;
            const bySearch = await resolveBySearch(parsed.value, apiKey);
            if (bySearch) return bySearch;
            throw createApiError(`Unable to resolve channel username: ${parsed.value}`);
        }

        const bySearch = await resolveBySearch(parsed.value, apiKey);
        if (bySearch) return bySearch;
        throw createApiError(`Unable to resolve channel: ${parsed.raw || parsed.value}`);
    }

    // ---- Video detail mapping ----

    function mapVideoItem(item) {
        const id = item?.id || '';
        const snippet = item?.snippet || {};
        const stats = item?.statistics || {};

        return {
            videoId: id,
            title: snippet.title || '',
            channelTitle: snippet.channelTitle || '',
            publishedAt: snippet.publishedAt || '',
            viewCount: toPositiveInt(stats.viewCount, 0),
            likeCount: toPositiveInt(stats.likeCount, 0),
            commentCount: toPositiveInt(stats.commentCount, 0),
            likesDisabled: !('likeCount' in stats),
            commentsDisabled: !('commentCount' in stats),
            url: id ? `https://www.youtube.com/watch?v=${id}` : ''
        };
    }

    async function fetchVideoDetails(videoIds, apiKey) {
        const ids = Array.isArray(videoIds) ? videoIds.filter(Boolean) : [];
        if (ids.length === 0) return [];

        const out = [];
        for (let i = 0; i < ids.length; i += 50) {
            const chunk = ids.slice(i, i + 50);
            const payload = await request('videos', {
                part: 'snippet,statistics',
                id: chunk.join(',')
            }, apiKey);
            const items = Array.isArray(payload.items) ? payload.items : [];
            for (const item of items) {
                out.push(mapVideoItem(item));
            }
        }

        return out;
    }

    // ---- Uploads playlist trick: UU + channelId[2:] saves search.list quota ----

    function getUploadsPlaylistId(channelId) {
        return 'UU' + channelId.slice(2);
    }

    async function getVideosFromPlaylist(channelId, apiKey, maxResults = 50) {
        const playlistId = getUploadsPlaylistId(channelId);
        const videoIds = [];
        let pageToken = '';

        while (videoIds.length < maxResults) {
            const params = {
                part: 'contentDetails',
                playlistId,
                maxResults: Math.min(50, maxResults - videoIds.length),
            };
            if (pageToken) params.pageToken = pageToken;

            const payload = await request('playlistItems', params, apiKey);
            const items = Array.isArray(payload.items) ? payload.items : [];
            for (const item of items) {
                const vid = item?.contentDetails?.videoId;
                if (vid) videoIds.push(vid);
            }

            pageToken = payload?.nextPageToken || '';
            if (!pageToken || items.length === 0) break;
        }

        if (videoIds.length === 0) return [];
        return await fetchVideoDetails(videoIds, apiKey);
    }

    // ---- Public video fetchers ----

    async function getTopPopularVideos(channelId, count, apiKey) {
        const limit = Math.max(1, Math.min(10, toPositiveInt(count, 3)));
        const videos = await getVideosFromPlaylist(channelId, apiKey, 50);
        videos.sort((a, b) => b.viewCount - a.viewCount);
        return videos.slice(0, limit);
    }

    async function getRecentVideos(channelId, options) {
        const opts = options || {};
        const apiKey = opts.apiKey || '';
        const maxVideos = toPositiveInt(opts.maxVideos, 50);

        const videos = await getVideosFromPlaylist(channelId, apiKey, maxVideos);

        if (opts.publishedAfter) {
            const cutoff = opts.publishedAfter instanceof Date
                ? opts.publishedAfter.getTime()
                : Date.parse(String(opts.publishedAfter));

            if (Number.isFinite(cutoff)) {
                return videos.filter((v) => {
                    const ts = Date.parse(v.publishedAt || '');
                    return Number.isFinite(ts) && ts >= cutoff;
                });
            }
        }

        return videos;
    }

    // ---- Export ----

    globalScope.youtubeApi = {
        resolveChannelId,
        getTopPopularVideos,
        getRecentVideos,
        fetchVideoDetails
    };
})(self);
