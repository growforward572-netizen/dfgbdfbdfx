/**
 * YouTube Niche Filter - Content Script
 * Analyzes YouTube home feed using the AI Brain for intelligent matching
 */

// ============================================
// Configuration
// ============================================
const CONFIG = {
    // YouTube DOM selectors (updated for current YouTube layout)
    selectors: {
        videoContainer: 'ytd-rich-item-renderer, ytd-rich-grid-media, ytd-video-renderer, ytd-compact-video-renderer',
        videoTitle: '#video-title, #video-title-link, a#video-title',
        channelName: '#channel-name a, #text.ytd-channel-name a, yt-formatted-string#text a',
        thumbnailLink: 'a#thumbnail',
        feedContainer: 'ytd-rich-grid-renderer, ytd-section-list-renderer'
    },
    maxVideos: 50,
    useBrainDefault: true,

    // Scrolling scan behavior
    scan: {
        // hard limit so we don't scroll forever on an infinite feed
        maxRounds: 3,
        // how many NEW videos to analyze per round
        analyzeChunkSize: 15,
        // stop after scanning this many distinct videos (safety cap)
        // Slightly higher improves match rate and reduces "stuck on home feed" cases.
        maxTotalVideos: 25,
        // used to decide when we can't load more
        minNewVideosPerRound: 1,
        // how long to wait after scrolling (ms)
        scrollSettleMs: 150,
        // how long to wait for new items after scroll (ms)
        waitForNewItemsMs: 400
    },

    filters: {
        minDurationSeconds: 6 * 60,   // Only pick long-form videos 6+ minutes
        maxDurationSeconds: 35 * 60   // ...and under 35 minutes
    },

    watch: {
        // Long-form watch time is a percentage of the video (see humanCycle).
        minWatchSeconds: 60,
        // Used only when the video length can't be read.
        unknownDurationSecondsMin: 180,
        unknownDurationSecondsMax: 420
    },

    // One cycle = home feed -> top channels -> Shorts. Repeats targetCycles times.
    humanCycle: {
        targetCycles: 2,
        homeVideosMin: 3,
        homeVideosMax: 4,
        homeWatchPctMin: 0.30,
        homeWatchPctMax: 0.60,
        channelVideosMin: 2,
        channelVideosMax: 3,
        channelWatchPctMin: 0.30,
        channelWatchPctMax: 0.60,
        longformMinMinutes: 40,
        longformMaxMinutes: 50,
        shortsMinMinutes: 20,
        shortsMaxMinutes: 30,
        // Re-search niche Shorts every N shorts so the feed doesn't drift off-topic.
        shortsResearchMin: 8,
        shortsResearchMax: 14,
        // Safety cap per cycle; the session ends after targetCycles regardless.
        maxHoursPerCycle: 2.5
    },

    session: {
        // Long-run automation (10-15 hours) unless stopped manually.
        minMinutes: 10 * 60,
        maxMinutes: 15 * 60,
        // Keep this high so we don't stop early; session time is the real limit.
        minVideos: 300,
        maxVideos: 800
    },

    engagement: {
        // Long-form engagement is randomized per video instead of every Nth video.
        likeChance: 0.4,
        commentChance: 0.35,
        maxCommentsPerCycle: 3,
        minVideosBetweenComments: 2,
        shareChance: 0.05,
        // Subscribe after finishing a top channel's videos.
        channelSubscribeChance: 0.5,
        shortsLikeChance: 0.12,
        commentStyles: [
            'casual reaction',
            'short question to the creator',
            'personal experience related to the topic',
            'agreeing with one specific point'
        ],
        commentEveryMin: 3,
        commentEveryMax: 5,
        likeEveryMin: 4,
        likeEveryMax: 4,
        shareEvery: 7,
        subscribeEvery: 10,
        likeCycleMax: 156,
        commentDelayMinMs: 5_000,
        commentDelayMaxMs: 10_000,
        likeDelayMinMs: 3_000,
        likeDelayMaxMs: 8_000,
        shareDelayMinMs: 2_000,
        shareDelayMaxMs: 5_000,
        subscribeDelayMinMs: 1_000,
        subscribeDelayMaxMs: 3_000
    }
};

const AUTOPLAY_CONFIG = {
    initialDelayMs: 400,
    retryDelayMs: 300,
    maxAttempts: 5,
    maxTotalMs: 5000,
    postClickCheckMs: 200
};

const AD_CONFIG = {
    checkIntervalMs: 500,       // Check for ads every 0.5 second (better mid-roll detection)
    refreshOnAdDetected: true,  // Refresh page when ad detected
    maxRefreshAttempts: 2,      // Fallback: refresh, refresh
    refreshDelayMs: 1500,       // Wait 1.5s before refresh

    // Skip button detection (preferred path before refresh fallback)
    buttonCheckIntervalMs: 250, // Check for button every 250ms
    buttonCheckDurationMs: 12000, // Keep checking for 12 seconds (some ads allow skip later)
    skipClickDelayMinMs: 1000,  // Once the button appears, wait 1-2.5s before clicking (human reaction)
    skipClickDelayMaxMs: 2500,
    skipVerifyDelayMs: 1500,    // Wait 1.5s after click to verify ad stopped (YouTube UI can lag)
    maxSkipRetries: 3,          // Try 3 times to skip
    retryDelayMs: 1500,         // Wait 1.5s between retries
    maxAdWaitMs: 120000,        // Max wait for ad (2 minutes)

    // Ad detection throughout video (for mid-roll ads)
    continuousMonitoring: true,  // Keep checking for ads during entire video

    // Comprehensive skip button selectors (YouTube updates these frequently)
    skipButtonSelectors: [
        // Modern YouTube selectors
        '.ytp-ad-skip-button-modern',
        'button.ytp-ad-skip-button-modern',
        '.ytp-skip-ad-button',
        'button.ytp-skip-ad-button',

        // Container-based selectors
        '.ytp-ad-skip-button-container button',
        '.ytp-ad-skip-button-slot',
        'button.ytp-ad-skip-button-slot',

        // Older selectors (still used sometimes)
        '.ytp-ad-skip-button',
        'button.ytp-ad-skip-button',
        '.videoAdUiSkipButton',
        'button.videoAdUiSkipButton',

        // Generic class patterns
        'button[class*="skip-ad"]',
        'button[class*="skip-button"]',
        'button[class*="ad-skip"]',

        // Aria label based
        'button[aria-label*="Skip"]',
        'button[aria-label*="skip"]',

        // By video overlay structure
        '.ytp-ad-overlay-container button',
        '.ytp-ad-player-overlay-skip-button',

        // Text-based fallback
        '.ytp-ad-text-overlay button'
    ],

    // These selectors are now only used for reference/debugging
    // The main isAdPlaying() function uses strict detection logic
    adIndicatorSelectors: [
        '.ad-showing',              // Primary - on the player element
        '.ytp-ad-simple-ad-badge',  // Secondary - ad badge
        '.ytp-ad-preview-container' // Secondary - ad countdown
    ]
};

// ============================================
// Human behavior layer (scripts/human.js)
// Every pointer/keyboard/scroll action goes through this so the session reads
// like a person instead of a script. Falls back to plain clicks if it is missing.
// ============================================
const HUMAN = window.__HUMAN__ || {
    enabled: false,
    intensity: 1,
    init() {},
    rand: (min, max) => min + Math.random() * (max - min),
    randInt: (min, max) => Math.floor(min + Math.random() * (max - min + 1)),
    chance: (probability) => Math.random() < probability,
    pick: (list) => (Array.isArray(list) && list.length ? list[Math.floor(Math.random() * list.length)] : null),
    delay: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
    touch() {},
    presence() {},
    async moveTo() {},
    async hover() { return true; },
    async click(element) {
        if (!element) return false;
        element.click();
        return true;
    },
    async type(element, text) {
        if (!element) return false;
        element.value = text;
        element.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
    },
    pressKey() {},
    async scrollBy(pixels) { window.scrollBy(0, pixels); },
    async scrollToElement(element) { element?.scrollIntoView?.({ block: 'center' }); },
    async navigateTo(url) { window.location.assign(url); return false; },
    async navigateHome() { window.location.assign('https://www.youtube.com/'); return false; },
    async search(query, fallbackUrl) { window.location.assign(fallbackUrl); return false; },
    watchBehavior() { return null; },
    stopWatchBehavior() {},
    shouldTakeBreak() { return false; },
    async takeBreak() {},
    warmupFactor() { return 1; },
    async maybeNotInterested() { return false; }
};

let adCheckTimerId = null;
let adRefreshCount = 0; // Track number of refreshes for current video
let adHandlingInProgress = false; // Prevent overlapping ad handlers

const CATEGORY_KEYWORDS = {
    tech: [
        'tech',
        'technology',
        'programming',
        'coding',
        'developer',
        'software',
        'app',
        'web',
        'ai',
        'machine learning',
        'data',
        'cloud',
        'devops',
        'saas',
        'startup'
    ],
    gaming: [
        'gaming',
        'gameplay',
        'stream',
        'streaming',
        'esports',
        'walkthrough',
        'review',
        'speedrun',
        'pc',
        'playstation',
        'xbox',
        'switch',
        'minecraft',
        'fortnite',
        'valorant',
        'roblox'
    ],
    finance: [
        'finance',
        'investing',
        'investment',
        'stocks',
        'stock market',
        'crypto',
        'bitcoin',
        'ethereum',
        'trading',
        'economy',
        'money',
        'budget',
        'wealth',
        'personal finance'
    ],
    fitness: [
        'fitness',
        'workout',
        'exercise',
        'gym',
        'training',
        'nutrition',
        'health',
        'weight loss',
        'cardio',
        'strength',
        'muscle',
        'yoga'
    ],
    business: [
        'business',
        'entrepreneur',
        'entrepreneurship',
        'startup',
        'marketing',
        'sales',
        'ecommerce',
        'strategy',
        'leadership',
        'productivity',
        'growth',
        'management'
    ],
    education: [
        'education',
        'tutorial',
        'how to',
        'learn',
        'course',
        'lesson',
        'guide',
        'explained',
        'tips',
        'training',
        'lecture'
    ],
    entertainment: [
        'entertainment',
        'comedy',
        'movie',
        'tv',
        'show',
        'reaction',
        'vlog',
        'trailer',
        'celebrity',
        'challenge',
        'prank'
    ],
    music: [
        'music',
        'song',
        'album',
        'lyrics',
        'cover',
        'live',
        'concert',
        'mix',
        'playlist',
        'instrumental',
        'producer',
        'beat'
    ]
};

// ============================================
// State
// ============================================
const SESSION_KEYS = {
    autoplay: '__nicheFilter_autoplay',
    cycle: '__nicheFilter_cycle',
    adRefreshCount: '__nicheFilter_adRefreshCount', // Track refresh attempts
    forceScanOnLoad: '__nicheFilter_forceScanOnLoad' // Force scan after refresh
};

// Persistent stats keys (stored in chrome.storage.local)
const STATS_KEYS = {
    totalVideosWatched: 'stats_totalVideosWatched',
    totalLikes: 'stats_totalLikes',
    totalComments: 'stats_totalComments',
    totalShares: 'stats_totalShares',
    totalSubscribes: 'stats_totalSubscribes',
    totalWatchTimeSeconds: 'stats_totalWatchTimeSeconds',
    totalSessions: 'stats_totalSessions',
    lastSessionDate: 'stats_lastSessionDate'
};

let useBrain = CONFIG.useBrainDefault;
let debugLogged = false;
let cycleReturnTimerId = null;
let cycleReturnVideoKey = '';
let cycleReturning = false;
let engagementVideoKey = '';
let commentTimerId = null;
let likeTimerId = null;
let sessionEndTimerId = null;
let sessionEndAt = 0;
let cycleWatchdogTimerId = null;
let cycleHomeRefreshTimerId = null;
let cycleLastAutoScanLocation = '';
let cycleScanInProgress = false;
let automationEnabled = true;
let stopRequested = false;
let lastOpenRequestKey = '';
let lastOpenRequestAt = 0;
let openInProgress = false;
let shortsLoopRunning = false;

// YouTube search filter: "Type: Channel"
const CHANNEL_SEARCH_FILTER = 'EgIQAg%253D%253D';

const autoplayState = {
    active: false,
    requested: false,
    startedAt: 0,
    attempts: 0,
    timerId: null
};

// Load automation enabled/disabled (kill switch)
chrome.storage.local.get(['automationEnabled'], (result) => {
    automationEnabled = result.automationEnabled !== false;
    stopRequested = !automationEnabled;
    if (!automationEnabled) {
        stopAutomationNow('disabled');
    }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    if (!changes.automationEnabled) return;

    automationEnabled = changes.automationEnabled.newValue !== false;
    stopRequested = !automationEnabled;
    if (!automationEnabled) {
        stopAutomationNow('disabled');
    }
});

// Load brain setting
chrome.storage.local.get(['useBrain'], (result) => {
    useBrain = result.useBrain !== false; // Default true
});

// ============================================
// Message Listener
// ============================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.action) {
        case 'scanFeed':
            handleScanFeed(message)
                .then(result => sendResponse(result))
                .catch(error => sendResponse({ success: false, error: error.message }));
            return true;

        case 'openVideo':
            // Respond first; navigation can tear down the page.
            sendResponse({ success: true });
            setTimeout(() => handleOpenVideo(message.url), 0);
            return false;

        case 'stopAutomation':
            stopRequested = true;
            stopAutomationNow(message.permanent ? 'manual_stop' : 'stop');
            sendResponse({ success: true });
            return false;

        case 'getTimerState':
            sendResponse(getTimerStateForPopup());
            return false;

        default:
            sendResponse({ success: false, error: 'Unknown action' });
            return false;
    }
});

// ============================================
// Feed Scanning with Brain Integration
// ============================================

/**
 * Scan YouTube feed for matching videos
 * Routes through the Brain for AI-powered analysis
 */
async function handleScanFeed(message) {
    const {
        keywords,
        niche,
        category,
        useBrainOverride,
        autoOpen,
        autoCycle,
        cycleMinMs,
        cycleMaxMs,
        commentAssist,
        maxCommentsPerSession,
        commentCooldownMinMs,
        commentCooldownMaxMs,
        targetCycles,
        scanId
    } = message;
    const shouldUseBrain = true;
    const selectedCategory = category || niche || '';
    const resolvedKeywords = normalizeKeywordsForScan(keywords, selectedCategory);
    const categoryHints = getCategoryKeywords(selectedCategory);
    const cycleEnabled = autoCycle === true;

    try {
        if (!automationEnabled || stopRequested) {
            throw new Error('Automation is disabled');
        }
        if (!selectedCategory) {
            throw new Error('Category is required');
        }
        if (!Array.isArray(resolvedKeywords) || resolvedKeywords.length === 0) {
            throw new Error('Category is required');
        }
        if (!isYouTubePage()) throw new Error('Please navigate to YouTube');
        if (!isYouTubeHomeFeed()) throw new Error('Please open the YouTube home feed (youtube.com/)');

        const brainCategory = formatCategoryForBrain(selectedCategory, resolvedKeywords);

    notifyScanProgress({
        scanId,
        stage: 'start',
        category: brainCategory
    });

    logActivity(`Session started - Category: ${brainCategory}`, 'action');

    await waitForFeed();

        let skipVideoKeys;

        if (cycleEnabled) {
            const cycleState = createCycleState({
                keywords: resolvedKeywords,
                category: selectedCategory,
                useBrain: true,
                cycleMinMs,
                cycleMaxMs,
                commentAssist,
                maxCommentsPerSession,
                commentCooldownMinMs,
                commentCooldownMaxMs,
                targetCycles
            });
            saveCycleState(cycleState);
            logActivity(`Cycle 1/${cycleState.targetCycles}: browsing home feed (${cycleState.homeTarget} videos)`, 'action');
            scheduleSessionEnd(cycleState);
            skipVideoKeys = new Set(cycleState.watchedKeys || []);

            // Record session start in stats
            recordSessionStart();

            // One-time per niche: AI-picked title words that keep keyword mode accurate offline.
            await seedNicheKeywords(selectedCategory, resolvedKeywords);
        }

        if (cycleEnabled) cycleScanInProgress = true;

        const scanResult = await scanFeedProgressively({
            keywords: resolvedKeywords,
            category: brainCategory,
            categoryHints,
            shouldUseBrain,
            autoOpen: autoOpen !== false,
            skipVideoKeys,
            scanId,
            onPicked: (picked) => {
                if (!cycleEnabled) return;
                recordCyclePick(picked);
            }
        });

        notifyScanProgress({
            scanId,
            stage: 'complete',
            opened: scanResult.opened,
            matches: scanResult.matches.length,
            totalScanned: scanResult.totalScanned
        });

        return {
            success: true,
            matches: scanResult.matches.slice(0, 10),
            totalScanned: scanResult.totalScanned,
            usedBrain: true,
            opened: scanResult.opened,
            openedVideo: scanResult.openedVideo || null
        };

    } catch (error) {
        console.error('[Niche Filter] Scan error:', error);
        notifyScanProgress({
            scanId,
            stage: 'error',
            error: error.message || 'Scan failed'
        });
        return { success: false, error: error.message };
    } finally {
        if (cycleEnabled) cycleScanInProgress = false;
    }
}

/**
 * Analyze a single video using the AI Brain (via background worker)
 * Returns null if video doesn't match or if there's an error (fail gracefully)
 */
async function analyzeVideoWithBrain(video, category, categoryHints) {
    const safeHints = Array.isArray(categoryHints) ? categoryHints.filter(Boolean).slice(0, 8) : [];

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'brainAnalyzeVideo',
            title: video?.title || '',
            category,
            categoryHints: safeHints,
            keywords: []
        });

        if (!response?.success) {
            console.warn('[Niche Filter] Brain analysis failed:', response?.error);
            return null; // Skip this video, continue to next
        }

        const result = response.result || {};
        const decision = String(result.decision || '').toLowerCase();

        // On fallback or error, skip this video gracefully
        if (decision === 'fallback' || decision === 'error') {
            console.warn('[Niche Filter] Brain returned fallback/error, skipping video');
            return null;
        }

        const relevant = resolveBrainRelevant(result);
        if (relevant === null || !relevant) {
            return null;
        }

        let score = normalizeBrainScore(result?.data?.score);
        if (!Number.isFinite(score) || score <= 0) {
            score = normalizeBrainScore(result?.confidence);
        }
        if (!Number.isFinite(score) || score <= 0) {
            score = 70;
        }

        return {
            ...video,
            score,
            brainAnalyzed: true,
            brainFallback: false
        };
    } catch (error) {
        console.warn('[Niche Filter] Brain analysis error, skipping video:', error.message);
        return null; // Skip this video on error, continue scanning
    }
}

/**
 * Analyze videos using keyword matching (fallback)
 */
function analyzeWithKeywords(videos, keywords, options = {}) {
    const minScore = typeof options.minScore === 'number'
        ? options.minScore
        : getKeywordMinScore(keywords, 20);
    const matches = [];

    for (let i = 0; i < videos.length; i++) {
        const video = videos[i];
        const score = calculateMatchScore(getTextForMatching(video), keywords);
        if (score >= minScore) {
            matches.push({
                ...video,
                score,
                brainAnalyzed: false,
                sourceIndex: i
            });
        }
    }

    return matches;
}

/**
 * Calculate keyword match score
 */
function calculateMatchScore(text, keywords) {
    if (!keywords || !Array.isArray(keywords)) return 0;

    const titleLower = (text || '').toLowerCase();
    let score = 0;

    for (const keyword of keywords) {
        const keywordLower = keyword.toLowerCase();

        const isGeneric = isGenericKeyword(keywordLower);
        const exactPoints = isGeneric ? 15 : 40;
        const partialPoints = isGeneric ? 8 : 20;

        // Exact word/phrase match
        const wordPattern = new RegExp(`\\b${escapeRegex(keywordLower)}\\b`, 'i');
        if (wordPattern.test(titleLower)) {
            score += exactPoints;
            continue;
        }

        // Partial match
        if (titleLower.includes(keywordLower)) {
            score += partialPoints;
        }
    }

    return Math.min(score, 100);
}

function isGenericKeyword(keywordLower) {
    // Common broad words that create false positives.
    return (
        keywordLower === 'tech' ||
        keywordLower === 'tutorial' ||
        keywordLower === 'how to' ||
        keywordLower === 'learn' ||
        keywordLower === 'course' ||
        keywordLower === 'review' ||
        keywordLower === 'trending'
    );
}

function getTextForMatching(video) {
    return video?.title || '';
}

function getCategoryKeywords(categoryValue) {
    const key = String(categoryValue || '').trim();
    if (!key) return [];

    // Check if it's a custom category (starts with 'custom_')
    if (key.startsWith('custom_')) {
        // For custom categories, the keywords are already passed from popup
        // Just return the key as a single keyword for fallback
        return [key.replace('custom_', '').replace(/_/g, ' ')];
    }

    const keyLower = key.toLowerCase();
    const mapped = CATEGORY_KEYWORDS[keyLower];
    if (Array.isArray(mapped) && mapped.length > 0) return mapped.slice();
    return [key];
}

function normalizeKeywordsForScan(keywords, categoryValue) {
    const cleaned = Array.isArray(keywords)
        ? keywords
            .map(k => String(k || '').trim().toLowerCase())
            .filter(Boolean)
        : [];

    let resolved = cleaned.length > 0 ? cleaned : getCategoryKeywords(categoryValue);
    const categoryKey = String(categoryValue || '').trim().toLowerCase();
    if (categoryKey && !resolved.includes(categoryKey)) {
        resolved = resolved.concat(categoryKey);
    }

    return Array.from(new Set(resolved));
}

function getKeywordMinScore(keywords, defaultMinScore) {
    const minScore = Number.isFinite(defaultMinScore) ? defaultMinScore : 20;
    if (!Array.isArray(keywords) || keywords.length === 0) return minScore;

    const hasSpecific = keywords.some((keyword) => {
        const normalized = String(keyword || '').trim().toLowerCase();
        if (!normalized) return false;
        if (isGenericKeyword(normalized)) return false;
        return normalized.length >= 4;
    });

    return hasSpecific ? minScore : 15;
}

// ============================================
// Helper Functions
// ============================================

function notifyScanProgress({
    scanId,
    stage,
    scanned,
    totalDiscovered,
    title,
    error,
    opened,
    matches,
    totalScanned,
    category
}) {
    updateOverlayFromProgress({
        stage,
        scanned,
        totalDiscovered,
        title,
        error,
        opened,
        matches,
        totalScanned,
        category
    });

    // Broadcast timer state on each progress update
    broadcastTimerState();

    if (!scanId) return;
    try {
        chrome.runtime.sendMessage({
            action: 'scanProgress',
            scanId,
            stage,
            scanned,
            totalDiscovered,
            title,
            error,
            opened,
            matches,
            totalScanned,
            category
        });
    } catch {
        // ignore
    }
}

const OVERLAY_ID = 'niche-filter-overlay';

function ensureOverlay() {
    let overlay = document.getElementById(OVERLAY_ID);
    if (overlay) return overlay;

    overlay = document.createElement('div');
    overlay.id = OVERLAY_ID;
    overlay.className = 'niche-filter-overlay';
    overlay.innerHTML = `
        <div class="niche-filter-overlay__title"></div>
        <div class="niche-filter-overlay__detail"></div>
    `;

    document.documentElement.appendChild(overlay);
    return overlay;
}

function updateOverlay(title, detail, tone = 'info') {
    const overlay = ensureOverlay();
    const titleEl = overlay.querySelector('.niche-filter-overlay__title');
    const detailEl = overlay.querySelector('.niche-filter-overlay__detail');

    if (titleEl) titleEl.textContent = title || '';
    if (detailEl) detailEl.textContent = detail || '';

    overlay.dataset.tone = tone;
    overlay.classList.add('niche-filter-overlay--visible');
}

function hideOverlay() {
    const overlay = document.getElementById(OVERLAY_ID);
    if (!overlay) return;
    overlay.classList.remove('niche-filter-overlay--visible');
}

// ============================================
// Timer State & Activity Log Broadcasting
// ============================================

/**
 * Get current timer state for popup
 */
function getTimerStateForPopup() {
    const state = loadCycleState();

    if (!state || state.active !== true) {
        return {
            isActive: false,
            returnAt: 0,
            sessionEndsAt: 0,
            stage: 'idle'
        };
    }

    let stage = 'idle';
    if (isShortsPage()) {
        stage = 'watching_shorts';
    } else if (isWatchLikePage()) {
        stage = 'watching';
    } else if (isYouTubeSearchPage()) {
        stage = cycleScanInProgress ? 'scanning_search' : 'waiting';
    } else if (isYouTubeHomeFeed()) {
        stage = cycleScanInProgress ? 'scanning' : 'waiting';
    }

    return {
        isActive: true,
        returnAt: state.returnAt || 0,
        sessionEndsAt: state.endsAt || 0,
        stage,
        totalWatched: state.totalWatched || 0,
        currentTitle: state.lastPickedTitle || '',
        phase: state.cyclePhase || 'home_feed',
        phaseVideosWatched: state.phaseVideosWatched || 0,
        cycleNumber: (state.cyclesCompleted || 0) + 1,
        targetCycles: state.targetCycles || CONFIG.humanCycle.targetCycles,
        longformWatchedMs: state.longformWatchedMs || 0,
        longformTargetMs: state.longformTargetMs || 0,
        shortsEndsAt: state.shortsEndsAt || 0
    };
}

/**
 * Broadcast timer state to popup
 */
function broadcastTimerState() {
    try {
        chrome.runtime.sendMessage({
            action: 'timerUpdate',
            ...getTimerStateForPopup()
        });
    } catch {
        // Popup might not be open
    }
}

/**
 * Send activity log message to popup
 */
function logActivity(text, type = 'info') {
    try {
        chrome.runtime.sendMessage({
            action: 'activityLog',
            text,
            type
        });
    } catch {
        // Popup might not be open
    }
    // Also log to console
    console.log(`[Niche Filter] ${text}`);
}

function updateOverlayFromProgress({ stage, scanned, title, error, opened, matches, totalScanned, category }) {
    const cleanTitle = typeof title === 'string' ? title.trim() : '';

    switch (stage) {
        case 'start':
            updateOverlay('Scanning feed', category ? `Category: ${category}` : '');
            break;
        case 'analyzing':
            updateOverlay(
                scanned ? `Analyzing #${scanned}` : 'Analyzing',
                cleanTitle ? cleanTitle : ''
            );
            break;
        case 'opening':
            updateOverlay('Opening match', cleanTitle || 'Opening matching video', 'success');
            break;
        case 'watching':
            updateOverlay('Watching video', cleanTitle || 'Auto-watching', 'info');
            break;
        case 'returning':
            updateOverlay('Returning home', cleanTitle || 'Continuing scan', 'info');
            break;
        case 'complete': {
            if (opened) {
                updateOverlay('Match opened', 'Watching and preparing next scan', 'success');
                break;
            }
            const found = Number.isFinite(matches) ? matches : 0;
            updateOverlay(
                'Scan complete',
                found > 0 ? `Found ${found} video(s)` : 'No matches found',
                found > 0 ? 'success' : 'warning'
            );
            break;
        }
        case 'error':
            updateOverlay('Brain error', error || 'Scan failed', 'error');
            break;
        case 'stopped':
            updateOverlay('Automation stopped', error || '', 'warning');
            break;
        default:
            if (stage) {
                updateOverlay(stage, '', 'info');
            }
            break;
    }
}

function isYouTubePage() {
    return window.location.hostname.includes('youtube.com');
}

function isYouTubeHomeFeed() {
    // Home feed is typically '/', and other browse feeds live under '/feed/'.
    // Keep strict enough to avoid trying to scan watch pages.
    return window.location.pathname === '/' || window.location.pathname.startsWith('/feed/');
}

function isYouTubeSearchPage() {
    return window.location.pathname === '/results';
}

async function waitForFeed() {
    return new Promise((resolve, reject) => {
        let attempts = 0;
        // YouTube can be slow to hydrate the home feed, especially after hard navigations.
        // Give it more time so the cycle doesn't "stall" and require manual restarts.
        const maxAttempts = 80; // 80 * 250ms = 20s

        const checkFeed = () => {
            const feed = document.querySelector(CONFIG.selectors.feedContainer);
            const videos = document.querySelectorAll(CONFIG.selectors.videoContainer);

            if (feed && videos.length > 0) {
                resolve();
                return;
            }

            attempts++;
            if (attempts >= maxAttempts) {
                reject(new Error('Feed not loaded. Please wait and try again.'));
                return;
            }

            setTimeout(checkFeed, 250);
        };

        checkFeed();
    });
}

function getVideoElements() {
    const elements = document.querySelectorAll(CONFIG.selectors.videoContainer);
    return Array.from(elements).slice(0, CONFIG.maxVideos);
}

function getAllVideoElements() {
    const elements = document.querySelectorAll(CONFIG.selectors.videoContainer);
    return Array.from(elements);
}

function extractVideoData(element) {
    try {
        const linkEl = findBestVideoLink(element);
        const href = linkEl?.getAttribute('href') || linkEl?.href || '';
        const url = toAbsoluteYouTubeUrl(href);
        if (!url) return null;

        const key = getVideoKeyFromUrl(url);
        if (!key) return null;

        const { title, ariaLabel, source: titleSource } = extractTitle(element, linkEl);
        if (!title) return null;

        const channel = extractChannel(element, ariaLabel) || 'Unknown';
        const hashtags = extractHashtags(element, ariaLabel);
        const isLive = detectLive(element, ariaLabel);

        const { durationSeconds, durationText } = extractDuration(element);
        if (isLive) return null;
        if (!isDurationAllowed(durationSeconds)) return null;

        return {
            title,
            url,
            key,
            channel,
            hashtags,
            isLive,
            titleSource,
            durationSeconds,
            durationText
        };
    } catch {
        return null;
    }
}

async function handleOpenVideo(url) {
    if (!url) return;

    const targetUrl = toAbsoluteYouTubeUrl(url) || url;
    const key = getVideoKeyFromUrl(targetUrl);
    const now = Date.now();

    // Guard against duplicate open requests fired within a short time window.
    if (key && lastOpenRequestKey === key && now - lastOpenRequestAt < 8_000) {
        console.log(`[Niche Filter] Skipping duplicate open request for ${key}`);
        return;
    }

    lastOpenRequestKey = key || '';
    lastOpenRequestAt = now;
    openInProgress = true;
    // Safety net in case the click never navigates.
    setTimeout(() => {
        openInProgress = false;
    }, 6_000);

    try {
        // Mark intent so the next page load can attempt to start playback.
        sessionStorage.setItem(SESSION_KEYS.autoplay, '1');
    } catch {
        // ignore
    }
    // Reset location tracker so returning home will trigger a new scan
    cycleLastAutoScanLocation = '';

    // Click the real card link when it is on screen: YouTube then does an
    // in-page transition instead of a hard reload, which is what a person does.
    const link = findLinkForUrl(targetUrl);
    if (link) {
        const clicked = await HUMAN.click(link, { missChance: 0.05 });
        if (clicked) {
            const startedAt = Date.now();
            while (Date.now() - startedAt < 3_000) {
                if (getVideoKeyFromUrl(window.location.href) === key) return;
                await sleep(150);
            }
        }
    }

    window.location.assign(targetUrl);
}

function findLinkForUrl(url) {
    try {
        const wanted = new URL(url, window.location.origin);
        for (const anchor of document.querySelectorAll('a[href]')) {
            const href = anchor.getAttribute('href');
            if (!href || href.startsWith('javascript:')) continue;
            const candidate = new URL(href, window.location.origin);
            if (candidate.pathname !== wanted.pathname) continue;
            if (wanted.search && candidate.search !== wanted.search) continue;
            return anchor;
        }
    } catch {
        // ignore
    }
    return null;
}

function maybeAutoplayIfRequested() {
    if (!isPlaybackPage()) return;
    if (!automationEnabled || stopRequested) return;

    if (autoplayState.active) {
        scheduleAutoplayAttempt(0);
        return;
    }

    let requested = false;
    try {
        const flag = sessionStorage.getItem(SESSION_KEYS.autoplay);
        requested = Boolean(flag);
        if (requested) sessionStorage.removeItem(SESSION_KEYS.autoplay);
    } catch {
        requested = false;
    }

    if (!requested) return;

    autoplayState.active = true;
    autoplayState.requested = true;
    autoplayState.startedAt = Date.now();
    autoplayState.attempts = 0;

    // A person does not press play the instant the page paints.
    scheduleAutoplayAttempt(HUMAN.randInt(900, 2_600));
}

function scheduleAutoplayAttempt(delayMs) {
    if (autoplayState.timerId) {
        clearTimeout(autoplayState.timerId);
        autoplayState.timerId = null;
    }

    autoplayState.timerId = setTimeout(() => {
        autoplayState.timerId = null;
        runAutoplayAttempt();
    }, delayMs);
}

function resetAutoplayState() {
    if (autoplayState.timerId) {
        clearTimeout(autoplayState.timerId);
        autoplayState.timerId = null;
    }

    autoplayState.active = false;
    autoplayState.requested = false;
    autoplayState.startedAt = 0;
    autoplayState.attempts = 0;
}

function clearCycleReturnTimer() {
    if (cycleReturnTimerId) {
        clearTimeout(cycleReturnTimerId);
        cycleReturnTimerId = null;
    }
    cycleReturnVideoKey = '';
    cycleReturning = false;
}

function clearEngagementTimers() {
    if (commentTimerId) {
        clearTimeout(commentTimerId);
        commentTimerId = null;
    }
    if (likeTimerId) {
        clearTimeout(likeTimerId);
        likeTimerId = null;
    }
    engagementVideoKey = '';
}

function clearSessionEndTimer() {
    if (sessionEndTimerId) {
        clearTimeout(sessionEndTimerId);
        sessionEndTimerId = null;
    }
    sessionEndAt = 0;
}

function startCycleWatchdog() {
    if (cycleWatchdogTimerId) return;

    // YouTube is an SPA and sometimes skips expected navigation events; this watchdog
    // ensures the cycle keeps progressing until the user stops it.
    cycleWatchdogTimerId = setInterval(() => {
        try {
            const state = loadCycleState();
            if (!state || state.active !== true) return;
            if (!automationEnabled || stopRequested) return;
            maybeContinueCycle();
        } catch {
            // ignore
        }
    }, 5000);
}

function stopCycleWatchdog() {
    if (cycleWatchdogTimerId) {
        clearInterval(cycleWatchdogTimerId);
        cycleWatchdogTimerId = null;
    }
}

function scheduleSessionEnd(state) {
    if (!state?.endsAt) return;
    if (sessionEndTimerId && sessionEndAt === state.endsAt) return;

    clearSessionEndTimer();
    sessionEndAt = state.endsAt;
    const delayMs = Math.max(0, state.endsAt - Date.now());

    sessionEndTimerId = setTimeout(() => {
        sessionEndTimerId = null;
        sessionEndAt = 0;
        stopAutomationNow('session_end');
    }, delayMs);
}

function pauseActiveVideo() {
    const video = document.querySelector('video');
    if (video && !video.paused) {
        try {
            video.pause();
        } catch {
            // ignore
        }
    }
}

function stopAutomationNow(reason) {
    clearCycleReturnTimer();
    clearEngagementTimers();
    clearSessionEndTimer();
    resetAutoplayState();
    stopAdMonitoring();
    stopCycleWatchdog();
    HUMAN.stopWatchBehavior();
    if (cycleHomeRefreshTimerId) {
        clearTimeout(cycleHomeRefreshTimerId);
        cycleHomeRefreshTimerId = null;
    }
    cycleScanInProgress = false;
    cycleLastAutoScanLocation = '';
    openInProgress = false;
    deactivateCycle(reason || 'stopped');
    pauseActiveVideo();
    notifyScanProgress({ stage: 'stopped', error: reason || 'stopped' });
    setTimeout(() => hideOverlay(), 2000);
}

async function runAutoplayAttempt() {
    if (!autoplayState.active) return;
    if (!isPlaybackPage()) {
        resetAutoplayState();
        return;
    }
    if (!automationEnabled || stopRequested) {
        resetAutoplayState();
        return;
    }

    autoplayState.attempts += 1;

    // Handle any ads first before trying to play the actual video
    if (isAdPlaying()) {
        console.log('[Niche Filter] Ad detected during autoplay, handling...');
        await handleAds();
    }

    const started = await tryStartPlayback();
    if (started) {
        // Start ad monitoring for future ads
        startAdMonitoring();
        resetAutoplayState();
        return;
    }

    const elapsed = Date.now() - autoplayState.startedAt;
    if (autoplayState.attempts >= AUTOPLAY_CONFIG.maxAttempts || elapsed >= AUTOPLAY_CONFIG.maxTotalMs) {
        const shouldReturnHome = autoplayState.requested;
        resetAutoplayState();
        if (shouldReturnHome) {
            returnHomeAndRestart('autoplay_failed');
        }
        return;
    }

    scheduleAutoplayAttempt(AUTOPLAY_CONFIG.retryDelayMs);
}

async function tryStartPlayback() {
    // Check if video is unavailable/private first
    if (isVideoUnavailable()) {
        console.warn('[Niche Filter] Video is unavailable or private');
        logActivity('Video is unavailable or private', 'error');
        return false;
    }

    const video = document.querySelector('video');
    if (isVideoPlaying(video)) {
        // Check if it's an ad or actual video
        if (!isAdPlaying()) {
            // Video started successfully - reset ad refresh count
            resetAdRefreshCount();
            logActivity('Video started playing', 'success');
        }
        return true;
    }

    if (video) {
        try {
            await video.play();
        } catch {
            // ignore
        }
    }

    if (isVideoPlaying(video)) {
        // Check if it's an ad or actual video
        if (!isAdPlaying()) {
            // Video started successfully - reset ad refresh count
            resetAdRefreshCount();
            logActivity('Video started playing', 'success');
        }
        return true;
    }

    const clicked = await clickPlayControls(video);
    if (clicked) {
        await sleep(AUTOPLAY_CONFIG.postClickCheckMs);
    }

    const updatedVideo = document.querySelector('video');
    const isPlaying = isVideoPlaying(updatedVideo);
    if (isPlaying) {
        // Check if it's an ad or actual video
        if (!isAdPlaying()) {
            // Video started successfully - reset ad refresh count
            resetAdRefreshCount();
            logActivity('Video started playing', 'success');
        }
    }
    return isPlaying;
}

/**
 * Check if video is unavailable, private, or deleted
 */
function isVideoUnavailable() {
    const errorSelectors = [
        '#error-screen',
        'yt-playability-error-supported-renderers',
        '.ytp-error',
        '#player-error-message-container'
    ];

    for (const selector of errorSelectors) {
        const el = document.querySelector(selector);
        if (el && el.offsetParent !== null) {
            return true;
        }
    }

    // Check for specific error messages
    const messageSelectors = [
        '.yt-playability-error-supported-renderers',
        '#reason',
        '.ytp-error-content-wrap-reason'
    ];

    for (const selector of messageSelectors) {
        const el = document.querySelector(selector);
        if (!el) continue;

        const text = (el.textContent || '').toLowerCase();
        if (text.includes('private') ||
            text.includes('unavailable') ||
            text.includes('removed') ||
            text.includes('deleted') ||
            text.includes('no longer available') ||
            text.includes('video is not available')) {
            return true;
        }
    }

    return false;
}

function isVideoPlaying(video) {
    if (!video) return false;
    return !video.paused && !video.ended && video.readyState >= 2;
}

async function clickPlayControls(video) {
    if (video && !video.paused && !video.ended) return false;

    const selectors = [
        '.ytp-play-button',
        'button.ytp-play-button',
        '.ytp-large-play-button',
        'button.ytp-large-play-button',
        'button[aria-label*="Play"]',
        'button[title*="Play"]'
    ];

    for (const selector of selectors) {
        const el = document.querySelector(selector);
        if (!el) continue;
        // Prefer a real pointer press on the player surface; fall back to the button.
        const surface = document.querySelector('#movie_player');
        if (surface && !isVideoPlaying(video)) {
            await HUMAN.click(surface, { missChance: 0.05 });
            await sleep(HUMAN.randInt(150, 400));
            if (isVideoPlaying(document.querySelector('video'))) return true;
        }
        await HUMAN.click(el, { missChance: 0.03 });
        return true;
    }

    return false;
}

function returnHomeAndRestart(reason) {
    if (!isPlaybackPage()) return;

    const state = loadCycleState();
    if (!state || state.active !== true) {
        logActivity('Returning to home feed', 'navigation');
        window.location.assign('https://www.youtube.com/');
        return;
    }

    clearCycleReturnTimer();
    clearEngagementTimers();
    cycleLastAutoScanLocation = '';
    console.warn(`[Niche Filter] Autoplay failed (${reason}); returning home to continue.`);
    logActivity(`Autoplay failed: ${reason}, returning home`, 'error');
    notifyScanProgress({ stage: 'returning', error: reason || '' });
    window.location.assign('https://www.youtube.com/');
}

function toAbsoluteYouTubeUrl(href) {
    if (!href) return '';
    try {
        if (href.startsWith('javascript:')) return '';
        const u = new URL(href, window.location.origin);

        if (u.pathname === '/watch') {
            const v = u.searchParams.get('v');
            if (!v) return '';
            return `${u.origin}/watch?v=${encodeURIComponent(v)}`;
        }

        // Allow long-form live pages too (some cards use /live/<id>)
        if (u.pathname.startsWith('/live/')) {
            return `${u.origin}${u.pathname}`;
        }

        // Ignore shorts and non-video links.
        return '';
    } catch {
        return '';
    }
}

function findBestVideoLink(element) {
    return (
        element.querySelector('a#video-title-link[href*="/watch?v="]') ||
        element.querySelector('a#thumbnail[href*="/watch?v="]') ||
        element.querySelector('a[href*="/watch?v="]') ||
        element.querySelector('a[href^="/live/"]') ||
        element.querySelector('a[href*="/live/"]') ||
        null
    );
}

function extractTitle(element, linkEl) {
    const titleLink =
        element.querySelector('a#video-title-link') ||
        element.querySelector('a#video-title') ||
        element.querySelector('h3 a') ||
        linkEl ||
        null;

    const titleAttr = normalizeText(titleLink?.getAttribute?.('title'));
    const text = normalizeText(titleLink?.textContent);
    const ariaLabel = normalizeText(
        titleLink?.getAttribute?.('aria-label') || linkEl?.getAttribute?.('aria-label') || ''
    );
    const fromAria = normalizeText(parseTitleFromAriaLabel(ariaLabel));

    // Some cards only expose the full title via the thumbnail image alt.
    const imgAlt = normalizeText(element.querySelector('img[alt]')?.getAttribute('alt'));

    let title = '';
    let source = '';

    if (titleAttr) {
        title = titleAttr;
        source = 'title_attr';
    } else if (text) {
        title = text;
        source = 'text';
    } else if (fromAria) {
        title = fromAria;
        source = 'aria';
    } else if (imgAlt) {
        title = imgAlt;
        source = 'img_alt';
    }

    return { title, ariaLabel, source };
}

function extractChannel(element, ariaLabel) {
    const channelElement = element.querySelector(CONFIG.selectors.channelName);
    const fromDom = normalizeText(channelElement?.textContent);
    if (fromDom) return fromDom;
    return normalizeText(parseChannelFromAriaLabel(ariaLabel));
}

function extractHashtags(element, ariaLabel) {
    const tags = new Set();
    for (const a of element.querySelectorAll('a[href^="/hashtag/"]')) {
        const t = normalizeText(a.textContent);
        if (t) tags.add(t.startsWith('#') ? t : `#${t}`);
    }

    // Backup: some aria-labels include hashtags.
    for (const m of String(ariaLabel || '').match(/#[A-Za-z0-9_]+/g) || []) {
        tags.add(m);
    }

    return Array.from(tags);
}

function detectLive(element, ariaLabel) {
    const aria = String(ariaLabel || '').toLowerCase();
    if (aria.startsWith('live') || aria.includes(' live:') || aria.includes(' live ')) return true;

    const badgeText = normalizeText(
        element.querySelector('ytd-thumbnail-overlay-time-status-renderer')?.textContent ||
        element.querySelector('ytd-badge-supported-renderer')?.textContent ||
        element.querySelector('yt-thumbnail-badge-view-model')?.textContent ||
        ''
    ).toLowerCase();

    return badgeText.includes('live');
}

function extractDuration(element) {
    const candidates = [
        element.querySelector('ytd-thumbnail-overlay-time-status-renderer span#text')?.textContent,
        element.querySelector('ytd-thumbnail-overlay-time-status-renderer')?.textContent,
        element.querySelector('span.ytd-thumbnail-overlay-time-status-renderer')?.textContent,
        // Newer lockup cards (yt-lockup-view-model) show the length in a badge.
        element.querySelector('yt-thumbnail-badge-view-model .yt-badge-shape__text')?.textContent,
        element.querySelector('yt-thumbnail-badge-view-model')?.textContent
    ];

    for (const raw of candidates) {
        const cleaned = normalizeText(raw);
        if (!cleaned) continue;
        const parsed = parseDurationText(cleaned);
        if (parsed) return parsed;
    }

    return { durationSeconds: null, durationText: '' };
}

function parseDurationText(text) {
    if (!text) return null;
    const match = text.match(/\b\d{1,2}:\d{2}(?::\d{2})?\b/);
    if (!match) return null;
    const timeText = match[0];
    const parts = timeText.split(':').map(part => Number.parseInt(part, 10));
    if (parts.some(p => Number.isNaN(p))) return null;

    let seconds = 0;
    for (const part of parts) {
        seconds = seconds * 60 + part;
    }

    if (!Number.isFinite(seconds) || seconds <= 0) return null;
    return { durationSeconds: seconds, durationText: timeText };
}

function isDurationAllowed(durationSeconds) {
    if (typeof durationSeconds !== 'number' || !Number.isFinite(durationSeconds)) return true;
    return durationSeconds >= CONFIG.filters.minDurationSeconds && durationSeconds <= CONFIG.filters.maxDurationSeconds;
}

function parseTitleFromAriaLabel(label) {
    if (!label) return '';
    // Typical format: "<TITLE> by <CHANNEL> <metadata...>"
    const parts = label.split(/\s+by\s+/i);
    return parts[0]?.trim() || label.trim();
}

function parseChannelFromAriaLabel(label) {
    if (!label) return '';
    const m = label.match(/\sby\s+(.+?)(?:\s+(?:\d+[\d,]*\s+views|\d+[\d,]*\s+watching|\d+\s+(?:minutes?|hours?|days?|weeks?|months?|years?)\s+ago)\b|$)/i);
    return m?.[1]?.trim() || '';
}

function normalizeText(value) {
    if (!value) return '';
    return String(value).replace(/\s+/g, ' ').trim();
}

function normalizeBrainIndex(index, length) {
    const n = typeof index === 'string' ? Number.parseInt(index, 10) : index;
    if (typeof n !== 'number' || !Number.isFinite(n)) return null;
    if (n >= 0 && n < length) return n;
    // Many LLMs respond with 1-based indices when given a numbered list.
    if (n >= 1 && n <= length) return n - 1;
    return null;
}

function normalizeBrainBoolean(value) {
    if (value === true) return true;
    if (value === false) return false;
    if (typeof value === 'number') return value === 1;
    if (typeof value === 'string') {
        const v = value.trim().toLowerCase();
        if (v === 'true') return true;
        if (v === 'false') return false;
        if (v === 'yes') return true;
        if (v === 'no') return false;
        if (v === '1') return true;
        if (v === '0') return false;
    }
    return false;
}

function resolveBrainRelevant(result) {
    if (!result || typeof result !== 'object') return null;

    const data = result.data || {};
    if (Object.prototype.hasOwnProperty.call(data, 'relevant')) {
        return normalizeBrainBoolean(data.relevant);
    }

    if (Object.prototype.hasOwnProperty.call(data, 'isRelevant')) {
        return normalizeBrainBoolean(data.isRelevant);
    }

    if (Object.prototype.hasOwnProperty.call(data, 'isMatch')) {
        return normalizeBrainBoolean(data.isMatch);
    }

    if (Object.prototype.hasOwnProperty.call(data, 'match')) {
        return normalizeBrainBoolean(data.match);
    }

    if (typeof result.decision === 'string') {
        const decision = result.decision.trim().toLowerCase();
        if (decision === 'approve') return true;
        if (decision === 'reject') return false;
    }

    if (Number.isFinite(data.score)) {
        return data.score >= 60;
    }

    return null;
}

function normalizeBrainScore(value) {
    const n = typeof value === 'string' ? Number.parseFloat(value) : value;
    if (typeof n !== 'number' || !Number.isFinite(n)) return 0;
    return Math.max(0, Math.min(100, Math.round(n)));
}

function formatCategoryForBrain(category, keywords) {
    const map = {
        tech: 'Tech & Programming',
        gaming: 'Gaming',
        finance: 'Finance & Crypto',
        fitness: 'Fitness & Health',
        business: 'Business & Entrepreneurship',
        education: 'Education',
        entertainment: 'Entertainment',
        music: 'Music'
    };

    if (!category) return 'None';

    // Handle custom categories
    if (category.startsWith('custom_')) {
        const categoryName = category.replace('custom_', '').replace(/_/g, ' ');
        const kw = Array.isArray(keywords) ? keywords.filter(Boolean).slice(0, 25) : [];
        return kw.length ? `${categoryName} (keywords: ${kw.join(', ')})` : categoryName;
    }

    if (category === 'custom') {
        const kw = Array.isArray(keywords) ? keywords.filter(Boolean).slice(0, 25) : [];
        return kw.length ? `Custom (keywords: ${kw.join(', ')})` : 'Custom';
    }

    return map[category] || category;
}

// ============================================
// Auto-Cycle (Watch 1-2 min, return home, pick next)
// ============================================

function loadCycleState() {
    try {
        const raw = sessionStorage.getItem(SESSION_KEYS.cycle);
        if (!raw) return null;
        const state = JSON.parse(raw);
        if (!state || typeof state !== 'object') return null;
        return state;
    } catch {
        return null;
    }
}

function saveCycleState(state) {
    try {
        sessionStorage.setItem(SESSION_KEYS.cycle, JSON.stringify(state));
    } catch {
        // ignore
    }
}

function createCycleState({
    keywords,
    category,
    useBrain,
    cycleMinMs,
    cycleMaxMs,
    commentAssist,
    maxCommentsPerSession,
    commentCooldownMinMs,
    commentCooldownMaxMs,
    targetCycles
}) {
    const min = normalizeCycleMs(cycleMinMs, 60_000);
    const max = normalizeCycleMs(cycleMaxMs, 120_000);
    const minMs = Math.min(min, max);
    const maxMs = Math.max(min, max);

    // The session ends when all cycles are done; endsAt is only a safety cap.
    const cycles = Number.isFinite(targetCycles)
        ? Math.max(CONFIG.humanCycle.targetCycles, Math.min(10, Math.floor(targetCycles)))
        : CONFIG.humanCycle.targetCycles;
    const sessionMs = Math.round(cycles * CONFIG.humanCycle.maxHoursPerCycle * 60 * 60_000);

    const commentCooldownMin = normalizeCycleMs(commentCooldownMinMs, 8 * 60_000);
    const commentCooldownMax = normalizeCycleMs(commentCooldownMaxMs, 15 * 60_000);
    const commentCooldownMinFinal = Math.min(commentCooldownMin, commentCooldownMax);
    const commentCooldownMaxFinal = Math.max(commentCooldownMin, commentCooldownMax);

    const maxComments =
        typeof maxCommentsPerSession === 'number' && Number.isFinite(maxCommentsPerSession)
            ? Math.max(1, Math.floor(maxCommentsPerSession))
            : 9999;

    const maxVideosForSession = randomIntInclusive(
        CONFIG.session.minVideos,
        CONFIG.session.maxVideos
    );

    const state = {
        version: 5,
        active: true,
        targetCycles: cycles,
        cyclesCompleted: 0,
        createdAt: Date.now(),
        endsAt: Date.now() + sessionMs,
        maxVideos: maxVideosForSession,
        category: category || '',
        keywords: Array.isArray(keywords) ? keywords : [],
        useBrain: useBrain !== false,
        cycleMinMs: minMs,
        cycleMaxMs: maxMs,

        // Navigation
        returnAt: 0,
        watchedKeys: [],
        lastPickedKey: '',
        lastPickedUrl: '',
        lastPickedAt: 0,
        lastPickedTitle: '',
        lastPickedChannel: '',
        lastPickedHashtags: [],
        lastPickedIsLive: false,
        lastPickedDurationSeconds: 0,
        lastPickedDurationText: '',
        totalWatched: 0,

        // Phase tracking (home_feed x3 -> search x2 -> repeat)
        cyclePhase: 'home_feed',
        phaseVideosWatched: 0,
        searchQueries: [],
        currentSearchQueryIndex: 0,
        homeVideosBeforeSearch: 3,
        searchVideosBeforeSwitch: 2,
        homeBlockTitles: [],

        // Scan tracking
        lastScannedIndex: 0,
        noMatchRetries: 0,

        // Engagement counters
        likeCounter: 0,
        shareCounter: 0,
        subscribeCounter: 0,
        nextCommentAt: CONFIG.engagement.commentEveryMin,
        nextLikeAt: CONFIG.engagement.likeEveryMin,
        nextShareAt: CONFIG.engagement.shareEvery,
        nextSubscribeAt: CONFIG.engagement.subscribeEvery,
        lastEngagementKey: '',
        likedKeys: [],
        sharedKeys: [],
        subscribedChannels: [],

        // Comment automation
        commentAssist: commentAssist === true,
        maxCommentsPerSession: maxComments,
        commentsMade: 0,
        nextCommentAllowedAt: 0,
        commentCooldownMinMs: commentCooldownMinFinal,
        commentCooldownMaxMs: commentCooldownMaxFinal,
        commentedKeys: [],
        commentedChannels: []
    };
    resetCycleProgress(state);
    return state;
}

/**
 * Reset everything that is tracked per cycle (home -> channels -> shorts).
 */
function resetCycleProgress(state) {
    const hc = CONFIG.humanCycle;
    state.cyclePhase = 'home_feed';
    state.phaseVideosWatched = 0;
    state.homeTarget = randomIntInclusive(hc.homeVideosMin, hc.homeVideosMax);
    state.homeBlockTitles = [];
    state.longformTargetMs = randomIntInclusive(hc.longformMinMinutes, hc.longformMaxMinutes) * 60_000;
    state.longformWatchedMs = 0;
    state.currentChannelUrl = '';
    state.currentChannelName = '';
    state.channelVideoTarget = 0;
    state.channelVideosWatched = 0;
    state.channelVideosMissed = 0;
    state.visitedChannels = Array.isArray(state.visitedChannels) ? state.visitedChannels : [];
    state.usedQueries = Array.isArray(state.usedQueries) ? state.usedQueries.slice(-30) : [];
    state.shortsEndsAt = 0;
    state.shortsWatched = 0;
    state.shortsSinceSearch = 0;
    state.shortsResearchAt = randomIntInclusive(hc.shortsResearchMin, hc.shortsResearchMax);
    state.cycleComments = 0;
    state.videosSinceComment = CONFIG.engagement.minVideosBetweenComments;
    state.lastScannedIndex = 0;
    state.noMatchRetries = 0;
    state.returnAt = 0;
    return state;
}

function recordCyclePick(video) {
    const state = loadCycleState();
    if (!state || state.active !== true) return;

    const key = video?.key || getVideoKeyFromUrl(video?.url);
    if (!key) return;

    const alreadyWatched = Array.isArray(state.watchedKeys) && state.watchedKeys.includes(key);

    state.watchedKeys = addWatchedKey(state.watchedKeys, key);
    state.lastPickedKey = key;
    state.lastPickedUrl = video?.url || state.lastPickedUrl;
    state.lastPickedAt = Date.now();

    if (video?.title) state.lastPickedTitle = video.title;
    if (video?.channel) state.lastPickedChannel = video.channel;
    if (Array.isArray(video?.hashtags)) state.lastPickedHashtags = video.hashtags;
    state.lastPickedIsLive = video?.isLive === true;
    if (Number.isFinite(video?.durationSeconds)) {
        state.lastPickedDurationSeconds = Math.floor(video.durationSeconds);
        state.lastPickedDurationText = video?.durationText || '';
    }

    if (!alreadyWatched) {
        state.totalWatched = Number.isFinite(state.totalWatched) ? state.totalWatched + 1 : 1;
        state.likeCounter = Number.isFinite(state.likeCounter) ? state.likeCounter + 1 : 1;
        state.shareCounter = Number.isFinite(state.shareCounter) ? state.shareCounter + 1 : 1;
        state.subscribeCounter = Number.isFinite(state.subscribeCounter) ? state.subscribeCounter + 1 : 1;
        state.lastEngagementKey = '';

        if ((state.cyclePhase || 'home_feed') === 'home_feed' && typeof video?.title === 'string') {
            state.homeBlockTitles = addRecentText(state.homeBlockTitles, video.title, 12);
        }
    }

    saveCycleState(state);
}

function deactivateCycle(reason) {
    const state = loadCycleState();
    if (!state) return;
    state.active = false;
    state.stoppedAt = Date.now();
    state.stopReason = reason || '';
    saveCycleState(state);
    clearSessionEndTimer();
}

function addWatchedKey(watchedKeys, key) {
    const out = Array.isArray(watchedKeys) ? watchedKeys.slice() : [];
    if (!key) return out;

    if (!out.includes(key)) out.push(key);

    const cap = 200;
    if (out.length > cap) {
        out.splice(0, out.length - cap);
    }

    return out;
}

function addRecentText(list, value, cap = 12) {
    const out = Array.isArray(list) ? list.slice() : [];
    const text = String(value || '').trim();
    if (!text) return out;

    out.push(text);

    const limit = Number.isFinite(cap) ? Math.max(1, Math.floor(cap)) : 12;
    if (out.length > limit) {
        out.splice(0, out.length - limit);
    }

    return out;
}

function normalizeCycleMs(value, fallback) {
    if (typeof value !== 'number' || !Number.isFinite(value)) return fallback;
    if (value < 1_000) return fallback;
    return Math.floor(value);
}

function randomIntInclusive(min, max) {
    const a = Math.ceil(min);
    const b = Math.floor(max);
    if (b <= a) return a;
    return Math.floor(Math.random() * (b - a + 1)) + a;
}

function getVideoKeyFromUrl(url) {
    if (!url) return '';
    try {
        const u = new URL(url, window.location.origin);
        if (u.pathname === '/watch') {
            const v = u.searchParams.get('v');
            return v ? `watch:${v}` : '';
        }
        if (u.pathname.startsWith('/live/')) {
            const id = u.pathname.replace(/^\/live\//, '').split('/')[0];
            return id ? `live:${id}` : '';
        }
    } catch {
        return '';
    }
    return '';
}

function isWatchLikePage() {
    return window.location.pathname === '/watch' || window.location.pathname.startsWith('/live/');
}

function isPlaybackPage() {
    return isWatchLikePage() || window.location.pathname.startsWith('/shorts/');
}

function isSessionExpired(state) {
    return Boolean(state?.endsAt) && Date.now() >= state.endsAt;
}

function getCurrentVideoKeyFromPage() {
    return getVideoKeyFromUrl(window.location.href);
}

function getVideoDurationSecondsFromPlayer() {
    const video = document.querySelector('video');
    if (video && Number.isFinite(video.duration) && video.duration > 0) {
        return Math.floor(video.duration);
    }

    const durationText = normalizeText(document.querySelector('.ytp-time-duration')?.textContent);
    const parsed = parseDurationText(durationText);
    return parsed?.durationSeconds || null;
}

function getBestDurationSeconds(state) {
    const fromState =
        Number.isFinite(state?.lastPickedDurationSeconds) && state.lastPickedDurationSeconds > 0
            ? state.lastPickedDurationSeconds
            : null;
    if (fromState) return fromState;

    const fromPlayer = getVideoDurationSecondsFromPlayer();
    if (Number.isFinite(fromPlayer) && fromPlayer > 0 && state) {
        state.lastPickedDurationSeconds = Math.floor(fromPlayer);
        saveCycleState(state);
    }
    return fromPlayer;
}

function randomFloat(min, max) {
    if (max <= min) return min;
    return Math.random() * (max - min) + min;
}

function pickWatchSeconds(state, durationSeconds) {
    // Watch a random slice of the video, like a viewer who leaves part-way.
    // Most sessions stop early, some watch nearly everything, a few bail fast.
    const hc = CONFIG.humanCycle;
    const onChannel = state?.cyclePhase === 'channel_videos';
    const minPct = onChannel ? hc.channelWatchPctMin : hc.homeWatchPctMin;
    const maxPct = onChannel ? hc.channelWatchPctMax : hc.homeWatchPctMax;

    if (Number.isFinite(durationSeconds) && durationSeconds > 0) {
        const roll = Math.random();
        let pct;

        if (roll < 0.12) {
            // Bailed out early: the thumbnail oversold it.
            pct = randomFloat(0.08, 0.22);
        } else if (roll < 0.82) {
            pct = randomFloat(minPct, maxPct);
        } else if (roll < 0.95) {
            // Watched most of it.
            pct = randomFloat(0.7, 0.95);
        } else {
            // Watched it through, maybe a little past the end.
            pct = randomFloat(0.97, 1.02);
        }

        const watchSeconds = Math.round(durationSeconds * pct);
        return Math.max(CONFIG.watch.minWatchSeconds, watchSeconds);
    }

    return randomIntInclusive(CONFIG.watch.unknownDurationSecondsMin, CONFIG.watch.unknownDurationSecondsMax);
}

function getWatchDurationMs(state, durationSeconds) {
    const watchSeconds = pickWatchSeconds(state, durationSeconds);
    if (Number.isFinite(watchSeconds) && watchSeconds > 0) {
        return watchSeconds * 1000;
    }

    return randomIntInclusive(
        CONFIG.watch.unknownDurationSecondsMin * 1000,
        CONFIG.watch.unknownDurationSecondsMax * 1000
    );
}

function maybeContinueCycle() {
    const state = loadCycleState();
    if (!state || state.active !== true) return;

    if (!automationEnabled || stopRequested) return;
    if (openInProgress) return;
    if (isSessionExpired(state)) {
        stopAutomationNow('session_end');
        return;
    }

    // Stop when max video count reached
    const maxVids = Number.isFinite(state.maxVideos) ? state.maxVideos : CONFIG.session.maxVideos;
    if (Number.isFinite(state.totalWatched) && state.totalWatched >= maxVids) {
        logActivity(`Session complete: watched ${state.totalWatched}/${maxVids} videos`, 'success');
        stopAutomationNow('max_videos_reached');
        return;
    }

    scheduleSessionEnd(state);

    if (!isWatchLikePage()) {
        clearCycleReturnTimer();
        clearEngagementTimers();
    }

    const currentPhase = normalizeCyclePhase(state);

    if (isShortsPage()) {
        if (currentPhase === 'shorts') {
            void runShortsLoop();
        }
        return;
    }

    if (isChannelVideosPage()) {
        if (cycleScanInProgress) return;
        if (currentPhase !== 'channel_videos') return;
        const loc = `${window.location.pathname}${window.location.search}`;
        if (cycleLastAutoScanLocation === loc) return;
        void runChannelVideosScan(state, loc);
        return;
    }

    if (isWatchLikePage()) {
        scheduleCycleReturn(state);
        // Engagement happens at END of watching (before returning home)
        return;
    }

    if (isYouTubeHomeFeed()) {
        if (cycleScanInProgress) return;
        // If we're already waiting on a scheduled refresh, don't start another scan.
        if (cycleHomeRefreshTimerId) return;

        const loc = `${window.location.pathname}${window.location.search}`;
        const phase = state.cyclePhase || 'home_feed';

        // Force rescan if just navigated from video (has timestamp param)
        const justNavigated = loc.includes('?t=');
        if (justNavigated) {
            console.log('[Niche Filter] Just navigated from video - forcing new scan');
            cycleLastAutoScanLocation = ''; // Force new scan
        }

        // Force rescan if flag is set (e.g., after ad-related page reload)
        try {
            const forceFlag = sessionStorage.getItem(SESSION_KEYS.forceScanOnLoad);
            if (forceFlag === '1') {
                console.log('[Niche Filter] Force scan flag detected - forcing new scan');
                sessionStorage.removeItem(SESSION_KEYS.forceScanOnLoad);
                cycleLastAutoScanLocation = ''; // Force new scan
            }
        } catch {
            // ignore
        }

        // Channel / Shorts phases start from the home page, like a person typing in the search bar.
        if (phase === 'channel_search' || phase === 'shorts' || phase === 'channel_videos') {
            if (cycleLastAutoScanLocation === loc) return;
            cycleLastAutoScanLocation = loc;
            if (phase === 'shorts') {
                void startShortsSearch(state);
            } else {
                void startChannelSearch(state);
            }
            return;
        }

        if (cycleLastAutoScanLocation === loc) return;
        // Set location AFTER scan succeeds (inside runCycleScan) to allow retries on failure
        console.log('[Niche Filter] Starting home feed scan (phase: home_feed)');
        runCycleScan(state, loc);
    }

    // Handle YouTube search page
    if (isYouTubeSearchPage()) {
        if (cycleScanInProgress) return;

        const phase = state.cyclePhase || 'home_feed';
        const loc = `${window.location.pathname}${window.location.search}`;
        if (cycleLastAutoScanLocation === loc) return;

        if (phase === 'channel_search') {
            void runChannelSearchScan(state, loc);
        } else if (phase === 'shorts') {
            void runShortsSearchScan(state, loc);
        }
    }
}

/**
 * Map phases from older saved sessions onto the current cycle phases.
 */
function normalizeCyclePhase(state) {
    const phase = state.cyclePhase || 'home_feed';
    if (phase === 'search' || phase === 'sidebar') {
        state.cyclePhase = 'channel_search';
        saveCycleState(state);
        return state.cyclePhase;
    }
    return phase;
}

function scheduleCycleReturn(state) {
    if (!isWatchLikePage()) return;
    const currentKey = getCurrentVideoKeyFromPage();
    if (!currentKey) return;

    if (state.lastPickedKey && state.lastPickedKey !== currentKey) {
        return;
    }

    if (cycleReturning) return;
    if (cycleReturnTimerId && cycleReturnVideoKey === currentKey) return;
    if (cycleReturnTimerId && cycleReturnVideoKey !== currentKey) {
        clearCycleReturnTimer();
    }

    if (isSessionExpired(state)) {
        stopAutomationNow('session_end');
        return;
    }

    const durationSeconds = getBestDurationSeconds(state);
    const delayMs = getWatchDurationMs(state, durationSeconds);
    const watchPct = Number.isFinite(durationSeconds) && durationSeconds > 0
        ? Math.round((delayMs / 1000 / durationSeconds) * 100)
        : null;

    notifyScanProgress({
        stage: 'watching',
        title: state.lastPickedTitle || '',
        totalScanned: 0
    });

    // Start ad monitoring while watching
    startAdMonitoring();

    // Behave like a viewer while the video plays (pause/resume, seek back,
    // hover the player, scroll to comments, idle micro-movement).
    HUMAN.watchBehavior();
    HUMAN.presence();

    cycleReturnTimerId = setTimeout(async () => {
        cycleReturnTimerId = null;
        cycleReturning = true;
        HUMAN.stopWatchBehavior();

        const st = loadCycleState();
        if (!st || st.active !== true) {
            cycleReturning = false;
            return;
        }
        if (isSessionExpired(st)) {
            stopAutomationNow('session_end');
            return;
        }
        if (!isWatchLikePage()) {
            cycleReturning = false;
            return;
        }

        const currentKey = getCurrentVideoKeyFromPage();

        // Occasionally step away for a few minutes before engaging.
        if (HUMAN.shouldTakeBreak()) {
            logActivity('Taking a short break...', 'info');
            await HUMAN.takeBreak();
        }

        // Engagement at the end of watching (before leaving the video)
        if (shouldDoLikeNow(st, currentKey)) {
            await doLikeNow(st, currentKey);
        }
        if (shouldDoCommentNow(st, currentKey)) {
            await doCommentNow(st, currentKey);
        }
        if (shouldDoShareNow(st, currentKey)) {
            await doShareNow(st, currentKey);
        }
        const currentChannel = st.currentChannelName || st.lastPickedChannel || getCurrentChannelName();
        if (shouldDoSubscribeNow(st, currentChannel)) {
            await doSubscribeNow(st, currentChannel);
        }

        stopAdMonitoring();
        // Reset ad refresh counter (prevent false detections on home feed)
        resetAdRefreshCount();

        await recordVideoWatched(Math.floor(delayMs / 1000));

        st.longformWatchedMs = (st.longformWatchedMs || 0) + delayMs;
        st.videosSinceComment = (st.videosSinceComment || 0) + 1;
        cycleLastAutoScanLocation = '';
        st.lastScannedIndex = 0;
        st.noMatchRetries = 0;

        advanceLongformPhase(st);
        // Hold the guard briefly so the watchdog can't restart the watch timer
        // while the navigation is still in flight.
        setTimeout(() => {
            cycleReturning = false;
        }, 3_000);
    }, delayMs);

    cycleReturnVideoKey = currentKey;
    state.returnAt = Date.now() + delayMs;
    saveCycleState(state);

    const minutes = Math.floor(delayMs / 60000);
    const seconds = Math.round((delayMs % 60000) / 1000);
    const videoTitle = state.lastPickedTitle ? truncateText(state.lastPickedTitle, 50) : 'video';
    logActivity(`Watching: ${videoTitle}`, 'watch');
    logActivity(
        `Watching ${minutes}:${String(seconds).padStart(2, '0')}${watchPct ? ` (~${watchPct}% of video)` : ''}`,
        'timer'
    );
    console.log(`[Niche Filter] Cycle: watching for ${minutes}m ${seconds}s, then returning home`);
}

// ============================================
// Engagement Helper Functions (at END of watching)
// ============================================

function shouldDoCommentNow(state, key) {
    if (!state.commentAssist) return false;
    if (Array.isArray(state.commentedKeys) && state.commentedKeys.includes(key)) return false;
    const eng = CONFIG.engagement;
    if ((state.cycleComments || 0) >= eng.maxCommentsPerCycle) return false;
    if ((state.videosSinceComment || 0) < eng.minVideosBetweenComments) return false;
    return Math.random() < eng.commentChance * HUMAN.warmupFactor();
}

async function doCommentNow(state, key) {
    const title = getCurrentVideoTitle() || state.lastPickedTitle || '';
    const description = getCurrentVideoDescription();

    logActivity('Generating AI comment...', 'brain');
    const styles = CONFIG.engagement.commentStyles;
    const comment = await generateCommentText({
        title,
        description,
        category: state.category || '',
        keywords: state.keywords || [],
        style: styles[randomIntInclusive(0, styles.length - 1)]
    });

    if (!comment) {
        logActivity('Failed to generate comment', 'error');
        return;
    }

    // Try posting with 2 retries
    let success = false;
    for (let attempt = 1; attempt <= 3; attempt++) {
        if (attempt === 1) {
            logActivity(`Posting comment (attempt ${attempt}/3)...`, 'action');
        } else {
            logActivity(`Retrying comment post (attempt ${attempt}/3)...`, 'action');
        }

        success = await postComment(comment);

        if (success) {
            state.commentedKeys = addUniqueKey(state.commentedKeys, key, 200);
            state.commentsMade = (state.commentsMade || 0) + 1;
            state.cycleComments = (state.cycleComments || 0) + 1;
            state.videosSinceComment = 0;
            saveCycleState(state);
            await recordComment();
            logActivity('Comment posted successfully!', 'success');
            await sleep(1000);
            return;
        }

        if (attempt < 3) {
            await sleep(1500); // Wait before retry
        }
    }

    // All retries failed
    logActivity('Comment posting failed after 3 attempts', 'error');
}

function shouldDoLikeNow(state, key) {
    if (Array.isArray(state.likedKeys) && state.likedKeys.includes(key)) return false;
    return Math.random() < CONFIG.engagement.likeChance * HUMAN.warmupFactor();
}

async function doLikeNow(state, key) {
    logActivity('Liking video...', 'action');
    const success = await tryLikeCurrentVideo();
    if (success) {
        state.likedKeys = addUniqueKey(state.likedKeys, key, 200);
        saveCycleState(state);
        await recordLike();
        logActivity('Video liked successfully!', 'success');
        await sleep(500);
    } else {
        logActivity('Like skipped (button not found or already liked)', 'info');
    }
}

function shouldDoShareNow(state, key) {
    if (Array.isArray(state.sharedKeys) && state.sharedKeys.includes(key)) return false;
    return Math.random() < CONFIG.engagement.shareChance;
}

async function doShareNow(state, key) {
    logActivity('Sharing video (copying link)...', 'action');
    const success = await tryShareCurrentVideo();
    if (success) {
        state.sharedKeys = addUniqueKey(state.sharedKeys, key, 50);
        saveCycleState(state);
        await recordShare();
        logActivity('Video link copied successfully!', 'success');
        await sleep(1000);
    } else {
        logActivity('Share skipped (button not found)', 'info');
    }
}

function shouldDoSubscribeNow(state, channel) {
    if (!channel) return false;
    if (Array.isArray(state.subscribedChannels) && state.subscribedChannels.includes(channel)) return false;
    // Only subscribe after finishing the last video of a top channel we searched for.
    if (state.cyclePhase !== 'channel_videos') return false;
    const target = state.channelVideoTarget || CONFIG.humanCycle.channelVideosMin;
    if ((state.channelVideosWatched || 0) + 1 < target) return false;
    return Math.random() < CONFIG.engagement.channelSubscribeChance;
}

async function doSubscribeNow(state, channel) {
    logActivity(`Subscribing to: ${truncateText(channel, 30)}...`, 'action');
    const success = await trySubscribeToChannel();
    if (success) {
        state.subscribedChannels = addUniqueKey(state.subscribedChannels, channel, 100);
        saveCycleState(state);
        await recordSubscribe();
        logActivity('Subscribed successfully!', 'success');
        await sleep(1000);
    } else {
        logActivity('Subscribe skipped (already subscribed or button not found)', 'info');
    }
}

// Scheduled engagement system removed - all engagement happens at END of watching

async function generateCommentText({ title, description, category, keywords, style }) {
    try {
        const response = await chrome.runtime.sendMessage({
            action: 'brainGenerateComment',
            title,
            description: truncateText(description, 1200),
            category,
            keywords,
            style
        });

        if (!response?.success) return null;
        const comment = response.result?.data?.comment;
        if (typeof comment !== 'string') return null;
        const cleaned = comment.replace(/\s+/g, ' ').trim();
        return cleaned.length ? cleaned : null;
    } catch (error) {
        console.warn('[Niche Filter] Comment generation failed:', error);
        return null;
    }
}

/**
 * Find the comment box by scrolling to comments section
 * Returns null if comments are disabled
 */
async function findCommentBox() {
    // Check if comments are disabled first
    if (areCommentsDisabled()) {
        return null;
    }

    // Strategy 1: Already visible
    let box = document.querySelector('ytd-comment-simplebox-renderer');
    if (box) return box;

    // Strategy 2: Scroll to comments section
    const commentsSection = document.querySelector('#comments');
    if (commentsSection) {
        await HUMAN.scrollToElement(commentsSection);
        await sleep(HUMAN.randInt(400, 900));
        box = document.querySelector('ytd-comment-simplebox-renderer');
        if (box) return box;
    }

    // Strategy 3: Scroll down once to trigger lazy loading
    await HUMAN.scrollBy(HUMAN.randInt(450, 800));
    await sleep(HUMAN.randInt(400, 900));

    box = document.querySelector('ytd-comment-simplebox-renderer');
    if (box) return box;

    return null;
}

/**
 * Check if comments are disabled for the current video
 */
function areCommentsDisabled() {
    // Check for "Comments are turned off" message
    const disabledSelectors = [
        'ytd-message-renderer',
        '#message',
        'yt-formatted-string.message'
    ];

    for (const selector of disabledSelectors) {
        const elements = document.querySelectorAll(selector);
        for (const el of elements) {
            const text = (el.textContent || '').toLowerCase();
            if (text.includes('comments are turned off') ||
                text.includes('comments have been turned off') ||
                text.includes('comments are disabled') ||
                text.includes('comments disabled')) {
                return true;
            }
        }
    }

    // Check if comments section exists but is empty/hidden
    const commentsSection = document.querySelector('#comments');
    if (commentsSection) {
        const style = window.getComputedStyle(commentsSection);
        if (style.display === 'none' || style.visibility === 'hidden') {
            return true;
        }
    }

    return false;
}

async function postComment(commentText) {
    const cleaned = truncateText(String(commentText || '').trim(), 100);
    if (!cleaned) {
        console.warn('[Niche Filter] Comment text is empty');
        return false;
    }

    // Check if comments are disabled FIRST
    if (areCommentsDisabled()) {
        console.log('[Niche Filter] Comments are disabled for this video');
        return false;
    }

    // Find comment box
    const commentBox = await findCommentBox();
    if (!commentBox) {
        console.warn('[Niche Filter] Comment box not found');
        return false;
    }

    try {
        // Scroll to comment box
        try {
            await HUMAN.scrollToElement(commentBox);
        } catch {
            // ignore
        }
        await sleep(HUMAN.randInt(250, 650));

        // Click placeholder to expand
        const placeholder = commentBox.querySelector('#placeholder-area');
        if (placeholder) {
            await HUMAN.click(placeholder, { missChance: 0.03 });
            await sleep(HUMAN.randInt(350, 900));
        }

        // Find input field
        const input = commentBox.querySelector('#contenteditable-root');
        if (!input) {
            console.warn('[Niche Filter] Comment input field not found');
            return false;
        }

        // Type it out character by character so the composer sees real keystrokes.
        await HUMAN.type(input, cleaned, { wpm: HUMAN.rand(52, 84), typoRate: 0.02 });
        await sleep(HUMAN.randInt(400, 1_100));

        // Find and click submit button
        const submitButton =
            commentBox.querySelector('ytd-button-renderer#submit-button button') ||
            commentBox.querySelector('#submit-button button') ||
            commentBox.querySelector('button#submit-button');

        if (!submitButton || submitButton.disabled) {
            console.warn('[Niche Filter] Submit button not found or disabled');
            return false;
        }

        await HUMAN.click(submitButton, { missChance: 0.02 });
        console.log('[Niche Filter] Comment posted:', cleaned);
        return true;

    } catch (error) {
        console.error('[Niche Filter] Error posting comment:', error);
        return false;
    }
}

async function tryLikeCurrentVideo() {
    const button = findLikeButton();
    if (!button) {
        console.log('[Niche Filter] Like button not found');
        return false;
    }

    if (isLikeButtonPressed(button)) {
        console.log('[Niche Filter] Video already liked');
        return false;
    }

    try {
        await HUMAN.click(button, { missChance: 0.05 });
        console.log('[Niche Filter] Video liked');
        return true;
    } catch (error) {
        console.error('[Niche Filter] Error clicking like button:', error);
        return false;
    }
}

function findLikeButton() {
    const candidates = Array.from(document.querySelectorAll('button[aria-label]'));
    return candidates.find(btn => {
        const label = String(btn.getAttribute('aria-label') || '').toLowerCase();
        if (!label) return false;
        if (label.includes('dislike')) return false;
        return label.includes('like');
    }) || null;
}

function isLikeButtonPressed(button) {
    const pressed = button.getAttribute('aria-pressed');
    if (pressed === 'true') return true;

    const label = String(button.getAttribute('aria-label') || '').toLowerCase();
    return label.includes('unlike');
}

/**
 * Share the current video by clicking share button and copying link
 */
async function tryShareCurrentVideo() {
    try {
        // Find the share button
        const shareButton = findShareButton();
        if (!shareButton) {
            console.log('[Niche Filter] Share button not found');
            return false;
        }

        // Click share button
        await HUMAN.click(shareButton, { missChance: 0.04 });
        await sleep(HUMAN.randInt(700, 1_400));

        // Find and click "Copy link" button in the share dialog
        const copyLinkButton = findCopyLinkButton();
        if (!copyLinkButton) {
            console.log('[Niche Filter] Copy link button not found');
            closeShareDialog();
            return false;
        }

        await HUMAN.click(copyLinkButton, { missChance: 0.03 });
        await sleep(HUMAN.randInt(400, 900));

        // Close dialog
        closeShareDialog();

        console.log('[Niche Filter] Video link copied');
        return true;
    } catch (error) {
        console.error('[Niche Filter] Share error:', error.message);
        closeShareDialog();
        return false;
    }
}

function findShareButton() {
    const selectors = [
        'button[aria-label="Share"]',
        'button[aria-label*="share" i]',
        '#top-level-buttons-computed button[aria-label*="Share"]',
        'ytd-menu-renderer button[aria-label*="Share"]',
        '.ytd-video-primary-info-renderer button[aria-label*="Share"]',
        'ytd-button-renderer[button-renderer] button[aria-label*="Share"]'
    ];

    for (const selector of selectors) {
        const btn = document.querySelector(selector);
        if (btn) return btn;
    }
    return null;
}

function findCopyLinkButton() {
    const selectors = [
        'button[aria-label="Copy link"]',
        'button[aria-label*="Copy" i]',
        'yt-button-renderer[aria-label*="Copy"]',
        '.yt-spec-button-shape-next[aria-label*="Copy"]'
    ];

    for (const selector of selectors) {
        const btn = document.querySelector(selector);
        if (btn) return btn;
    }

    // Fallback: find by text content
    const buttons = document.querySelectorAll('button, yt-button-renderer, a');
    for (const btn of buttons) {
        const text = (btn.textContent || '').toLowerCase();
        if (text.includes('copy')) return btn;
    }

    return null;
}

function closeShareDialog() {
    try {
        // Try to close any open dialog
        const closeSelectors = [
            'button[aria-label="Close"]',
            'button[aria-label="Cancel"]',
            '.yt-dialog-close-button',
            'tp-yt-paper-dialog button[aria-label="Close"]',
            'ytd-unified-share-panel-renderer button[aria-label="Close"]'
        ];

        for (const selector of closeSelectors) {
            const btn = document.querySelector(selector);
            if (btn) {
                void HUMAN.click(btn, { missChance: 0.02 });
                return;
            }
        }

        // Press Escape as fallback
        HUMAN.pressKey('Escape', document.body);
    } catch {
        // ignore
    }
}

/**
 * Subscribe to the current video's channel
 */
async function trySubscribeToChannel() {
    try {
        const subscribeButton = findSubscribeButton();
        if (!subscribeButton) {
            console.log('[Niche Filter] Subscribe button not found');
            return false;
        }

        // Check if already subscribed
        if (isAlreadySubscribed(subscribeButton)) {
            console.log('[Niche Filter] Already subscribed to this channel');
            return false;
        }

        // Click subscribe
        await HUMAN.click(subscribeButton, { missChance: 0.05 });
        await sleep(HUMAN.randInt(400, 1_000));

        console.log('[Niche Filter] Subscribed to channel');
        return true;
    } catch (error) {
        console.error('[Niche Filter] Subscribe error:', error.message);
        return false;
    }
}

function findSubscribeButton() {
    const selectors = [
        '#subscribe-button button',
        '#subscribe-button-shape button',
        'ytd-subscribe-button-renderer button',
        'button[aria-label*="Subscribe"]',
        '#subscribe-button yt-button-shape button',
        '#owner #subscribe-button button'
    ];

    for (const selector of selectors) {
        const btn = document.querySelector(selector);
        if (btn) return btn;
    }

    // Fallback: find button with "Subscribe" text
    const buttons = document.querySelectorAll('button, yt-button-shape button');
    for (const btn of buttons) {
        const text = (btn.textContent || '').toLowerCase().trim();
        const ariaLabel = (btn.getAttribute('aria-label') || '').toLowerCase();
        // Make sure it's the subscribe button, not "subscribed" or "unsubscribe"
        if ((text === 'subscribe' || ariaLabel.includes('subscribe')) &&
            !text.includes('subscribed') && !ariaLabel.includes('subscribed') &&
            !text.includes('unsubscribe') && !ariaLabel.includes('unsubscribe')) {
            return btn;
        }
    }

    return null;
}

function isAlreadySubscribed(button) {
    if (!button) return false;

    const ariaLabel = (button.getAttribute('aria-label') || '').toLowerCase();
    if (ariaLabel.includes('unsubscribe') || ariaLabel.includes('subscribed')) {
        return true;
    }

    const text = (button.textContent || '').toLowerCase().trim();
    if (text === 'subscribed' || text.includes('unsubscribe')) {
        return true;
    }

    // Check if button has "subscribed" state
    const parent = button.closest('#subscribe-button, ytd-subscribe-button-renderer');
    if (parent) {
        const subscribed = parent.getAttribute('subscribed');
        if (subscribed === '' || subscribed === 'true') return true;
    }

    return false;
}

function getCurrentChannelName() {
    const selectors = [
        '#owner #channel-name a',
        '#owner ytd-channel-name a',
        'ytd-video-owner-renderer #channel-name a',
        '#upload-info #channel-name a',
        '#owner-sub-count ~ #channel-name a',
        'a.yt-simple-endpoint[href*="/@"]',
        '#owner a[href*="/@"]'
    ];

    for (const selector of selectors) {
        const el = document.querySelector(selector);
        const text = normalizeText(el?.textContent);
        if (text) return text;
    }

    return '';
}

function getCurrentVideoTitle() {
    const selectors = [
        'h1.title yt-formatted-string',
        '#title h1 yt-formatted-string',
        'h1 yt-formatted-string',
        'h1.title',
        'h1'
    ];

    for (const selector of selectors) {
        const el = document.querySelector(selector);
        const text = normalizeText(el?.textContent);
        if (text) return text;
    }

    return '';
}

function getCurrentVideoDescription() {
    const selectors = [
        '#description-inline-expander',
        'ytd-expandable-video-description-body-renderer',
        '#description',
        'ytd-text-inline-expander'
    ];

    for (const selector of selectors) {
        const el = document.querySelector(selector);
        const text = normalizeText(el?.textContent);
        if (text) return text;
    }

    return '';
}

function truncateText(text, maxLength) {
    if (!text) return '';
    if (!Number.isFinite(maxLength) || maxLength < 1) return text;
    return text.length > maxLength ? `${text.slice(0, maxLength - 3)}...` : text;
}

function addUniqueKey(list, key, cap) {
    const out = Array.isArray(list) ? list.slice() : [];
    if (!key) return out;
    if (!out.includes(key)) out.push(key);

    if (typeof cap === 'number' && Number.isFinite(cap) && cap > 0 && out.length > cap) {
        out.splice(0, out.length - cap);
    }

    return out;
}

// ============================================
// Session Stats Tracking (Persistent)
// ============================================

async function incrementStat(statKey, amount = 1) {
    try {
        const result = await chrome.storage.local.get([statKey]);
        const current = Number.isFinite(result[statKey]) ? result[statKey] : 0;
        await chrome.storage.local.set({ [statKey]: current + amount });
    } catch (error) {
        console.warn('[Niche Filter] Failed to update stat:', statKey, error);
    }
}

async function recordVideoWatched(watchTimeSeconds) {
    await incrementStat(STATS_KEYS.totalVideosWatched, 1);
    if (Number.isFinite(watchTimeSeconds) && watchTimeSeconds > 0) {
        await incrementStat(STATS_KEYS.totalWatchTimeSeconds, Math.floor(watchTimeSeconds));
    }
}

async function recordLike() {
    await incrementStat(STATS_KEYS.totalLikes, 1);
}

async function recordComment() {
    await incrementStat(STATS_KEYS.totalComments, 1);
}

async function recordShare() {
    await incrementStat(STATS_KEYS.totalShares, 1);
}

async function recordSubscribe() {
    await incrementStat(STATS_KEYS.totalSubscribes, 1);
}

async function recordSessionStart() {
    await incrementStat(STATS_KEYS.totalSessions, 1);
    await chrome.storage.local.set({
        [STATS_KEYS.lastSessionDate]: new Date().toISOString()
    });
}

async function getAllStats() {
    try {
        const result = await chrome.storage.local.get(Object.values(STATS_KEYS));
        return {
            totalVideosWatched: result[STATS_KEYS.totalVideosWatched] || 0,
            totalLikes: result[STATS_KEYS.totalLikes] || 0,
            totalComments: result[STATS_KEYS.totalComments] || 0,
            totalShares: result[STATS_KEYS.totalShares] || 0,
            totalSubscribes: result[STATS_KEYS.totalSubscribes] || 0,
            totalWatchTimeSeconds: result[STATS_KEYS.totalWatchTimeSeconds] || 0,
            totalSessions: result[STATS_KEYS.totalSessions] || 0,
            lastSessionDate: result[STATS_KEYS.lastSessionDate] || null
        };
    } catch (error) {
        console.warn('[Niche Filter] Failed to get stats:', error);
        return null;
    }
}

async function resetAllStats() {
    try {
        const keysToRemove = Object.values(STATS_KEYS);
        await chrome.storage.local.remove(keysToRemove);
        console.log('[Niche Filter] Stats reset');
    } catch (error) {
        console.warn('[Niche Filter] Failed to reset stats:', error);
    }
}

// ============================================
// Ad Detection and Skip Handling
// ============================================

/**
 * Check if an ad is currently playing
 * STRICT DETECTION: Only returns true when we are CERTAIN an ad is playing
 * to avoid false positives that cause unnecessary page refreshes.
 */
function isAdPlaying() {
    // Extra safety: never treat the home feed as "ad playing" (prevents refresh loops).
    if (isYouTubeHomeFeed()) return false;

    // Primary signal: YouTube toggles these classes on the player during video ads.
    const player = document.querySelector('#movie_player, .html5-video-player');
    const root = player || document;
    if (player) {
        if (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting')) {
            return true;
        }
    }

    const adBadge = root.querySelector('.ytp-ad-simple-ad-badge, .ytp-ad-badge, .ytp-ad-badge__text');
    if (isElementVisible(adBadge)) {
        return true;
    }

    const adDurationRemaining = root.querySelector('.ytp-ad-duration-remaining');
    if (isElementVisible(adDurationRemaining)) {
        return true;
    }

    // Strong signal: a real "Skip ad(s)" button in the ad UI.
    if (findSkipAdButtonFast(root)) {
        return true;
    }

    const adPreview = root.querySelector('.ytp-ad-preview-container, .ytp-ad-text, .ytp-ad-preview-text');
    if (isElementVisible(adPreview)) {
        const text = (adPreview.textContent || '').trim();
        if (text && /(\bad\b|advert|sponsor|skip)/i.test(text)) {
            return true;
        }
    }

    // Fallback: some ad formats show an overlay container; treat it as an ad only if it
    // contains ad-specific descendants (prevents false positives on normal playback).
    const overlayRoot = player || document;
    const overlay = overlayRoot.querySelector('.ytp-ad-player-overlay, .ytp-ad-overlay-container, .ytp-ad-image-overlay');
    if (isElementVisible(overlay)) {
        const hasAdBits = Boolean(
            overlay.querySelector(
                '.ytp-ad-simple-ad-badge, .ytp-ad-badge, .ytp-ad-text, .ytp-ad-preview-container, .ytp-ad-preview-text, .ytp-ad-duration-remaining, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button'
            )
        );
        if (hasAdBits) return true;
    }

    return false;
}

function findSkipAdButtonFast(root) {
    const host = root || document;

    // Fast path only: avoid scanning the whole DOM on every polling tick.
    const selectors = [
        '.ytp-ad-skip-button-modern',
        'button.ytp-ad-skip-button-modern',
        '.ytp-skip-ad-button',
        'button.ytp-skip-ad-button',
        '.ytp-ad-skip-button',
        'button.ytp-ad-skip-button',
        '.videoAdUiSkipButton',
        'button.videoAdUiSkipButton',
        'button[aria-label*="Skip ad"]',
        'button[aria-label*="Skip Ad"]',
        'button[aria-label*="Skip ads"]',
        'button[aria-label*="Skip Ads"]'
    ];

    for (const selector of selectors) {
        const btn = host.querySelector(selector);
        if (!btn || !isButtonVisible(btn)) continue;
        const inAdUi = Boolean(
            btn.closest?.('.ytp-ad-player-overlay, .ytp-ad-overlay-container, .ytp-ad-skip-button-container, .video-ads')
        );
        if (!inAdUi) continue;
        return btn;
    }

    return null;
}

/**
 * Find the skip ad button if available
 * Uses comprehensive detection strategies
 */
function findSkipAdButton() {
    const root = document.querySelector('#movie_player, .html5-video-player') || document;

    // Current layout: a pill that just says "Skip" (no "ad"). While the player is in ad
    // mode, the only skip control inside it is the ad's own.
    const player = document.querySelector('#movie_player, .html5-video-player');
    if (player && (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting'))) {
        for (const btn of player.querySelectorAll('button, [role="button"]')) {
            if (!isButtonVisible(btn)) continue;
            const label = normalizeText(btn.getAttribute('aria-label') || btn.textContent).toLowerCase();
            if (/^skip\b/.test(label)) return btn;
        }
    }

    // Strategy 1: Try all known selectors
    for (const selector of AD_CONFIG.skipButtonSelectors) {
        const btn = root.querySelector(selector);
        if (btn && isButtonVisible(btn)) {
            console.log(`[Niche Filter] Skip button found with selector: ${selector}`);
            return btn;
        }
    }

    // Strategy 2: Find by text content (case-insensitive)
    const allButtons = root.querySelectorAll('button, [role="button"]');
    for (const btn of allButtons) {
        if (!isButtonVisible(btn)) continue;
        // Prevent false positives: only treat "skip ad(s)" buttons inside the ad UI as skip buttons.
        const inAdUi = Boolean(
            btn.closest?.('.ytp-ad-player-overlay, .ytp-ad-overlay-container, .ytp-ad-skip-button-container, .video-ads')
        );
        if (!inAdUi) continue;

        const text = (btn.textContent || '').toLowerCase().trim();
        const ariaLabel = (btn.getAttribute('aria-label') || '').toLowerCase();

        // Check for "Skip Ad", "Skip Ads", "Skip", etc.
        if (text.includes('skip ad') ||
            text.includes('skip ads') ||
            ariaLabel.includes('skip ad') ||
            ariaLabel.includes('skip ads')) {
            console.log(`[Niche Filter] Skip button found by text: "${text || ariaLabel}"`);
            return btn;
        }
    }

    // Strategy 3: Look inside ad overlay containers
    const adContainers = [
        '.ytp-ad-player-overlay',
        '.ytp-ad-overlay-container',
        '.ytp-ad-skip-button-container',
        '.video-ads'
    ];

    for (const containerSelector of adContainers) {
        const container = root.querySelector(containerSelector);
        if (!container) continue;

        const buttons = container.querySelectorAll('button');
        for (const btn of buttons) {
            if (!isButtonVisible(btn)) continue;

            const text = (btn.textContent || '').toLowerCase();
            if (text.includes('skip')) {
                console.log(`[Niche Filter] Skip button found in container: ${containerSelector}`);
                return btn;
            }
        }
    }

    // Strategy 4: Find by common skip button classes (partial match)
    const skipButtons = root.querySelectorAll('[class*="skip"]');
    for (const element of skipButtons) {
        if (element.tagName === 'BUTTON' && isButtonVisible(element)) {
            const inAdUi = Boolean(
                element.closest?.('.ytp-ad-player-overlay, .ytp-ad-overlay-container, .ytp-ad-skip-button-container, .video-ads')
            );
            if (!inAdUi) continue;

            const text = (element.textContent || '').toLowerCase();
            if (text.includes('skip')) {
                console.log(`[Niche Filter] Skip button found by class pattern`);
                return element;
            }
        }
    }

    return null;
}

/**
 * Check if a button is visible and clickable
 */
function isButtonVisible(button) {
    if (!isElementVisible(button)) return false;

    // Check if button is disabled
    if (button.disabled || button.getAttribute('disabled') !== null) {
        return false;
    }
    return true;
}

function isElementVisible(el) {
    if (!el) return false;

    const style = window.getComputedStyle(el);
    if (!style) return false;

    if (style.display === 'none' || style.visibility === 'hidden') return false;
    if (style.opacity === '0') return false;

    const rect = el.getBoundingClientRect?.();
    if (!rect) return false;
    if (rect.width === 0 || rect.height === 0) return false;

    return true;
}

/**
 * Get remaining ad time in seconds (if available)
 */
function getAdRemainingTime() {
    // Try to find the ad countdown timer
    const timerSelectors = [
        '.ytp-ad-duration-remaining',
        '.ytp-ad-text',
        '.ytp-ad-preview-text',
        '.ytp-ad-skip-button-text',
        '.ytp-ad-skip-button-modern__text'
    ];

    for (const selector of timerSelectors) {
        const el = document.querySelector(selector);
        if (!el) continue;

        const text = el.textContent || '';
        // Match patterns like "0:05", "5", "5 seconds", "Video will play after ad"
        const match = text.match(/(\d+):(\d+)|(\d+)\s*(?:second|sec|s)?/i);
        if (match) {
            if (match[1] && match[2]) {
                // MM:SS format
                return parseInt(match[1], 10) * 60 + parseInt(match[2], 10);
            } else if (match[3]) {
                // Just seconds
                return parseInt(match[3], 10);
            }
        }
    }

    return null;
}

/**
 * Verify that the ad was actually skipped
 */
async function verifyAdSkipped() {
    await sleep(AD_CONFIG.skipVerifyDelayMs);
    const stillPlaying = isAdPlaying();
    return !stillPlaying;
}

/**
 * Try to skip the current ad with verification
 * Returns object with found/skipped status
 */
async function trySkipAdWithVerify(skipButton = findSkipAdButton()) {

    if (!skipButton) {
        return { found: false, skipped: false };
    }

    try {
        console.log('[Niche Filter] Clicking skip button...');
        skipButton.focus?.({ preventScroll: true });
        await pressButtonLikePointer(skipButton);

        // Verify the ad was actually skipped
        let skipped = await verifyAdSkipped();

        // YouTube can ignore scripted clicks. The ad is skippable (the button is showing),
        // so finishing it has the same effect as pressing Skip.
        if (!skipped && findSkipAdButton() && finishSkippableAd()) {
            console.log('[Niche Filter] Click ignored; finished the skippable ad instead');
            skipped = await verifyAdSkipped();
        }

        if (skipped) {
            console.log('[Niche Filter] Ad successfully skipped and verified');
        } else {
            console.warn('[Niche Filter] Skip button clicked but ad still playing');
        }

        return { found: true, skipped };
    } catch (error) {
        console.warn('[Niche Filter] Failed to click skip button:', error);
        return { found: true, skipped: false };
    }
}

/**
 * Wait for skip button to appear, then keep it present for 3-5s before clicking
 * Returns the button when ready to click, or null if not found within duration
 */
/**
 * Send the pointer/mouse events a real click produces, not just click().
 */
async function pressButtonLikePointer(button) {
    await HUMAN.click(button, { missChance: 0.04 });
}

/**
 * Jump a skippable ad to its end. Only runs while the player is in ad mode with
 * a visible Skip button, so it can never touch the real video or unskippable ads.
 */
function finishSkippableAd() {
    const player = document.querySelector('#movie_player, .html5-video-player');
    if (!player || !player.classList.contains('ad-showing')) return false;
    if (!findSkipAdButton()) return false;
    const video = player.querySelector('video.html5-main-video') || player.querySelector('video');
    if (!video || !Number.isFinite(video.duration) || video.duration <= 0) return false;
    video.currentTime = Math.max(0, video.duration - 0.05);
    // The player only moves on once the ad actually plays through its last frame.
    if (video.paused) video.play().catch(() => {});
    return true;
}

async function waitForSkipButton(durationMs, checkIntervalMs) {
    const startTime = Date.now();
    let buttonSeenAt = 0;
    let clickDelayMs = 0;

    while (Date.now() - startTime < durationMs) {
        if (!automationEnabled || stopRequested) return null;
        if (!isPlaybackPage()) return null;
        // Stop waiting if the ad ended naturally.
        if (!isAdPlaying()) return null;

        const button = findSkipAdButton();
        if (button) {
            if (!buttonSeenAt) {
                buttonSeenAt = Date.now();
                clickDelayMs = randomIntInclusive(
                    AD_CONFIG.skipClickDelayMinMs,
                    AD_CONFIG.skipClickDelayMaxMs
                );
                const delaySeconds = (clickDelayMs / 1000).toFixed(1);
                console.log(`[Niche Filter] Skip button detected, waiting ${delaySeconds}s before clicking...`);
                logActivity(`Skip button detected. Clicking in ${delaySeconds}s...`, 'action');
            }

            if (Date.now() - buttonSeenAt >= clickDelayMs) {
                const readyButton = findSkipAdButton();
                if (readyButton) {
                    return readyButton;
                }

                console.warn('[Niche Filter] Skip button disappeared before delayed click, continuing to monitor...');
                buttonSeenAt = 0;
                clickDelayMs = 0;
            }
        } else {
            buttonSeenAt = 0;
            clickDelayMs = 0;
        }
        await sleep(checkIntervalMs);
    }

    return null;
}

/**
 * Wait for ad to finish playing naturally
 */
async function waitForAdToFinish() {
    const maxWait = AD_CONFIG.maxAdWaitMs;
    const startTime = Date.now();
    let lastLogTime = 0;

    console.log('[Niche Filter] Waiting for ad to finish naturally...');

    while (Date.now() - startTime < maxWait) {
        if (!isAdPlaying()) {
            console.log('[Niche Filter] Ad finished');

            // Wait a moment for video to start
            await sleep(1000);

            // Check if actual video is now playing
            const video = document.querySelector('video');
            if (isVideoPlaying(video)) {
                logActivity('Ad finished, video is now playing', 'success');
            } else {
                logActivity('Ad finished', 'info');
            }

            return true;
        }

        // Log progress every 5 seconds
        const elapsed = Date.now() - startTime;
        if (elapsed - lastLogTime >= 5000) {
            const remaining = getAdRemainingTime();
            if (remaining !== null && remaining > 0) {
                logActivity(`Watching ad... ${remaining}s remaining`, 'info');
                console.log(`[Niche Filter] Watching ad... ${remaining}s remaining`);
            } else {
                console.log(`[Niche Filter] Watching ad... ${Math.floor(elapsed / 1000)}s elapsed`);
            }
            lastLogTime = elapsed;
        }

        await sleep(1000);
    }

    console.warn('[Niche Filter] Ad wait timeout');
    return false;
}

/**
 * Handle ads by preferring a real skip-button click and only refreshing as fallback
 */
async function handleAds() {
    // CRITICAL: Never handle ads on home feed (prevents infinite refresh loop)
    if (isYouTubeHomeFeed()) {
        console.log('[Niche Filter] Ignoring ad detection - on home feed');
        return { handled: false, skipped: false };
    }

    // Only run one ad handler at a time (autoplay + monitor can overlap).
    if (adHandlingInProgress) {
        return { handled: false, skipped: false, inProgress: true };
    }
    adHandlingInProgress = true;

    try {
        // Double-check: Is this really an ad or just the video?
        if (!isAdPlaying()) {
            return { handled: false, skipped: false };
        }
        // Reduce false positives from transient DOM/class flickers.
        await sleep(300);
        if (!isAdPlaying()) {
            return { handled: false, skipped: false };
        }

        console.log('[Niche Filter] Ad detected - waiting for skip button');
        logActivity('Ad detected', 'action');

        // 1) Try to SKIP (preferred). Some ads enable the skip button after a delay,
        // so we wait for it to appear (or for the ad to end).
        const skipButton = await waitForSkipButton(
            AD_CONFIG.buttonCheckDurationMs,
            AD_CONFIG.buttonCheckIntervalMs
        );

        if (skipButton) {
            for (let attempt = 1; attempt <= AD_CONFIG.maxSkipRetries; attempt++) {
                if (!isAdPlaying()) {
                    resetAdRefreshCount();
                    await tryStartPlayback();
                    return { handled: true, skipped: false };
                }

                const currentSkipButton = attempt === 1 ? skipButton : findSkipAdButton();
                const result = await trySkipAdWithVerify(currentSkipButton);
                if (result.skipped) {
                    resetAdRefreshCount();
                    await sleep(500);
                    await tryStartPlayback();
                    logActivity(`Ad skipped (attempt ${attempt}/${AD_CONFIG.maxSkipRetries})`, 'success');
                    return { handled: true, skipped: true, attempts: attempt };
                }

                if (attempt < AD_CONFIG.maxSkipRetries) {
                    await sleep(AD_CONFIG.retryDelayMs);
                }
            }

            // Skip button existed but skip didn't take (UI click didn't register, etc).
            console.warn('[Niche Filter] Skip button present but skip failed - will try refresh');
            logActivity('Skip failed, refreshing video...', 'warning');
        } else {
            // No skip button found within the wait window.
            if (!isAdPlaying()) {
                resetAdRefreshCount();
                await tryStartPlayback();
                return { handled: true, skipped: false, unskippable: true };
            }
            console.log('[Niche Filter] No skip button detected - will try refresh');
            logActivity('No skip button, refreshing video...', 'warning');
        }

        // 2) If no skip button (or skip failed), REFRESH the video (user request).
        let refreshCount = 0;
        try {
            const stored = sessionStorage.getItem(SESSION_KEYS.adRefreshCount);
            refreshCount = stored ? parseInt(stored, 10) : 0;
        } catch {
            refreshCount = 0;
        }

        if (AD_CONFIG.refreshOnAdDetected && refreshCount < AD_CONFIG.maxRefreshAttempts) {
            refreshCount++;
            try {
                sessionStorage.setItem(SESSION_KEYS.adRefreshCount, String(refreshCount));
                // Ensure we attempt to resume playback after reload (works for ad refresh too).
                sessionStorage.setItem(SESSION_KEYS.autoplay, '1');
            } catch {
                // ignore
            }

            console.log(`[Niche Filter] Refreshing to escape ad (attempt ${refreshCount}/${AD_CONFIG.maxRefreshAttempts})`);
            logActivity(`Ad detected, refreshing video (attempt ${refreshCount}/${AD_CONFIG.maxRefreshAttempts})...`, 'action');
            await sleep(AD_CONFIG.refreshDelayMs);
            window.location.reload();
            return { handled: true, refreshed: true, attempt: refreshCount };
        }

        // 3) Last resort: watch the ad to completion.
        console.log('[Niche Filter] Max refresh attempts reached, watching ad...');
        logActivity('Could not skip/refresh ad, watching...', 'info');

        const finished = await waitForAdToFinish();
        resetAdRefreshCount();
        await tryStartPlayback();

        return {
            handled: true,
            skipped: false,
            watchedFull: true,
            timeout: !finished
        };
    } finally {
        adHandlingInProgress = false;
    }
}

/**
 * Reset the ad refresh counter (call when ad is successfully avoided or finishes)
 */
function resetAdRefreshCount() {
    try {
        sessionStorage.removeItem(SESSION_KEYS.adRefreshCount);
    } catch {
        // ignore
    }
}

/**
 * Start periodic ad checking while watching a video
 * Monitors throughout entire video for mid-roll ads
 */
function startAdMonitoring() {
    stopAdMonitoring(); // Clear any existing timer

    // Shorts ads are just swiped past by the Shorts loop.
    if (!isWatchLikePage()) return;

    // CRITICAL: Never monitor ads on home feed (prevents infinite refresh loop)
    if (isYouTubeHomeFeed()) {
        console.log('[Niche Filter] Skipping ad monitoring - on home feed');
        return;
    }

    let lastAdHandledAt = 0; // Small gap between handler runs while an ad keeps playing
    let checkCount = 0; // Count checks to add initial delay
    const warmupChecks = Math.max(1, Math.ceil(3000 / AD_CONFIG.checkIntervalMs)); // ~3s warmup

    adCheckTimerId = setInterval(async () => {
        if (!isPlaybackPage() || !automationEnabled || stopRequested) {
            stopAdMonitoring();
            return;
        }

        checkCount++;

        // Skip initial checks to let the player fully initialize.
        // This prevents false positives immediately after page load.
        if (checkCount <= warmupChecks) {
            console.log(`[Niche Filter] Ad monitoring: Waiting for player (${checkCount}/${warmupChecks})...`);
            return;
        }

        // Handle every ad that is playing, not just the first: after skipping ad 1 of 2,
        // the second one starts while we're still in ad mode.
        if (isAdPlaying() && !adHandlingInProgress && Date.now() - lastAdHandledAt > 1500) {
            console.log('[Niche Filter] Ad detected (pre-roll, mid-roll or next ad in a pod)');
            await handleAds();
            lastAdHandledAt = Date.now();
        }
    }, AD_CONFIG.checkIntervalMs);

    console.log('[Niche Filter] Ad monitoring started (will begin checks after 3s)');
}

/**
 * Stop periodic ad checking
 */
function stopAdMonitoring() {
    if (adCheckTimerId) {
        clearInterval(adCheckTimerId);
        adCheckTimerId = null;
    }
}

function scheduleHomeRefresh(delayMs) {
    // Prevent multiple queued refresh timers (watchdog/events can call into the cycle often).
    if (cycleHomeRefreshTimerId) {
        clearTimeout(cycleHomeRefreshTimerId);
        cycleHomeRefreshTimerId = null;
    }

    const safeDelay = Number.isFinite(delayMs) ? Math.max(0, Math.floor(delayMs)) : 0;
    cycleHomeRefreshTimerId = setTimeout(() => {
        cycleHomeRefreshTimerId = null;
        window.location.href = 'https://www.youtube.com/?t=' + Date.now();
    }, safeDelay);
}

async function runCycleScan(state, scannedLocation) {
    if (cycleScanInProgress) return;
    cycleScanInProgress = true;

    try {
        if (!state || state.active !== true) return;
        if (!automationEnabled || stopRequested) return;
        if (isSessionExpired(state)) {
            stopAutomationNow('session_end');
            return;
        }
        // Go back to the top so we scan from the start.
        if (window.scrollY > 40) {
            await HUMAN.scrollBy(-window.scrollY, { overshoot: false });
        }

        await waitForFeed();
        await sleep(HUMAN.randInt(800, 2_000));

        // Sometimes dismiss a card the way a viewer would.
        await HUMAN.maybeNotInterested();

        logActivity('Scrolling through the home feed...', 'navigation');
        await humanBrowseScroll();

        const skip = new Set(Array.isArray(state.watchedKeys) ? state.watchedKeys : []);

        const brainCategory = formatCategoryForBrain(state.category || '', state.keywords);

        notifyScanProgress({
            stage: 'start',
            category: brainCategory
        });

        logActivity(`Scanning for ${brainCategory} videos...`, 'brain');

        const scanResult = await scanFeedProgressively({
            keywords: Array.isArray(state.keywords) ? state.keywords : [],
            category: brainCategory,
            categoryHints: getCategoryKeywords(state.category || ''),
            shouldUseBrain: true,
            autoOpen: true,
            skipVideoKeys: skip,
            onPicked: (picked) => recordCyclePick(picked)
        });

        // Mark this location as scanned only when we actually opened a video.
        // If nothing opened, keep retrying until the user stops automation.
        if (scanResult.opened && scannedLocation) {
            cycleLastAutoScanLocation = scannedLocation;
        }

        if (!scanResult.opened) {
            console.log('[Niche Filter] Cycle: no next video found; will retry');
            logActivity('No matching video opened. Retrying...', 'warning');
        }
    } catch (error) {
        console.error('[Niche Filter] Cycle scan error:', error);
        // Do NOT set cycleLastAutoScanLocation on error — allow retry
    } finally {
        cycleScanInProgress = false;
    }
}

async function scanFeedProgressively({
    keywords,
    category,
    categoryHints,
    shouldUseBrain,
    autoOpen,
    skipVideoKeys,
    scanId,
    onPicked
}) {
    const skip =
        skipVideoKeys instanceof Set
            ? skipVideoKeys
            : new Set(Array.isArray(skipVideoKeys) ? skipVideoKeys : []);

    const maxVideos = CONFIG.scan.maxTotalVideos;

    // Get last scanned index from cycle state (to skip already-scanned videos)
    const cycleState = loadCycleState();
    const startIndex = cycleState?.lastScannedIndex || 0;

    console.log(`[Niche Filter] Scanning from index ${startIndex}`);

    // Step 1: Collect videos from visible feed starting from last position
    let videos = collectVideosFromFeed(skip, maxVideos, startIndex);

    if (!debugLogged && videos.length > 0) {
        debugLogged = true;
        console.log('[Niche Filter] Collected videos:', videos.length, videos.slice(0, 3));
    }

    // Step 2: Scroll a few times to load more cards (home feed is infinite).
    if (videos.length < maxVideos) {
        for (let round = 0; round < CONFIG.scan.maxRounds && videos.length < maxVideos; round++) {
            const before = videos.length;
            await scrollAndWaitForMore();
            videos = collectVideosFromFeed(skip, maxVideos, startIndex);
            // If scrolling didn't increase our candidate pool, don't waste time looping.
            if (videos.length <= before && before > 0) break;
        }
    }

    if (videos.length === 0) {
        // No videos found - handle retry
        if (autoOpen && cycleState && cycleState.active) {
            cycleState.noMatchRetries = (cycleState.noMatchRetries || 0) + 1;
            cycleState.lastScannedIndex = 0;  // Reset to start

            const retries = cycleState.noMatchRetries;
            const fastRetries = 3;
            let delayMs = 1000;
            if (retries > fastRetries) {
                // Backoff so we don't hammer reloads forever, but also never "stall" permanently.
                const backoffStep = retries - fastRetries;
                delayMs = Math.min(120_000, 15_000 * backoffStep); // cap at 2 minutes
            }

            saveCycleState(cycleState);
            console.log(`[Niche Filter] No videos found, refreshing page in ${Math.round(delayMs / 1000)}s (retry ${retries})...`);
            logActivity(`No videos found. Refreshing home in ${Math.round(delayMs / 1000)}s...`, 'warning');
            scheduleHomeRefresh(delayMs);
        }

        return {
            opened: false,
            openedVideo: null,
            matches: [],
            totalScanned: 0
        };
    }

    notifyScanProgress({
        scanId,
        stage: 'analyzing',
        scanned: videos.length,
        totalDiscovered: videos.length,
        title: `Analyzing ${videos.length} videos...`
    });

    logActivity(`Analyzing ${videos.length} videos with AI...`, 'brain');

    // Step 3: Analyze all videos in ONE batch API call
    let matches = [];

    if (shouldUseBrain) {
        matches = await analyzeBatchWithBrain(videos, category, categoryHints, keywords);

        // Titles the AI (not the keyword fallback) approved teach keyword mode new niche words.
        const aiApproved = matches.filter(m => m.brainFallback !== true).map(m => m.title);
        for (const title of aiApproved) {
            await learnFromTitles(cycleState?.category, [title]);
        }

        if (matches.length > 0) {
            logActivity(`Found ${matches.length} matching video(s) (scores: ${matches.slice(0, 3).map(m => m.score).join(', ')}%)`, 'success');
        } else {
            logActivity('No matching videos found in this batch', 'info');
        }
    } else {
        matches = analyzeWithKeywords(videos, keywords);
    }

    // Step 4: If we have a match and autoOpen is enabled, open one of the best few
    // (not always the top one, so picks look less mechanical).
    if (matches.length > 0 && autoOpen) {
        const firstMatch = matches[randomIntInclusive(0, Math.min(matches.length, 3) - 1)];

        // Save the feed index so next scan starts after this video
        if (cycleState && firstMatch.feedIndex !== undefined) {
            cycleState.lastScannedIndex = firstMatch.feedIndex + 1;
            cycleState.noMatchRetries = 0;  // Reset retry counter
            saveCycleState(cycleState);
            console.log(`[Niche Filter] Next scan will start from index ${cycleState.lastScannedIndex}`);
        }

        notifyScanProgress({
            scanId,
            stage: 'opening',
            scanned: videos.length,
            title: firstMatch?.title || ''
        });

        const videoTitle = truncateText(firstMatch?.title || '', 50);
        logActivity(`Opening: ${videoTitle}`, 'navigation');

        try {
            if (typeof onPicked === 'function') onPicked(firstMatch);
        } catch {
            // ignore
        }

        setTimeout(() => handleOpenVideo(firstMatch.url), 50);
        return {
            opened: true,
            openedVideo: firstMatch,
            matches: matches,
            totalScanned: videos.length
        };
    }

    // No match found - refresh and retry
    if (matches.length === 0 && autoOpen && cycleState && cycleState.active) {
        cycleState.noMatchRetries = (cycleState.noMatchRetries || 0) + 1;
        cycleState.lastScannedIndex = 0;  // Reset to start

        const retries = cycleState.noMatchRetries;
        const fastRetries = 3;
        let delayMs = 1000;
        if (retries > fastRetries) {
            const backoffStep = retries - fastRetries;
            delayMs = Math.min(120_000, 15_000 * backoffStep);
        }

        saveCycleState(cycleState);
        console.log(`[Niche Filter] No match found, refreshing for new content in ${Math.round(delayMs / 1000)}s (retry ${retries})...`);
        logActivity(`No matches found. Refreshing home in ${Math.round(delayMs / 1000)}s...`, 'warning');
        scheduleHomeRefresh(delayMs);
    }

    return {
        opened: false,
        openedVideo: null,
        matches: matches,
        totalScanned: videos.length
    };
}

/**
 * Collect videos from the visible feed DOM (fast, no API calls)
 * @param {Set} skip - Set of video keys to skip
 * @param {number} maxCount - Maximum number of videos to collect
 * @param {number} startIndex - Index to start from (skip first N videos)
 */
function collectVideosFromFeed(skip, maxCount, startIndex = 0) {
    const elements = getAllVideoElements();
    const videos = [];

    for (let i = startIndex; i < elements.length; i++) {
        if (videos.length >= maxCount) break;

        const el = elements[i];
        const data = extractVideoData(el);
        if (!data || !data.url) continue;

        // Skip already-watched videos
        if (data.key && skip?.has?.(data.key)) {
            continue;
        }

        // Track feed position for next scan
        data.feedIndex = i;
        videos.push(data);
    }

    return videos;
}

// ============================================
// Search & Sidebar Phase Functions
// ============================================

async function navigateToSearch(query, searchFilter = '') {
    const encoded = encodeURIComponent(query);
    const filter = searchFilter ? `&sp=${searchFilter}` : '';
    cycleLastAutoScanLocation = '';
    const fallback = `https://www.youtube.com/results?search_query=${encoded}${filter}`;

    if (!searchFilter) {
        // Type into the real search box when it exists so the transition stays in-page.
        await HUMAN.search(query, fallback);
        return;
    }

    // Channel search: type it like a person, then apply the "Type: Channel"
    // filter through the UI instead of hard-loading a filtered URL.
    const typed = await HUMAN.search(query, fallback);
    if (!typed) return;
    await sleep(HUMAN.randInt(900, 1_600));
    if (await applyChannelSearchFilter()) return;
    window.location.assign(fallback);
}

async function applyChannelSearchFilter() {
    try {
        const filtersButton =
            document.querySelector('#filter-button button') ||
            document.querySelector('button[aria-label*="filter" i]') ||
            document.querySelector('ytd-search-filter-renderer');
        if (!filtersButton) return false;

        await HUMAN.click(filtersButton, { missChance: 0.03 });
        await sleep(HUMAN.randInt(500, 1_000));

        const groups = Array.from(document.querySelectorAll('ytd-search-filter-group-renderer'));
        const typeGroup = groups.find(group => /type/i.test(group.querySelector('#title, h3')?.textContent || ''));
        const scope = typeGroup || document;

        const channelItem = Array.from(scope.querySelectorAll('ytd-search-filter-renderer, tp-yt-paper-item'))
            .find(el => /^channel$/i.test((el.textContent || '').trim()));
        if (!channelItem) {
            HUMAN.pressKey('Escape', document.body);
            return false;
        }

        await HUMAN.click(channelItem, { missChance: 0.03 });
        await sleep(HUMAN.randInt(1_200, 2_200));
        return window.location.search.includes('sp=');
    } catch {
        return false;
    }
}

function navigateToHome() {
    cycleLastAutoScanLocation = '';
    void HUMAN.navigateHome();
}

function waitForSearchResults() {
    return new Promise((resolve, reject) => {
        let attempts = 0;
        const maxAttempts = 80; // 80 * 250ms = 20s

        const check = () => {
            const results = document.querySelectorAll('ytd-video-renderer');
            if (results.length > 0) {
                resolve();
                return;
            }
            attempts++;
            if (attempts >= maxAttempts) {
                reject(new Error('Search results not loaded'));
                return;
            }
            setTimeout(check, 250);
        };
        check();
    });
}

function normalizeSearchQuery(query) {
    if (typeof query !== 'string') return '';
    return query
        .replace(/\s+/g, ' ')
        .replace(/^['"\s]+|['"\s]+$/g, '')
        .trim()
        .slice(0, 90);
}

// ============================================
// Human-like Cycle: home -> top channels -> Shorts
// ============================================

function isShortsPage() {
    return window.location.pathname.startsWith('/shorts/');
}

function isChannelVideosPage() {
    return /^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)\/videos\/?$/.test(window.location.pathname);
}

function navigateTo(url) {
    cycleLastAutoScanLocation = '';
    void HUMAN.navigateTo(url);
}

/**
 * Called after each long-form video. Decides what a viewer would do next.
 */
function advanceLongformPhase(st) {
    const longformMin = Math.round((st.longformWatchedMs || 0) / 60_000);
    const targetMin = Math.round((st.longformTargetMs || 0) / 60_000);

    if (st.cyclePhase === 'channel_videos') {
        st.channelVideosWatched = (st.channelVideosWatched || 0) + 1;
        const channelTarget = st.channelVideoTarget || CONFIG.humanCycle.channelVideosMin;
        const channelName = truncateText(st.currentChannelName || 'channel', 30);
        const longformLeftMs = (st.longformTargetMs || 0) - (st.longformWatchedMs || 0);
        const longformDone = longformLeftMs <= 0;

        // Once long-form time is reached, 2 videos from this channel is enough.
        if (longformDone && st.channelVideosWatched >= CONFIG.humanCycle.channelVideosMin) {
            startShortsPhase(st);
            return;
        }

        if (st.channelVideosWatched < channelTarget && st.currentChannelUrl) {
            logActivity(
                `${channelName}: ${st.channelVideosWatched}/${channelTarget} videos (${longformMin}/${targetMin} min long-form). Back to channel...`,
                'navigation'
            );
            saveCycleState(st);
            navigateTo(`${st.currentChannelUrl}/videos`);
            return;
        }

        // A new channel means 2+ more videos, so don't start one for the last few minutes.
        if (longformLeftMs <= 4 * 60_000) {
            startShortsPhase(st);
            return;
        }

        logActivity(`Done with ${channelName} (${longformMin}/${targetMin} min). Finding another top channel...`, 'action');
        st.cyclePhase = 'channel_search';
        saveCycleState(st);
        navigateToHome();
        return;
    }

    // Home feed block
    st.cyclePhase = 'home_feed';
    st.phaseVideosWatched = (st.phaseVideosWatched || 0) + 1;
    const homeTarget = st.homeTarget || CONFIG.humanCycle.homeVideosMin;

    if (st.phaseVideosWatched < homeTarget) {
        logActivity(`Home video ${st.phaseVideosWatched}/${homeTarget} done. Back to home feed...`, 'navigation');
        saveCycleState(st);
        navigateToHome();
        return;
    }

    logActivity(`Home browsing done (${homeTarget} videos, ${longformMin} min). Searching top channels...`, 'action');
    st.cyclePhase = 'channel_search';
    st.phaseVideosWatched = 0;
    saveCycleState(st);
    navigateToHome();
}

/**
 * Scroll the feed in uneven steps with pauses, sometimes scrolling back up.
 */
async function humanBrowseScroll(steps = randomIntInclusive(3, 6)) {
    for (let i = 0; i < steps; i++) {
        if (!automationEnabled || stopRequested) return;
        const goUp = i > 0 && Math.random() < 0.2;
        const distance = randomIntInclusive(250, 750) * (goUp ? -0.5 : 1);
        await HUMAN.scrollBy(distance);
        await sleep(HUMAN.randInt(700, 2_200));
    }
}

function getNicheTopics(state) {
    const category = String(state?.category || '');
    const labels = {
        tech: 'tech',
        gaming: 'gaming',
        finance: 'personal finance',
        fitness: 'fitness',
        business: 'business',
        education: 'education',
        entertainment: 'entertainment',
        music: 'music'
    };
    const base = category.startsWith('custom_')
        ? category.replace('custom_', '').replace(/_/g, ' ')
        : (labels[category] || category);
    const keywords = (Array.isArray(state?.keywords) ? state.keywords : [])
        .map(k => String(k || '').trim())
        .filter(k => k && !isGenericKeyword(k.toLowerCase()))
        .slice(0, 8);
    return Array.from(new Set([base, ...keywords].filter(Boolean)));
}

/**
 * Get a niche search query from the AI, falling back to keyword templates.
 * kind: 'channel' | 'shorts'
 */
async function generateNicheQuery(state, kind) {
    const used = new Set(Array.isArray(state.usedQueries) ? state.usedQueries : []);
    const purpose = kind === 'shorts'
        ? 'find short-form YouTube Shorts in this niche'
        : 'find the biggest, most popular YouTube channels in this niche';

    let candidates = [];
    try {
        const response = await chrome.runtime.sendMessage({
            action: 'brainGenerateSearchQueries',
            category: formatCategoryForBrain(state.category || '', state.keywords),
            keywords: (state.keywords || []).slice(0, 12),
            purpose
        });
        const queries = response?.result?.data?.queries;
        const isFallback = /^fallback/i.test(response?.result?.reasoning || '');
        // Without an API key the brain's generic fallback queries are worse than ours below.
        if (response?.success && !isFallback && Array.isArray(queries)) {
            candidates = queries.map(normalizeSearchQuery).filter(Boolean);
        }
    } catch (error) {
        console.warn('[Niche Filter] Query generation failed:', error.message);
    }

    if (candidates.length === 0) {
        const topics = getNicheTopics(state);
        candidates = topics.flatMap(topic => kind === 'shorts'
            ? [`${topic} shorts`, `${topic} tips shorts`, `${topic} #shorts`]
            : [topic, `best ${topic} channel`, `${topic} youtuber`]);
    }

    const fresh = candidates.filter(q => !used.has(q));
    const pool = fresh.length > 0 ? fresh : candidates;
    let query = pool[randomIntInclusive(0, pool.length - 1)] || 'popular videos';
    if (kind === 'shorts' && !/shorts/i.test(query)) {
        query = `${query} #shorts`;
    }

    state.usedQueries = addRecentText(state.usedQueries, query, 30);
    saveCycleState(state);
    return query;
}

// ---------- Top channels ----------

async function startChannelSearch(state) {
    if (cycleScanInProgress) return;
    cycleScanInProgress = true;
    try {
        logActivity('Looking for top channels in your niche...', 'brain');
        const query = await generateNicheQuery(state, 'channel');
        const st = loadCycleState();
        if (!st || st.active !== true || !automationEnabled || stopRequested) return;
        st.cyclePhase = 'channel_search';
        saveCycleState(st);
        logActivity(`Searching channels: "${query}"`, 'action');
        await navigateToSearch(query, CHANNEL_SEARCH_FILTER);
    } finally {
        cycleScanInProgress = false;
    }
}

function parseCompactCount(text) {
    const match = String(text || '').replace(/,/g, '').match(/([\d.]+)\s*([KMB])?\s*subscribers/i);
    if (!match) return 0;
    const value = parseFloat(match[1]);
    const mult = { K: 1e3, M: 1e6, B: 1e9 }[(match[2] || '').toUpperCase()] || 1;
    return Number.isFinite(value) ? Math.round(value * mult) : 0;
}

function toChannelBaseUrl(href) {
    if (!href) return '';
    try {
        const u = new URL(href, 'https://www.youtube.com');
        const match = u.pathname.match(/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)/);
        return match ? `https://www.youtube.com/${match[1]}` : '';
    } catch {
        return '';
    }
}

function collectChannelsFromSearch() {
    const channels = [];
    const seen = new Set();

    for (const el of document.querySelectorAll('ytd-channel-renderer')) {
        const link = el.querySelector('a#main-link, a.channel-link, a[href^="/@"], a[href^="/channel/"]');
        const url = toChannelBaseUrl(link?.getAttribute('href'));
        if (!url || seen.has(url)) continue;
        seen.add(url);
        const name = normalizeText(el.querySelector('ytd-channel-name #text, #channel-title #text, #text.ytd-channel-name')?.textContent);
        const description = normalizeText(el.querySelector('#description')?.textContent);
        channels.push({
            url,
            name: name || url.split('/').pop(),
            description,
            subscribers: parseCompactCount(el.textContent),
            position: channels.length
        });
    }

    // Fallback: channel filter didn't apply, so use channels behind the video results.
    if (channels.length === 0) {
        for (const el of document.querySelectorAll('ytd-video-renderer')) {
            const link = el.querySelector('ytd-channel-name a, #channel-info a[href^="/@"]');
            const url = toChannelBaseUrl(link?.getAttribute('href'));
            if (!url || seen.has(url)) continue;
            seen.add(url);
            channels.push({
                url,
                name: normalizeText(link?.textContent) || url.split('/').pop(),
                description: '',
                subscribers: 0,
                position: channels.length
            });
        }
    }

    return channels;
}

async function waitForSelector(selector, timeoutMs = 15_000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
        if (document.querySelector(selector)) return true;
        await sleep(250);
    }
    return false;
}

async function runChannelSearchScan(state, scannedLocation) {
    if (cycleScanInProgress) return;
    cycleScanInProgress = true;

    try {
        if (!state || state.active !== true || !automationEnabled || stopRequested) return;

        await waitForSelector('ytd-channel-renderer, ytd-video-renderer');
        await sleep(randomIntInclusive(1000, 2500));
        await humanBrowseScroll(randomIntInclusive(1, 3));

        const visited = new Set(Array.isArray(state.visitedChannels) ? state.visitedChannels : []);
        let channels = collectChannelsFromSearch().filter(ch => !visited.has(ch.url)).slice(0, 10);

        if (channels.length === 0) {
            const st = loadCycleState() || state;
            st.channelSearchFails = (st.channelSearchFails || 0) + 1;
            cycleLastAutoScanLocation = scannedLocation;
            if (st.channelSearchFails >= 3) {
                st.channelSearchFails = 0;
                logActivity('Could not find channels after 3 searches. Moving on to Shorts...', 'warning');
                startShortsPhase(st);
                return;
            }
            saveCycleState(st);
            logActivity('No new channels in these results. Trying another search...', 'warning');
            navigateToHome();
            return;
        }

        // Ask the AI which channels actually fit the niche.
        const brainCategory = formatCategoryForBrain(state.category || '', state.keywords);
        const asVideos = channels.map(ch => ({
            ...ch,
            title: truncateText(`${ch.name} - ${ch.description}`, 160)
        }));
        const relevant = await analyzeBatchWithBrain(
            asVideos,
            brainCategory,
            getCategoryKeywords(state.category || ''),
            state.keywords
        );
        if (relevant.length > 0) channels = relevant;

        // "Top" channel: most subscribers among the first few relevant results.
        const pool = channels
            .slice()
            .sort((a, b) => a.position - b.position)
            .slice(0, 5)
            .sort((a, b) => (b.subscribers || 0) - (a.subscribers || 0));
        const picked = pool[0];

        const st = loadCycleState() || state;
        st.cyclePhase = 'channel_videos';
        st.channelSearchFails = 0;
        st.currentChannelUrl = picked.url;
        st.currentChannelName = picked.name;
        st.channelVideosWatched = 0;
        st.channelVideosMissed = 0;
        st.channelVideoTarget = randomIntInclusive(CONFIG.humanCycle.channelVideosMin, CONFIG.humanCycle.channelVideosMax);
        st.visitedChannels = addUniqueKey(st.visitedChannels, picked.url, 100);
        saveCycleState(st);

        cycleLastAutoScanLocation = scannedLocation;
        const subs = picked.subscribers ? ` (${picked.subscribers.toLocaleString()} subs)` : '';
        logActivity(`Opening channel: ${truncateText(picked.name, 40)}${subs} - will watch ${st.channelVideoTarget} videos`, 'navigation');
        await sleep(randomIntInclusive(800, 1800));
        navigateTo(`${picked.url}/videos`);
    } catch (error) {
        console.error('[Niche Filter] Channel search error:', error);
    } finally {
        cycleScanInProgress = false;
    }
}

async function clickChannelSortChip(label) {
    const chips = Array.from(document.querySelectorAll('yt-chip-cloud-chip-renderer, chip-shape button, button[role="tab"]'));
    const chip = chips.find(el => normalizeText(el.textContent).toLowerCase() === label.toLowerCase());
    if (!chip) return false;
    await HUMAN.click(chip, { missChance: 0.05 });
    await sleep(HUMAN.randInt(1_500, 2_500));
    return true;
}

async function runChannelVideosScan(state, scannedLocation) {
    if (cycleScanInProgress) return;
    cycleScanInProgress = true;

    try {
        if (!state || state.active !== true || !automationEnabled || stopRequested) return;

        try {
            await waitForFeed();
        } catch {
            // handled below as "no videos"
        }
        await sleep(randomIntInclusive(1200, 2500));

        // Viewers browse a channel's Popular tab about half the time.
        if (Math.random() < 0.5 && await clickChannelSortChip('Popular')) {
            logActivity('Browsing the channel\'s popular videos...', 'navigation');
        }
        await humanBrowseScroll(randomIntInclusive(1, 3));

        if (!(state.channelVideosWatched > 0)) {
            const channelTitles = collectVideosFromFeed(new Set(), 30, 0).map(v => v.title);
            await learnFromTitles(state.category, channelTitles);
        }

        const skip = new Set(Array.isArray(state.watchedKeys) ? state.watchedKeys : []);
        const videos = collectVideosFromFeed(skip, 12, 0);

        if (videos.length === 0) {
            const st = loadCycleState() || state;
            st.channelVideosMissed = (st.channelVideosMissed || 0) + 1;
            if (st.channelVideosMissed >= 2) {
                logActivity('No suitable videos on this channel. Finding another channel...', 'warning');
                st.cyclePhase = 'channel_search';
                saveCycleState(st);
                navigateToHome();
            } else {
                saveCycleState(st);
                logActivity('No suitable videos found yet. Reloading channel...', 'warning');
                setTimeout(() => window.location.reload(), 3000);
            }
            return;
        }

        const picked = videos[randomIntInclusive(0, Math.min(videos.length, 8) - 1)];
        cycleLastAutoScanLocation = scannedLocation;
        recordCyclePick(picked);
        logActivity(`Opening channel video: ${truncateText(picked.title, 50)}`, 'navigation');
        await sleep(HUMAN.randInt(600, 1_500));
        await handleOpenVideo(picked.url);
    } catch (error) {
        console.error('[Niche Filter] Channel videos scan error:', error);
    } finally {
        cycleScanInProgress = false;
    }
}

// ---------- Shorts ----------

function startShortsPhase(st) {
    const hc = CONFIG.humanCycle;
    const minutes = randomIntInclusive(hc.shortsMinMinutes, hc.shortsMaxMinutes);
    const longformMin = Math.round((st.longformWatchedMs || 0) / 60_000);
    st.cyclePhase = 'shorts';
    st.shortsEndsAt = Date.now() + minutes * 60_000;
    st.returnAt = st.shortsEndsAt;
    st.shortsWatched = 0;
    st.shortsSinceSearch = 0;
    saveCycleState(st);
    logActivity(`Long-form done (${longformMin} min). Watching niche Shorts for ${minutes} min...`, 'action');
    navigateToHome();
}

async function startShortsSearch(state) {
    if (cycleScanInProgress) return;
    cycleScanInProgress = true;
    try {
        const query = await generateNicheQuery(state, 'shorts');
        if (!automationEnabled || stopRequested) return;
        logActivity(`Searching Shorts: "${query}"`, 'action');
        await navigateToSearch(query);
    } finally {
        cycleScanInProgress = false;
    }
}

async function runShortsSearchScan(state, scannedLocation) {
    if (cycleScanInProgress) return;
    cycleScanInProgress = true;

    try {
        if (!state || state.active !== true || !automationEnabled || stopRequested) return;
        if (Date.now() >= (state.shortsEndsAt || 0)) {
            completeCycle(state);
            return;
        }

        await waitForSelector('a[href^="/shorts/"]');
        await sleep(randomIntInclusive(1000, 2000));
        await humanBrowseScroll(randomIntInclusive(1, 2));

        const urls = Array.from(new Set(
            Array.from(document.querySelectorAll('a[href^="/shorts/"]'))
                .map(a => a.getAttribute('href'))
                // Skip the sidebar's bare "/shorts/" link; keep real Shorts with an id.
                .filter(href => /^\/shorts\/[\w-]{5,}/.test(href || ''))
        ));

        cycleLastAutoScanLocation = scannedLocation;
        if (urls.length === 0) {
            logActivity('No Shorts in search results. Opening the Shorts feed...', 'warning');
            window.location.assign('https://www.youtube.com/shorts/');
            return;
        }

        // Start somewhere in the top results and keep the rest as a queue: the Shorts
        // player ignores scripted swipes, so the loop may need to open them directly.
        const absolute = urls.map(href => `https://www.youtube.com${href.split('?')[0]}`);
        const startIndex = randomIntInclusive(0, Math.min(absolute.length, 5) - 1);
        const st = loadCycleState() || state;
        st.shortsQueue = absolute.slice(startIndex + 1, startIndex + 21);
        saveCycleState(st);

        logActivity(`Opening a niche Short (${st.shortsQueue.length} more queued)...`, 'navigation');
        window.location.assign(absolute[startIndex]);
    } catch (error) {
        console.error('[Niche Filter] Shorts search error:', error);
    } finally {
        cycleScanInProgress = false;
    }
}

function getActiveShortRenderer() {
    // Current layout reuses one reel container around #shorts-player; older layouts mark it is-active.
    return document.querySelector('#shorts-player')?.closest('ytd-reel-video-renderer')
        || document.querySelector('ytd-reel-video-renderer[is-active]')
        || null;
}

function getActiveShortVideo() {
    return document.querySelector('#shorts-player video')
        || getActiveShortRenderer()?.querySelector('video')
        || document.querySelector('video');
}

function isActiveShortAd() {
    const active = getActiveShortRenderer();
    if (!active) return false;
    if (active.querySelector('ytd-ad-slot-renderer, ad-badge-view-model, ytd-in-feed-ad-layout-renderer')) return true;
    return /\bSponsored\b/.test(active.textContent || '');
}

/**
 * How long to stay on one Short: sometimes swipe fast, usually watch most of it,
 * occasionally let it loop.
 */
function pickShortWatchMs(video) {
    const duration = video && Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 30;
    const roll = Math.random();
    let seconds;
    if (roll < 0.15) {
        seconds = randomFloat(2, 5);
    } else if (roll < 0.85) {
        seconds = duration * randomFloat(0.6, 1.0);
    } else {
        seconds = duration * randomFloat(1.2, 2.0);
    }
    return Math.round(Math.max(2, Math.min(120, seconds)) * 1000);
}

async function likeActiveShort() {
    const active = getActiveShortRenderer();
    const scope = active || document;
    const button = scope.querySelector('like-button-view-model button, #like-button button, ytd-toggle-button-renderer#like-button button')
        || Array.from(scope.querySelectorAll('button[aria-label]')).find(btn => {
            const label = String(btn.getAttribute('aria-label') || '').toLowerCase();
            return label.includes('like') && !label.includes('dislike');
        });
    if (!button || isLikeButtonPressed(button)) return false;
    await HUMAN.click(button, { missChance: 0.06 });
    return true;
}

/**
 * Move to the next Short. Returns 'swiped' (same page), 'navigating' (full page
 * load to a queued Short) or 'empty' (queue used up).
 */
async function goToNextShort(state) {
    const before = window.location.pathname;
    const button = document.querySelector('#navigation-button-down button, #navigation-button-down ytd-button-renderer button, button[aria-label="Next video"]');
    if (button) {
        await HUMAN.click(button, { missChance: 0.05 });
        const start = Date.now();
        while (Date.now() - start < 4000) {
            if (window.location.pathname !== before) return 'swiped';
            await sleep(200);
        }
    }

    // The Shorts player usually ignores scripted clicks; open the next queued Short instead.
    const queue = Array.isArray(state.shortsQueue) ? state.shortsQueue.slice() : [];
    const next = queue.shift();
    state.shortsQueue = queue;
    saveCycleState(state);
    if (!next) return 'empty';

    window.location.assign(next);
    return 'navigating';
}

async function runShortsLoop() {
    if (shortsLoopRunning) return;
    shortsLoopRunning = true;

    try {
        await sleep(randomIntInclusive(1500, 3000));

        while (true) {
            const st = loadCycleState();
            if (!st || st.active !== true || st.cyclePhase !== 'shorts') return;
            if (!automationEnabled || stopRequested) return;
            if (!isShortsPage()) return;

            if (Date.now() >= (st.shortsEndsAt || 0)) {
                completeCycle(st);
                return;
            }

            const video = getActiveShortVideo();
            if (video && video.paused) {
                try {
                    await video.play();
                } catch {
                    // ignore autoplay rejection
                }
            }

            const isAd = isActiveShortAd();
            const watchMs = isAd ? randomIntInclusive(2000, 5000) : pickShortWatchMs(video);
            const remainingMin = Math.max(0, Math.round((st.shortsEndsAt - Date.now()) / 60_000));
            if (!isAd) {
                logActivity(`Short #${(st.shortsWatched || 0) + 1}: watching ${Math.round(watchMs / 1000)}s (${remainingMin} min of Shorts left)`, 'watch');
            }

            const shortPath = window.location.pathname;
            const watchStart = Date.now();
            let nextJiggle = watchStart + HUMAN.randInt(4_000, 12_000);
            let pausedOnce = false;

            while (Date.now() - watchStart < watchMs) {
                if (!automationEnabled || stopRequested) return;
                if (window.location.pathname !== shortPath) break;

                if (Date.now() >= nextJiggle) {
                    nextJiggle = Date.now() + HUMAN.randInt(6_000, 18_000);
                    HUMAN.presence();
                    if (HUMAN.chance(0.5)) {
                        await HUMAN.moveTo(
                            HUMAN.rand(60, Math.max(120, window.innerWidth - 60)),
                            HUMAN.rand(80, Math.max(140, window.innerHeight - 80)),
                            { maxSteps: 10 }
                        );
                    }
                }

                // Sometimes a Short gets paused mid-way and resumed.
                if (!pausedOnce && !isAd && HUMAN.chance(0.004)) {
                    pausedOnce = true;
                    const activeVideo = getActiveShortVideo();
                    if (activeVideo && !activeVideo.paused) {
                        try {
                            activeVideo.pause();
                            await sleep(HUMAN.randInt(900, 3_500));
                            await activeVideo.play();
                        } catch {
                            // ignore
                        }
                    }
                }

                await sleep(500);
            }

            const latest = loadCycleState();
            if (!latest || latest.active !== true || latest.cyclePhase !== 'shorts') return;

            if (!isAd) {
                if (HUMAN.chance(CONFIG.engagement.shortsLikeChance * HUMAN.warmupFactor()) && await likeActiveShort()) {
                    await recordLike();
                    logActivity('Liked this Short', 'success');
                    await sleep(HUMAN.randInt(500, 1_200));
                }
                latest.shortsWatched = (latest.shortsWatched || 0) + 1;
                latest.shortsSinceSearch = (latest.shortsSinceSearch || 0) + 1;
                saveCycleState(latest);
                await recordVideoWatched(Math.round(watchMs / 1000));
            }

            // Search again now and then so the Shorts feed stays on the niche.
            if ((latest.shortsSinceSearch || 0) >= (latest.shortsResearchAt || CONFIG.humanCycle.shortsResearchMax)) {
                latest.shortsSinceSearch = 0;
                latest.shortsResearchAt = randomIntInclusive(CONFIG.humanCycle.shortsResearchMin, CONFIG.humanCycle.shortsResearchMax);
                saveCycleState(latest);
                logActivity('Searching for more niche Shorts...', 'action');
                await startShortsSearch(latest);
                return;
            }

            const result = await goToNextShort(latest);
            if (result === 'navigating') return;
            if (result === 'empty') {
                logActivity('Watched all queued Shorts. Searching for more...', 'action');
                await startShortsSearch(latest);
                return;
            }
            await sleep(HUMAN.randInt(600, 1_500));
        }
    } catch (error) {
        console.error('[Niche Filter] Shorts loop error:', error);
    } finally {
        shortsLoopRunning = false;
    }
}

// ---------- Keyword learning (better matching when the AI is unavailable) ----------

const LEARN_STOP_WORDS = new Set([
    'about', 'after', 'again', 'against', 'almost', 'also', 'always', 'amazing', 'another', 'anyone', 'anything',
    'around', 'back', 'because', 'been', 'before', 'being', 'best', 'better', 'beyond', 'biggest', 'build', 'building',
    'built', 'can\'t', 'change', 'changed', 'channel', 'cheap', 'complete', 'could', 'crazy', 'day', 'days', 'did\'t',
    'didn\'t', 'does', 'doesn\'t', 'doing', 'done', 'don\'t', 'down', 'during', 'each', 'easy', 'easiest', 'ending',
    'enough', 'episode', 'even', 'ever', 'every', 'everyone', 'everything', 'explained', 'fast', 'final', 'finally',
    'find', 'first', 'free', 'from', 'full', 'game', 'gets', 'getting', 'give', 'going', 'good', 'great', 'guide',
    'happened', 'have', 'here', 'highly', 'home', 'hours', 'huge', 'idea', 'ideas', 'incredible', 'insane', 'into',
    'it\'s', 'just', 'know', 'last', 'learn', 'less', 'life', 'like', 'little', 'live', 'long', 'look', 'made', 'make',
    'makes', 'making', 'many', 'minute', 'minutes', 'month', 'months', 'more', 'most', 'much', 'must', 'myself', 'need',
    'never', 'news', 'next', 'nobody', 'nothing', 'only', 'other', 'over', 'part', 'people', 'perfect', 'review',
    'really', 'right', 'same', 'satisfying', 'secret', 'should', 'shorts', 'show', 'simple', 'since', 'small', 'some',
    'something', 'start', 'started', 'step', 'still', 'stop', 'story', 'such', 'take', 'than', 'that', 'that\'s',
    'their', 'them', 'then', 'there', 'these', 'they', 'thing', 'things', 'think', 'this', 'those', 'through', 'time',
    'times', 'today', 'tried', 'trying', 'tutorial', 'ultimate', 'under', 'until', 'using', 'very', 'video', 'videos',
    'vlog', 'want', 'watch', 'ways', 'week', 'weeks', 'well', 'went', 'were', 'what', 'what\'s', 'when', 'where',
    'which', 'while', 'who\'s', 'whole', 'why', 'will', 'with', 'without', 'world', 'worth', 'would', 'year', 'years',
    'you\'re', 'your', 'yourself'
]);

function learnedTermsStorageKey(category) {
    return `learnedTerms:${String(category || '').toLowerCase()}`;
}

/**
 * Count niche words from one trusted source (an AI-approved title, or a top
 * channel's video grid). Each source adds at most 1 per word, so one channel's
 * pet topics can't dominate.
 */
async function learnFromTitles(category, titles) {
    if (!category || !Array.isArray(titles) || titles.length === 0) return;
    try {
        const key = learnedTermsStorageKey(category);
        const counts = (await chrome.storage.local.get([key]))[key] || {};
        const words = new Set();
        for (const title of titles) {
            for (const word of String(title || '').toLowerCase().match(/[a-z][a-z']{3,}/g) || []) {
                if (!LEARN_STOP_WORDS.has(word)) words.add(word);
            }
        }
        for (const word of words) {
            counts[word] = (counts[word] || 0) + 1;
        }
        const trimmed = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 300);
        await chrome.storage.local.set({ [key]: Object.fromEntries(trimmed) });
    } catch (error) {
        console.warn('[Niche Filter] Keyword learning failed:', error.message);
    }
}

function seededKeywordsStorageKey(category) {
    return `seededKeywords:${String(category || '').toLowerCase()}`;
}

/**
 * Once per category, ask the AI for words that typically appear in this niche's
 * titles and keep them. They make keyword-mode matching work well later, even
 * when no AI is reachable.
 */
async function seedNicheKeywords(category, keywords) {
    if (!category) return;
    const key = seededKeywordsStorageKey(category);
    try {
        const existing = (await chrome.storage.local.get([key]))[key];
        if (Array.isArray(existing) && existing.length > 0) return;

        const response = await chrome.runtime.sendMessage({
            action: 'brainGenerateKeywords',
            category: formatCategoryForBrain(category, keywords),
            keywords: (keywords || []).slice(0, 12)
        });
        // Skip the brain's offline fallback (it just splits the category name).
        if (!response?.success || /^fallback/i.test(response.result?.reasoning || '')) return;

        const own = new Set((keywords || []).map(k => String(k).toLowerCase()));
        const seeded = Array.from(new Set(
            (response.result?.data?.keywords || [])
                .map(k => String(k || '').toLowerCase().replace(/[^a-z0-9' -]/g, ' ').replace(/\s+/g, ' ').trim())
                .filter(k => k.length >= 3 && k.length <= 30 && !own.has(k) && !LEARN_STOP_WORDS.has(k) && !isGenericKeyword(k))
        )).slice(0, 20);
        if (seeded.length === 0) return;

        await chrome.storage.local.set({ [key]: seeded });
        logActivity(`Learned niche keywords: ${seeded.join(', ')}`, 'brain');
    } catch (error) {
        console.warn('[Niche Filter] Keyword seeding failed:', error.message);
    }
}

/**
 * Extra keywords for matching: `strong` (AI-seeded, or seen in 4+ trusted
 * sources) and `weak` (seen in 3 sources). The user's own keywords are excluded.
 */
async function getLearnedKeywords(category, userKeywords = []) {
    const empty = { strong: [], weak: [] };
    if (!category) return empty;
    try {
        const termsKey = learnedTermsStorageKey(category);
        const seededKey = seededKeywordsStorageKey(category);
        const stored = await chrome.storage.local.get([termsKey, seededKey]);
        const counts = stored[termsKey] || {};
        const seeded = Array.isArray(stored[seededKey]) ? stored[seededKey] : [];
        const own = new Set((userKeywords || []).map(k => String(k).toLowerCase()));

        const ranked = Object.entries(counts)
            .filter(([word, count]) => count >= 3 && !own.has(word))
            .sort((a, b) => b[1] - a[1])
            .slice(0, 25);
        const strong = Array.from(new Set([
            ...seeded.filter(k => !own.has(k)),
            ...ranked.filter(([, count]) => count >= 4).map(([word]) => word)
        ]));
        return {
            strong,
            weak: ranked.filter(([word, count]) => count === 3 && !strong.includes(word)).map(([word]) => word)
        };
    } catch {
        return empty;
    }
}

// ---------- Cycle completion ----------

function completeCycle(st) {
    st.cyclesCompleted = (st.cyclesCompleted || 0) + 1;
    const target = st.targetCycles || CONFIG.humanCycle.targetCycles;
    const longformMin = Math.round((st.longformWatchedMs || 0) / 60_000);
    logActivity(
        `Cycle ${st.cyclesCompleted}/${target} complete: ${longformMin} min long-form, ${st.shortsWatched || 0} Shorts, ${st.cycleComments || 0} comments`,
        'success'
    );

    if (st.cyclesCompleted >= target) {
        saveCycleState(st);
        logActivity(`All ${target} cycles finished. Session complete.`, 'success');
        stopAutomationNow('cycles_complete');
        return;
    }

    resetCycleProgress(st);
    saveCycleState(st);
    logActivity(`Cycle ${st.cyclesCompleted + 1}/${target}: browsing home feed (${st.homeTarget} videos)`, 'action');
    navigateToHome();
}

/**
 * Analyze all videos in ONE batch API call (FAST!)
 */
async function analyzeBatchWithBrain(videos, category, categoryHints, keywords) {
    if (!videos || videos.length === 0) return [];

    const safeHints = Array.isArray(categoryHints) ? categoryHints.filter(Boolean).slice(0, 8) : [];
    // Seeded and well-established learned words count like the user's keywords;
    // newer learned words count half (see buildFallbackBrainMatch in background.js).
    const learned = await getLearnedKeywords(loadCycleState()?.category, keywords);
    const allKeywords = Array.from(new Set([...(keywords || []), ...learned.strong]));

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'brainAnalyzeBatch',
            videos: videos.map(v => ({ title: v.title || '' })),
            category,
            categoryHints: safeHints,
            keywords: allKeywords,
            learnedKeywords: learned.weak
        });

        if (!response?.success) {
            console.warn('[Niche Filter] Batch analysis failed:', response?.error);
            // Fallback to keyword matching
            return analyzeWithKeywords(videos, allKeywords);
        }

        const batchMatches = response.result?.data?.matches || [];
        const results = [];

        for (const match of batchMatches) {
            if (!match) continue;

            // Check if relevant
            const relevant = match.relevant === true || match.relevant === 'true';
            if (!relevant) continue;

            const index = typeof match.index === 'string'
                ? parseInt(match.index, 10)
                : match.index;

            if (typeof index !== 'number' || !Number.isFinite(index)) continue;
            if (index < 0 || index >= videos.length) continue;

            const video = videos[index];
            if (!video) continue;

            results.push({
                ...video,
                score: match.score || 70,
                brainAnalyzed: true,
                brainFallback: match.brainFallback === true
            });
        }

        // Sort by score (highest first) and return
        results.sort((a, b) => (b.score || 0) - (a.score || 0));
        return results;

    } catch (error) {
        console.warn('[Niche Filter] Batch API error:', error.message);
        // Fallback to keyword matching
        return analyzeWithKeywords(videos, allKeywords);
    }
}

function enqueueNewVideos(discovered, pending, skip) {
    if (discovered.size >= CONFIG.scan.maxTotalVideos) return;
    const elements = getAllVideoElements();
    let skippedCount = 0;

    for (const el of elements) {
        if (discovered.size >= CONFIG.scan.maxTotalVideos) break;
        const data = extractVideoData(el);
        if (!data || !data.url) continue;

        const id = data.url;
        if (discovered.has(id)) continue;
        discovered.add(id);

        // Skip already-watched videos
        if (data.key && skip?.has?.(data.key)) {
            skippedCount++;
            continue;
        }

        pending.push(data);
    }

    if (skippedCount > 0) {
        console.log(`[Niche Filter] Skipped ${skippedCount} already-watched video(s)`);
    }
}

async function scrollAndWaitForMore() {
    const before = getAllVideoElements().length;
    await HUMAN.scrollBy(Math.max(window.innerHeight * 1.5, 900));

    const start = Date.now();
    while (Date.now() - start < CONFIG.scan.waitForNewItemsMs) {
        const current = getAllVideoElements().length;
        if (current > before) return;
        await sleep(100); // Check more frequently (100ms instead of 200ms)
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ============================================
// Initialization
// ============================================
console.log('[YouTube Niche Filter] Content script loaded with Brain integration');

HUMAN.init();
HUMAN.presence();

// If we navigated here via the extension, try to start playback.
if (
    window.location.pathname === '/watch' ||
    window.location.pathname.startsWith('/live/') ||
    window.location.pathname.startsWith('/shorts/')
) {
    maybeAutoplayIfRequested();
}

// Auto-cycle: watch a percentage of the video, return home, pick a new video.
maybeContinueCycle();
startCycleWatchdog();

// Delayed retry: If on home feed with active cycle but scan didn't start, retry
setTimeout(() => {
    if (isYouTubeHomeFeed() && !cycleScanInProgress) {
        const state = loadCycleState();
        if (state && state.active === true && automationEnabled && !stopRequested) {
            // Only retry if no scan location is set (meaning previous scan failed or never ran)
            if (!cycleLastAutoScanLocation) {
                console.log('[Niche Filter] Delayed retry: Checking if scan needed');
                maybeContinueCycle();
            }
        }
    }
}, 3000); // 3 second delay

// YouTube is an SPA; re-check on internal navigations.
window.addEventListener('yt-navigate-finish', () => {
    openInProgress = false;
    HUMAN.presence();
    maybeAutoplayIfRequested();
    maybeContinueCycle();
});

window.addEventListener('yt-page-data-updated', () => {
    maybeAutoplayIfRequested();
    maybeContinueCycle();
});

