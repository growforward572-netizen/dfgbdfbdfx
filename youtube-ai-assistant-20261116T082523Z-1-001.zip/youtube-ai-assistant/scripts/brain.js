/**
 * YouTube Niche Filter - AI Brain Engine
 * Central thinking system. Uses NVIDIA Nemotron models (and FreeLLMAPI if it is
 * running on this PC). Whenever the AI is unavailable, matching falls back to
 * keyword scoring and comments/queries to templates, so the cycle never stalls.
 */

const BRAIN_CONFIG = {
    temperature: 0.1,
    // Extra tokens allowed on top of each action's budget in case the model
    // emits reasoning tokens before the JSON answer.
    reasoningHeadroomTokens: 400,
    topP: 0.85,
    enableThinking: false
};

// GLM 5.3 on the shared NVIDIA endpoint can be slow, so timeouts are generous.
// Every action has a non-AI fallback, so a timeout never stalls the cycle.
const ACTION_CONFIG = {
    default: { maxTokens: 160, requestTimeoutMs: 45000 },
    analyzeVideo: { maxTokens: 80, requestTimeoutMs: 40000 },
    analyzeVideoBatch: { maxTokens: 260, requestTimeoutMs: 60000 },
    generateComment: { maxTokens: 90, requestTimeoutMs: 45000, temperature: 0.8 },
    generateSearchQueries: { maxTokens: 140, requestTimeoutMs: 45000, temperature: 0.6 },
    generateSearchTitle: { maxTokens: 80, requestTimeoutMs: 40000, temperature: 0.6 },
    generateKeywords: { maxTokens: 200, requestTimeoutMs: 40000 },
    decide: { maxTokens: 120, requestTimeoutMs: 40000 }
};

// Providers are tried in order; the first JSON answer wins. If all fail, callers
// fall back to keyword matching and comment templates, so the cycle never stalls.
const PROVIDERS = [
    {
        name: 'nvidia',
        keyPrefix: 'nvapi-',
        apiUrl: 'https://integrate.api.nvidia.com/v1/chat/completions',
        // In testing Ultra matched correctly 4/4; Lightning is the faster backup.
        models: ['nvidia/nemotron-3-ultra-550b-a55b', 'nvidia/nemotron-3.5-lightning-30b-a3b'],
        apiKey: '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',
        supportsThinking: true,
        local: false,
        timeoutMs: 15000
    },
    {
        // Only used when FreeLLMAPI happens to be running on this PC.
        name: 'freellmapi',
        keyPrefix: 'freellmapi-',
        apiUrl: 'http://127.0.0.1:31415/v1/chat/completions',
        models: ['kilo-auto'],
        apiKey: 'freellmapi-c442e15dfc9d7d903a0002d726f05b5ffdb56009a0e6250e',
        supportsThinking: false,
        local: true,
        timeoutMs: 15000
    }
];

// A model that fails twice in a row is skipped for a while so calls don't keep
// waiting on a struggling endpoint.
const MODEL_FAILURE_LIMIT = 2;
const MODEL_COOLDOWN_MS = 5 * 60_000;
const modelHealth = new Map(); // "provider:model" -> { failures, cooldownUntil }

const KEY_PREFIXES = PROVIDERS.map(provider => provider.keyPrefix);

// Bump when the key setup changes so stale keys saved in storage are cleared.
const API_KEY_VERSION = 5;

// Key entered in Settings; it replaces the built-in key of the matching provider.
let USER_API_KEY = '';

function getProviderKey(provider) {
    return USER_API_KEY.startsWith(provider.keyPrefix) ? USER_API_KEY : provider.apiKey;
}

function recordModelResult(id, ok) {
    if (ok) {
        modelHealth.delete(id);
        return;
    }
    const health = modelHealth.get(id) || { failures: 0, cooldownUntil: 0 };
    health.failures += 1;
    if (health.failures >= MODEL_FAILURE_LIMIT) {
        health.failures = 0;
        health.cooldownUntil = Date.now() + MODEL_COOLDOWN_MS;
    }
    modelHealth.set(id, health);
}

function isModelCoolingDown(id) {
    return (modelHealth.get(id)?.cooldownUntil || 0) > Date.now();
}

function isSupportedKey(apiKey) {
    return KEY_PREFIXES.some(prefix => String(apiKey || '').startsWith(prefix));
}

function formatApiError(status, statusText, detail, apiUrl) {
    const base = `API Error: ${status}${statusText ? ` ${statusText}` : ''}`;
    let detailText = detail;
    if (detailText && typeof detailText !== 'string') {
        try {
            detailText = JSON.stringify(detailText);
        } catch {
            detailText = String(detailText);
        }
    }
    const suffix = detailText ? ` - ${detailText}` : '';
    const endpoint = apiUrl ? ` @ ${apiUrl}` : '';
    return `${base}${suffix}${endpoint}`;
}

function cleanText(value, fallback = 'None') {
    const text = String(value ?? '')
        .replace(/\s+/g, ' ')
        .trim();
    return text || fallback;
}

function cleanList(values, limit = 8) {
    if (!Array.isArray(values)) return [];
    return values
        .map(value => cleanText(value, ''))
        .filter(Boolean)
        .slice(0, limit);
}

function clampScore(value, fallback = 0) {
    const score = Number(value);
    if (!Number.isFinite(score)) return fallback;
    return Math.max(0, Math.min(100, Math.round(score)));
}

class Brain {
    constructor() {
        this.isInitialized = false;
        this.systemPrompt = this.getSystemPrompt();
    }

    async initialize() {
        try {
            const result = await chrome.storage.local.get(['brainApiKey', 'brainApiKeyVersion']);
            if (result.brainApiKeyVersion !== API_KEY_VERSION) {
                // Saved key belongs to the previous model setup; use the new default.
                await chrome.storage.local.remove('brainApiKey');
                await chrome.storage.local.set({ brainApiKeyVersion: API_KEY_VERSION });
            } else if (isSupportedKey(result.brainApiKey)) {
                USER_API_KEY = result.brainApiKey;
            } else if (result.brainApiKey) {
                try {
                    await chrome.storage.local.remove('brainApiKey');
                } catch {
                    // ignore
                }
            }
            this.isInitialized = true;
            console.log('[Brain] Initialized successfully');
            return true;
        } catch (error) {
            console.error('[Brain] Initialization error:', error);
            return false;
        }
    }

    getSystemPrompt() {
        return 'You are a YouTube assistant brain. Return JSON only. No markdown. Keep reasoning short and literal.';
    }

    hasApiKey() {
        return PROVIDERS.some(provider => Boolean(getProviderKey(provider)));
    }

    getActionConfig(action) {
        return ACTION_CONFIG[action] || ACTION_CONFIG.default;
    }

    async think(action, context) {
        if (!this.isInitialized) {
            await this.initialize();
        }

        // Keyword mode: no network call, answer from local rules straight away.
        if (!this.hasApiKey()) {
            return this.getFallbackDecision(action, context);
        }

        try {
            const prompt = this.buildPrompt(action, context);
            const response = await this.callAPI(action, prompt);
            const decision = this.normalizeDecision(action, this.parseResponse(response));
            if (!decision) {
                console.warn(`[Brain] Unusable answer for ${action}; using fallback`);
                return this.getFallbackDecision(action, context);
            }
            console.log(`[Brain] Action: ${action}`, decision);
            return decision;
        } catch (error) {
            console.error(`[Brain] API error for action ${action}:`, error.message);
            return this.getFallbackDecision(action, context);
        }
    }

    /**
     * Make sure the answer has what the caller reads (models sometimes put fields at
     * the top level or omit them). Returns null when it can't be used.
     */
    normalizeDecision(action, decision) {
        if (!decision || typeof decision !== 'object') return null;
        const data = decision.data && typeof decision.data === 'object' ? decision.data : {};
        decision.data = data;

        if (action === 'generateComment') {
            const comment = [data.comment, decision.comment, data.text].find(v => typeof v === 'string' && v.trim());
            if (!comment) return null;
            data.comment = comment.trim();
        } else if (action === 'generateSearchQueries') {
            const queries = Array.isArray(data.queries) ? data.queries : decision.queries;
            if (!Array.isArray(queries) || !queries.some(q => typeof q === 'string' && q.trim())) return null;
            data.queries = queries.filter(q => typeof q === 'string' && q.trim());
        } else if (action === 'generateSearchTitle') {
            const query = [data.query, decision.query].find(v => typeof v === 'string' && v.trim());
            if (!query && !Array.isArray(data.queries)) return null;
            if (query) data.query = query.trim();
        } else if (action === 'generateKeywords') {
            const list = Array.isArray(data.keywords) ? data.keywords : decision.keywords;
            if (!Array.isArray(list) || !list.some(k => typeof k === 'string' && k.trim())) return null;
            data.keywords = list.filter(k => typeof k === 'string' && k.trim());
        } else if (action === 'analyzeVideoBatch') {
            const matches = Array.isArray(data.matches) ? data.matches : decision.matches;
            if (!Array.isArray(matches)) return null;
            data.matches = matches;
        }

        return decision;
    }

    buildPrompt(action, context = {}) {
        const category = cleanText(context.category || context.niche);
        const hints = cleanList(context.categoryHints);
        const keywords = cleanList(context.keywords, 12);

        const prompts = {
            analyzeVideo: () => [
                'Task: decide if the title fits the category.',
                `Category: ${category}`,
                `Hints: ${hints.join(', ') || 'None'}`,
                `Keywords: ${keywords.join(', ') || 'None'}`,
                `Title: ${cleanText(context.title)}`,
                'Return JSON only:',
                '{"decision":"approve|reject","confidence":0-100,"reasoning":"short","data":{"score":0-100,"relevant":true|false}}',
                'Reject weak or off-topic titles.'
            ].join('\n'),

            analyzeVideoBatch: () => [
                'Task: mark which titles fit the category.',
                `Category: ${category}`,
                `Hints: ${hints.join(', ') || 'None'}`,
                `Keywords: ${keywords.join(', ') || 'None'}`,
                'Titles (0-based):',
                Array.isArray(context.videos)
                    ? context.videos.map((video, index) => `${index}|${cleanText(video?.title)}`).join('\n')
                    : 'None',
                'Return JSON only:',
                '{"decision":"analyze","confidence":0-100,"reasoning":"short","data":{"matches":[{"index":0,"score":0-100,"relevant":true|false}]}}',
                'Include every index once. Reject uncertain titles.'
            ].join('\n'),

            generateComment: () => [
                'Task: write one YouTube comment as a regular viewer who just watched this video.',
                `Title: ${cleanText(context.title)}`,
                `Description: ${cleanText((context.description || '').slice(0, 300))}`,
                `Style: ${cleanText(context.style, 'casual reaction')}`,
                'Rules: under 120 chars, casual everyday tone, mention something specific from the title or description,',
                'no generic praise like "great video", no emoji, no hashtags, no links, no self-promotion.',
                'Return JSON only:',
                '{"decision":"comment","data":{"comment":"text"}}'
            ].join('\n'),

            generateSearchQueries: () => [
                `Task: generate 5 YouTube search queries${context.purpose ? ` to ${cleanText(context.purpose)}` : ''}.`,
                `Category: ${category}`,
                `Keywords: ${keywords.join(', ') || 'None'}`,
                'Rules: natural language, 2-6 words, varied phrasing.',
                'Return JSON only:',
                '{"decision":"action","data":{"queries":["query 1","query 2","query 3","query 4","query 5"]}}'
            ].join('\n'),

            generateSearchTitle: () => [
                'Task: generate one YouTube search query based on watched titles.',
                `Category: ${category}`,
                `Keywords: ${keywords.join(', ') || 'None'}`,
                'Watched titles:',
                cleanList(context.watchedTitles, 6).map((title, index) => `${index + 1}|${title}`).join('\n') || 'None',
                'Rules: 3-8 words, natural, specific, no emoji, no quotes.',
                'Return JSON only:',
                '{"decision":"action","data":{"query":"single query"}}'
            ].join('\n'),

            generateKeywords: () => [
                'Task: list 20 single words that often appear in YouTube video titles in this niche: 5 techniques, 5 tools, 5 materials and 5 typical projects or results.',
                `Category: ${cleanText(context.data?.category || context.category)}`,
                `Known keywords: ${keywords.join(', ') || 'None'}`,
                'Rules: single words, lowercase, specific to the niche; no generic words like video, best, tutorial, how, diy, make, build.',
                'Return JSON only:',
                '{"decision":"action","data":{"keywords":["keyword 1","keyword 2"]}}'
            ].join('\n'),

            decide: () => [
                `Task: ${cleanText(context.task, 'Make a decision')}`,
                `Context: ${JSON.stringify(context.data || {})}`,
                'Return JSON only:',
                '{"decision":"action","confidence":0-100,"reasoning":"short","data":{}}'
            ].join('\n'),

            default: () => [
                `Action: ${cleanText(action)}`,
                `Context: ${JSON.stringify(context || {})}`,
                'Return JSON only:',
                '{"decision":"action","confidence":0-100,"reasoning":"short","data":{}}'
            ].join('\n')
        };

        return (prompts[action] || prompts.default)();
    }

    async callAPI(action, userMessage) {
        let lastError = new Error('API Error: all models are cooling down');

        for (const provider of PROVIDERS) {
            const apiKey = getProviderKey(provider);
            if (!apiKey) continue;

            for (const model of provider.models) {
                const id = `${provider.name}:${model}`;
                if (isModelCoolingDown(id)) continue;

                try {
                    const content = await this.callModel(action, userMessage, provider, apiKey, model);
                    // A reply without JSON (e.g. the model only wrote its reasoning) counts as a failure.
                    if (!/\{[\s\S]*\}/.test(content.replace(/<think>[\s\S]*?<\/think>/gi, ''))) {
                        throw new Error('API Error: no JSON in response');
                    }
                    recordModelResult(id, true);
                    this.lastModel = id;
                    return content;
                } catch (error) {
                    lastError = error;
                    console.warn(`[Brain] ${id} failed:`, error.message);

                    // Local router not running, or a rejected key: skip the whole provider for now.
                    const providerDown =
                        /\b(401|403)\b/.test(error.message || '') ||
                        (provider.local && /failed to fetch|fetch failed|ECONNREFUSED/i.test(error.message || ''));
                    if (providerDown) {
                        const until = Date.now() + MODEL_COOLDOWN_MS;
                        provider.models.forEach(m => modelHealth.set(`${provider.name}:${m}`, { failures: 0, cooldownUntil: until }));
                        break;
                    }
                    recordModelResult(id, false);
                }
            }
        }

        throw lastError;
    }

    async callModel(action, userMessage, provider, apiKey, model) {
        const actionConfig = this.getActionConfig(action);
        const controller = new AbortController();
        const timeoutMs = Math.min(actionConfig.requestTimeoutMs, provider.timeoutMs);
        const timeout = setTimeout(() => controller.abort(), timeoutMs);

        const headers = {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };

        const payload = {
            model,
            messages: [
                { role: 'system', content: this.systemPrompt },
                { role: 'user', content: userMessage }
            ],
            max_tokens: actionConfig.maxTokens + BRAIN_CONFIG.reasoningHeadroomTokens,
            temperature: actionConfig.temperature ?? BRAIN_CONFIG.temperature,
            top_p: BRAIN_CONFIG.topP,
            stream: false
        };

        if (provider.supportsThinking) {
            // Different model templates read different flag names; send both.
            payload.chat_template_kwargs = {
                thinking: BRAIN_CONFIG.enableThinking,
                enable_thinking: BRAIN_CONFIG.enableThinking
            };
        }

        let response;
        try {
            response = await fetch(provider.apiUrl, {
                method: 'POST',
                headers,
                body: JSON.stringify(payload),
                signal: controller.signal
            });
        } catch (error) {
            const message = error?.name === 'AbortError' || /aborted/i.test(error?.message || '')
                ? 'API Error: timeout'
                : (error?.message || 'API Error: request failed');
            throw new Error(message);
        } finally {
            clearTimeout(timeout);
        }

        if (!response.ok) {
            const raw = await response.text();
            let detail = raw;
            try {
                const parsed = JSON.parse(raw);
                detail = parsed.detail || parsed.error || parsed.message || raw;
            } catch {
                // use raw text
            }

            // Forget a rejected key from Settings so the built-in key is used again.
            if ((response.status === 401 || response.status === 403) && apiKey === USER_API_KEY) {
                USER_API_KEY = '';
                try {
                    await chrome.storage.local.remove('brainApiKey');
                } catch {
                    // ignore
                }
            }

            throw new Error(formatApiError(response.status, response.statusText, detail, provider.apiUrl));
        }

        const data = await response.json();
        const message = data.choices?.[0]?.message || {};
        // If the model spent its answer in the reasoning channel, the JSON may live there.
        const content = message.content || message.reasoning_content || '';
        if (!content) {
            throw new Error('API Error: empty response');
        }

        return content;
    }

    parseResponse(responseText) {
        try {
            // Strip <think> blocks some reasoning models prepend to the answer.
            const cleaned = String(responseText || '').replace(/<think>[\s\S]*?<\/think>/gi, '');
            const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            }

            return {
                decision: 'unknown',
                confidence: 50,
                reasoning: responseText,
                data: {}
            };
        } catch (error) {
            console.error('[Brain] Parse error:', error);
            return {
                decision: 'error',
                confidence: 0,
                reasoning: 'Failed to parse brain response',
                data: { raw: responseText }
            };
        }
    }

    getFallbackDecision(action, context = {}) {
        console.log('[Brain] Using fallback decision logic');

        if (action === 'analyzeVideo') {
            return {
                decision: 'fallback',
                confidence: 0,
                reasoning: 'API unavailable',
                data: { score: 0, relevant: false }
            };
        }

        if (action === 'generateSearchQueries') {
            const keywords = cleanList(context.keywords, 12);
            const category = cleanText(context.category, 'videos');
            const queries = [];
            for (let index = 0; index < 5; index += 1) {
                if (keywords.length > 0) {
                    queries.push(`${category} ${keywords[index % keywords.length]}`);
                } else {
                    queries.push(`best ${category} ${new Date().getFullYear()}`);
                }
            }
            return {
                decision: 'action',
                confidence: 40,
                reasoning: 'Fallback: keyword-based search queries',
                data: { queries }
            };
        }

        if (action === 'generateSearchTitle') {
            const titles = cleanList(context.watchedTitles, 6);
            const keywords = cleanList(context.keywords, 12);
            const category = cleanText(context.category, 'videos');

            let query = '';

            if (titles.length > 0) {
                const pickedTitle = titles[Math.floor(Math.random() * titles.length)];
                query = String(pickedTitle || '')
                    .replace(/[#@][^\s]+/g, ' ')
                    .replace(/[^a-zA-Z0-9\s]/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .split(' ')
                    .slice(0, 6)
                    .join(' ');
            }

            if (!query && keywords.length > 0) {
                query = `${keywords[Math.floor(Math.random() * keywords.length)]} tutorial`;
            }

            if (!query) {
                query = `best ${category} tips`;
            }

            return {
                decision: 'action',
                confidence: 40,
                reasoning: 'Fallback: title-derived search query',
                data: { query }
            };
        }

        if (action === 'generateComment') {
            return {
                decision: 'comment',
                confidence: 60,
                reasoning: 'Fallback: comment template',
                data: { comment: buildTemplateComment(context) }
            };
        }

        if (action === 'generateKeywords') {
            const category = cleanText(context.data?.category || context.category, 'general');
            return {
                decision: 'action',
                confidence: 40,
                reasoning: 'Fallback: category-derived keywords',
                data: { keywords: cleanList(category.split(/\s+/), 8) }
            };
        }

        return {
            decision: 'fallback',
            confidence: 50,
            reasoning: 'API unavailable, using fallback logic',
            data: {}
        };
    }

    async setApiKey(newKey) {
        USER_API_KEY = newKey;
        await chrome.storage.local.set({ brainApiKey: newKey, brainApiKeyVersion: API_KEY_VERSION });
        console.log('[Brain] API key updated');
    }

    async test() {
        if (!this.hasApiKey()) {
            return {
                success: true,
                keywordMode: true,
                result: { reasoning: 'No API key set; using keyword matching and comment templates.' }
            };
        }

        // Call the API directly: think() would hide a failure behind the fallback.
        try {
            const prompt = this.buildPrompt('decide', {
                task: 'Respond with a simple test confirmation',
                data: { test: true }
            });
            const response = await this.callAPI('decide', prompt);
            return { success: true, model: this.lastModel, result: this.parseResponse(response) };
        } catch (error) {
            return { success: false, error: `${error.message} (keyword mode will be used instead)` };
        }
    }
}

/**
 * Comment without AI: pick a template matching the requested style and fill in
 * the niche keyword that appears in the title (or the first keyword).
 */
function buildTemplateComment(context = {}) {
    const title = cleanText(context.title, '').toLowerCase();
    const keywords = cleanList(context.keywords, 12).filter(k => k.length >= 3);
    const topic = keywords.find(k => title.includes(k.toLowerCase())) || keywords[0] || 'this';
    const style = cleanText(context.style, '').toLowerCase();

    const byStyle = {
        question: [
            `How long did it take you to get comfortable with ${topic}?`,
            `Would you do this differently if you were starting with ${topic} today?`,
            `Any beginner mistakes with ${topic} you wish someone had warned you about?`,
            `Do you have a follow up planned on this? Would love more ${topic} content like it`
        ],
        experience: [
            `I tried something similar with ${topic} last month and ran into exactly this`,
            `This is the step I kept getting wrong with ${topic}, makes sense now`,
            `Been getting into ${topic} recently and this filled in a few gaps for me`,
            `Wish I had seen this before my first attempt at ${topic}`
        ],
        agree: [
            `Agree with the point about taking it slow, rushing ${topic} never works out`,
            `That middle section is underrated, most ${topic} videos skip it`,
            `Totally agree, the basics matter way more than people think in ${topic}`
        ],
        casual: [
            `Did not expect to watch this whole thing but here I am`,
            `The way you explained this made ${topic} click for me`,
            `Saving this one for later, really clear walkthrough`,
            `Underrated channel for ${topic}, glad this showed up in my feed`,
            `This was way more useful than the last few ${topic} videos I watched`
        ]
    };

    let pool = byStyle.casual;
    if (style.includes('question')) pool = byStyle.question;
    else if (style.includes('experience')) pool = byStyle.experience;
    else if (style.includes('agree')) pool = byStyle.agree;

    return pool[Math.floor(Math.random() * pool.length)];
}

const brain = new Brain();
self.brain = brain;
