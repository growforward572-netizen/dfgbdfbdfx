/**
 * YouTube Niche Filter - Human Behavior Engine
 *
 * Everything the automation does goes through here so the session looks like a
 * person on a mouse and keyboard instead of a script:
 *
 *   - pointer travel along curved paths with easing, overshoot and hover dwell
 *   - clicks with real pointerdown -> pointerup timing and occasional misses
 *   - typing at a human WPM with typos, backspaces and thinking pauses
 *   - wheel/momentum scrolling with overshoot and scroll-back
 *   - in-video behavior: pause/resume, seek-back, volume, speed, fullscreen,
 *     hovering the player, scrolling to comments and back
 *   - idle micro-movement so the cursor never sits still for minutes
 *   - session fatigue and periodic breaks
 *
 * Loaded before content.js in the same isolated world, exposed as
 * window.__HUMAN__. Every method degrades to a plain click/scroll when the
 * human layer is switched off.
 */
(() => {
    'use strict';

    if (window.__HUMAN__) return;

    const DEFAULTS = {
        enabled: true,
        // 0.6 = brisk, 1 = normal, 1.7 = deliberately slow
        intensity: 1
    };

    const config = { ...DEFAULTS };

    const state = {
        x: 0,
        y: 0,
        seeded: false,
        lastActivity: Date.now(),
        typing: false,
        watch: null,
        nextBreakAt: 0,
        sessionStart: Date.now(),
        started: false
    };

    // ---------------------------------------------------------------
    // Random helpers
    // ---------------------------------------------------------------
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const rand = (min, max) => min + Math.random() * (max - min);
    const randInt = (min, max) => Math.floor(rand(min, max + 1));
    const chance = (probability) => Math.random() < probability;
    const pick = (list) => (Array.isArray(list) && list.length ? list[randInt(0, list.length - 1)] : null);

    function gauss(mean = 0, deviation = 1) {
        let u = 0;
        let v = 0;
        while (u === 0) u = Math.random();
        while (v === 0) v = Math.random();
        return mean + deviation * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
    }

    const scale = (ms) => Math.max(1, Math.round(ms * config.intensity));
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, scale(ms)));
    const touch = () => {
        state.lastActivity = Date.now();
    };

    // ---------------------------------------------------------------
    // Settings
    // ---------------------------------------------------------------
    function applySettings(values) {
        if (!values) return;
        if (typeof values.humanMode === 'boolean') config.enabled = values.humanMode;
        if (Number.isFinite(values.humanIntensity)) {
            config.intensity = clamp(values.humanIntensity, 0.5, 2);
        }
    }

    function init() {
        if (state.started) return;
        state.started = true;

        try {
            chrome.storage.local.get(['humanMode', 'humanIntensity'], applySettings);
            chrome.storage.local.get(['stats_totalSessions'], (result) => {
                state.sessions = Number(result?.stats_totalSessions) || 0;
            });
            chrome.storage.onChanged.addListener((changes, area) => {
                if (area !== 'local') return;
                if (changes.humanMode) config.enabled = changes.humanMode.newValue !== false;
                if (changes.humanIntensity) {
                    const next = Number(changes.humanIntensity.newValue);
                    if (Number.isFinite(next)) config.intensity = clamp(next, 0.5, 2);
                }
            });
        } catch {
            // storage unavailable, keep defaults
        }

        state.nextBreakAt = Date.now() + rand(35, 75) * 60_000;
        seedPointer();
    }

    // ---------------------------------------------------------------
    // Pointer
    // ---------------------------------------------------------------
    function seedPointer() {
        if (state.seeded) return;
        state.seeded = true;
        state.x = randInt(120, Math.max(240, window.innerWidth - 160));
        state.y = randInt(120, Math.max(200, window.innerHeight - 200));
        dispatchMove(state.x, state.y, 0, 0);
    }

    function pointerEventTarget(x, y) {
        try {
            return document.elementFromPoint(x, y) || document.documentElement;
        } catch {
            return document.documentElement;
        }
    }

    function dispatchMove(x, y, movementX, movementY) {
        const target = pointerEventTarget(x, y);
        const base = {
            bubbles: true,
            cancelable: true,
            composed: true,
            view: window,
            clientX: Math.round(x),
            clientY: Math.round(y),
            screenX: Math.round(x),
            screenY: Math.round(y),
            movementX: Math.round(movementX),
            movementY: Math.round(movementY)
        };

        try {
            target.dispatchEvent(new PointerEvent('pointermove', { ...base, pointerType: 'mouse', isPrimary: true }));
        } catch {
            // ignore
        }
        target.dispatchEvent(new MouseEvent('mousemove', base));
    }

    /**
     * Move the virtual cursor along a curved, eased path.
     */
    async function moveTo(targetX, targetY, options = {}) {
        if (!config.enabled) {
            state.x = targetX;
            state.y = targetY;
            return;
        }

        seedPointer();
        touch();

        const fromX = state.x;
        const fromY = state.y;
        const distance = Math.hypot(targetX - fromX, targetY - fromY);
        if (distance < 3) {
            state.x = targetX;
            state.y = targetY;
            return;
        }

        const steps = clamp(Math.round(distance / rand(16, 38)), 5, options.maxSteps || 55);
        const bend = Math.min(120, distance * rand(0.08, 0.22)) * (chance(0.5) ? 1 : -1);
        const normalX = -(targetY - fromY) / (distance || 1);
        const normalY = (targetX - fromX) / (distance || 1);
        const controlX = (fromX + targetX) / 2 + normalX * bend;
        const controlY = (fromY + targetY) / 2 + normalY * bend;

        let previousX = fromX;
        let previousY = fromY;

        for (let step = 1; step <= steps; step += 1) {
            const t = step / steps;
            // ease-in-out with a little hand tremor
            const eased = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
            const wobble = step === steps ? 0 : gauss(0, 1.1);
            const x = (1 - eased) * (1 - eased) * fromX + 2 * (1 - eased) * eased * controlX + eased * eased * targetX + wobble;
            const y = (1 - eased) * (1 - eased) * fromY + 2 * (1 - eased) * eased * controlY + eased * eased * targetY + wobble;

            dispatchMove(x, y, x - previousX, y - previousY);
            previousX = x;
            previousY = y;

            await delay(rand(5, 15));
        }

        state.x = targetX;
        state.y = targetY;
    }

    function isInViewport(rect) {
        return rect.top >= 0 && rect.left >= 0 && rect.bottom <= window.innerHeight && rect.right <= window.innerWidth;
    }

    /**
     * Aim at a point inside an element, never dead center.
     */
    function aimPoint(element) {
        const rect = element.getBoundingClientRect();
        let x = rect.left + rect.width * rand(0.28, 0.72);
        let y = rect.top + rect.height * rand(0.3, 0.7);

        // Nudge off the exact center pixel.
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        if (Math.abs(x - centerX) < 2) x += rand(2, 6);
        if (Math.abs(y - centerY) < 2) y += rand(2, 5);

        return { x: clamp(x, rect.left + 2, rect.right - 2), y: clamp(y, rect.top + 2, rect.bottom - 2) };
    }

    async function moveToElement(element, options = {}) {
        if (!element) return null;

        let rect = element.getBoundingClientRect();
        if (options.scroll !== false && !isInViewport(rect)) {
            await scrollToElement(element);
            rect = element.getBoundingClientRect();
        }

        const point = aimPoint(element);
        await moveTo(point.x, point.y, options);
        return point;
    }

    function dispatchHover(element, point) {
        const base = {
            bubbles: true,
            cancelable: true,
            composed: true,
            view: window,
            clientX: Math.round(point.x),
            clientY: Math.round(point.y)
        };

        try {
            element.dispatchEvent(new PointerEvent('pointerover', { ...base, pointerType: 'mouse', isPrimary: true }));
            element.dispatchEvent(new PointerEvent('pointerenter', { ...base, pointerType: 'mouse', isPrimary: true, bubbles: false }));
        } catch {
            // ignore
        }
        element.dispatchEvent(new MouseEvent('mouseover', base));
        element.dispatchEvent(new MouseEvent('mouseenter', { ...base, bubbles: false }));
    }

    async function hover(element) {
        if (!element) return false;
        if (!config.enabled) return true;

        const point = await moveToElement(element);
        if (!point) return false;
        dispatchHover(element, point);
        await delay(rand(120, 420));
        return true;
    }

    /**
     * Human click: travel, hover, press, release. Sometimes misses first.
     */
    async function click(element, options = {}) {
        if (!element) return false;
        if (element.disabled) return false;

        if (!config.enabled) {
            try {
                element.focus?.({ preventScroll: true });
                element.click();
                return true;
            } catch {
                return false;
            }
        }

        touch();

        // Hidden controls can have a zero-size box; a plain click is safer there.
        const box = element.getBoundingClientRect();
        if (box.width < 2 && box.height < 2) {
            try {
                element.click();
                return true;
            } catch {
                return false;
            }
        }

        const point = await moveToElement(element, options);
        if (!point) return false;

        // Overshoot onto a neighbouring pixel, then correct - like a real hand.
        if (chance(options.missChance ?? 0.07)) {
            await moveTo(point.x + rand(-26, 26), point.y + rand(-18, 18), { maxSteps: 8 });
            await delay(rand(90, 260));
            await moveTo(point.x, point.y, { maxSteps: 8 });
        }

        dispatchHover(element, point);

        const base = {
            bubbles: true,
            cancelable: true,
            composed: true,
            view: window,
            clientX: Math.round(point.x),
            clientY: Math.round(point.y),
            button: 0,
            detail: 1
        };

        try {
            element.focus?.({ preventScroll: true });
        } catch {
            // ignore
        }

        await delay(rand(55, 190));

        try {
            element.dispatchEvent(new PointerEvent('pointerdown', { ...base, pointerType: 'mouse', isPrimary: true, buttons: 1 }));
        } catch {
            // ignore
        }
        element.dispatchEvent(new MouseEvent('mousedown', { ...base, buttons: 1 }));

        await delay(rand(35, 120));

        try {
            element.dispatchEvent(new PointerEvent('pointerup', { ...base, pointerType: 'mouse', isPrimary: true, buttons: 0 }));
        } catch {
            // ignore
        }
        element.dispatchEvent(new MouseEvent('mouseup', { ...base, buttons: 0 }));
        element.dispatchEvent(new MouseEvent('click', base));

        return true;
    }

    // ---------------------------------------------------------------
    // Keyboard
    // ---------------------------------------------------------------
    const KEY_CODES = {
        Enter: 13,
        Backspace: 8,
        Escape: 27,
        Tab: 9,
        ' ': 32
    };

    function keyInit(key) {
        return {
            key,
            code: key === ' ' ? 'Space' : key.length === 1 ? `Key${key.toUpperCase()}` : key,
            keyCode: KEY_CODES[key] || (key.length === 1 ? key.toUpperCase().charCodeAt(0) : 0),
            which: KEY_CODES[key] || (key.length === 1 ? key.toUpperCase().charCodeAt(0) : 0),
            bubbles: true,
            cancelable: true,
            composed: true,
            view: window
        };
    }

    function pressKey(key, target = document.activeElement || document.body) {
        if (!target) return;
        const init = keyInit(key);
        target.dispatchEvent(new KeyboardEvent('keydown', init));
        if (key.length === 1 || key === 'Enter') {
            target.dispatchEvent(new KeyboardEvent('keypress', init));
        }
        target.dispatchEvent(new KeyboardEvent('keyup', init));
    }

    function setNativeValue(element, value) {
        try {
            const prototype = element instanceof HTMLTextAreaElement
                ? HTMLTextAreaElement.prototype
                : HTMLInputElement.prototype;
            const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
            if (setter) setter.call(element, value);
            else element.value = value;
        } catch {
            element.value = value;
        }
    }

    function insertCharacter(element, character) {
        if (element.isContentEditable) {
            try {
                document.execCommand('insertText', false, character);
                return;
            } catch {
                // fall through
            }
            element.textContent = `${element.textContent || ''}${character}`;
            element.dispatchEvent(new InputEvent('input', { bubbles: true, data: character, inputType: 'insertText' }));
            return;
        }

        setNativeValue(element, `${element.value || ''}${character}`);
        element.dispatchEvent(new InputEvent('input', { bubbles: true, data: character, inputType: 'insertText' }));
    }

    function deleteCharacter(element) {
        if (element.isContentEditable) {
            try {
                document.execCommand('delete', false, null);
                return;
            } catch {
                // fall through
            }
            element.textContent = (element.textContent || '').slice(0, -1);
            element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
            return;
        }

        setNativeValue(element, (element.value || '').slice(0, -1));
        element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
    }

    /**
     * Type like a person: variable speed, thinking pauses, typos + backspace.
     */
    async function type(element, text, options = {}) {
        if (!element || typeof text !== 'string') return false;

        const value = text.slice(0, options.maxLength || 400);
        if (!config.enabled) {
            element.focus?.();
            if (element.isContentEditable) {
                try {
                    document.execCommand('insertText', false, value);
                } catch {
                    element.textContent = value;
                }
            } else {
                setNativeValue(element, value);
                element.dispatchEvent(new Event('input', { bubbles: true }));
            }
            return true;
        }

        await click(element, { missChance: 0.03 });
        try {
            element.focus?.({ preventScroll: true });
        } catch {
            // ignore
        }
        await delay(rand(180, 520));

        const wpm = options.wpm || rand(62, 104);
        const baseMs = 60_000 / wpm / 5;
        const typoRate = options.typoRate ?? 0.018;

        state.typing = true;
        try {
            for (let index = 0; index < value.length; index += 1) {
                const character = value[index];

                if (character !== ' ' && /[a-z0-9]/i.test(character) && chance(typoRate)) {
                    const wrong = pick('abcdefghijklmnopqrstuvwxyz'.split('').filter((c) => c !== character.toLowerCase()));
                    if (wrong) {
                        pressKey(wrong, element);
                        insertCharacter(element, wrong);
                        await delay(rand(90, 260));
                        pressKey('Backspace', element);
                        deleteCharacter(element);
                        await delay(rand(70, 200));
                    }
                }

                pressKey(character, element);
                insertCharacter(element, character);
                await delay(baseMs * rand(0.55, 1.75));

                if (character === ' ') await delay(rand(40, 220));
                if (/[.,!?]/.test(character)) await delay(rand(160, 620));
                if (chance(0.02)) await delay(rand(400, 1600));
            }
        } finally {
            state.typing = false;
            touch();
        }

        await delay(rand(220, 700));

        if (options.submit) {
            pressKey('Enter', element);
            await delay(rand(120, 380));
        }

        return true;
    }

    // ---------------------------------------------------------------
    // Scrolling
    // ---------------------------------------------------------------
    function dispatchWheel(deltaY) {
        const target = pointerEventTarget(state.x, state.y);
        try {
            target.dispatchEvent(new WheelEvent('wheel', {
                bubbles: true,
                cancelable: true,
                composed: true,
                view: window,
                deltaY,
                deltaMode: 0,
                clientX: Math.round(state.x),
                clientY: Math.round(state.y)
            }));
        } catch {
            // ignore
        }
    }

    function maxScrollY() {
        return Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
    }

    function animateScroll(delta) {
        return new Promise((resolve) => {
            const startY = window.scrollY;
            const targetY = clamp(startY + delta, 0, maxScrollY());
            const distance = targetY - startY;
            if (Math.abs(distance) < 2) {
                resolve();
                return;
            }

            const duration = clamp(Math.abs(distance) * rand(0.35, 0.75), 170, 850) * config.intensity;
            const startedAt = performance.now();
            const ease = (t) => 1 - Math.pow(1 - t, 3);

            const step = (now) => {
                const t = clamp((now - startedAt) / duration, 0, 1);
                window.scrollTo(0, startY + distance * ease(t));
                dispatchWheel(distance * 0.1);
                if (t < 1) requestAnimationFrame(step);
                else resolve();
            };

            requestAnimationFrame(step);
        });
    }

    /**
     * Wheel-style scroll with momentum, and sometimes an overshoot + correction.
     */
    async function scrollBy(delta, options = {}) {
        touch();

        if (!config.enabled) {
            window.scrollBy(0, delta);
            return;
        }

        const bursts = randInt(2, 4);
        let remaining = delta;

        for (let burst = 0; burst < bursts; burst += 1) {
            const portion = remaining * rand(0.45, 0.75);
            remaining -= portion;
            await animateScroll(portion);
            await delay(rand(60, 220));
            if (chance(0.25)) await delay(rand(200, 700));
        }

        if (Math.abs(remaining) > 4) await animateScroll(remaining);

        if (options.overshoot !== false && Math.abs(delta) > 200 && chance(0.22)) {
            await delay(rand(180, 520));
            await animateScroll(-Math.sign(delta) * rand(40, 130));
        }
    }

    async function scrollToElement(element) {
        if (!element) return;
        const rect = element.getBoundingClientRect();
        const targetY = window.scrollY + rect.top - window.innerHeight * rand(0.22, 0.42);
        const delta = targetY - window.scrollY;
        if (Math.abs(delta) < 40) return;
        await scrollBy(delta, { overshoot: false });
        await delay(rand(250, 700));
    }

    // ---------------------------------------------------------------
    // Navigation
    // ---------------------------------------------------------------
    function findLinkForUrl(url) {
        try {
            const wanted = new URL(url, window.location.origin);
            const anchors = document.querySelectorAll('a[href]');
            for (const anchor of anchors) {
                const href = anchor.getAttribute('href');
                if (!href || href.startsWith('javascript:')) continue;
                const candidate = new URL(href, window.location.origin);
                if (candidate.pathname !== wanted.pathname) continue;
                if (wanted.search && candidate.search !== wanted.search) continue;
                return anchor;
            }
        } catch {
            // ignore
        }
        return null;
    }

    async function navigateTo(url) {
        const link = findLinkForUrl(url);
        if (link) {
            const clicked = await click(link, { missChance: 0.04 });
            if (clicked) {
                await delay(rand(400, 900));
                return true;
            }
        }
        window.location.assign(url);
        return false;
    }

    function findSearchBox() {
        return (
            document.querySelector('ytd-searchbox input#search') ||
            document.querySelector('input#search') ||
            document.querySelector('input[name="search_query"]') ||
            document.querySelector('ytd-searchbox input') ||
            null
        );
    }

    /**
     * Use the real search box (click + type + Enter) so the navigation is an
     * in-page SPA transition, not a hard load.
     */
    async function search(query, fallbackUrl) {
        const box = findSearchBox();

        if (box) {
            const ok = await type(box, query, { wpm: rand(78, 118), submit: true, typoRate: 0.012 });
            if (ok) {
                // Give the SPA navigation a moment before deciding it failed.
                const startedAt = Date.now();
                while (Date.now() - startedAt < 4_000) {
                    if (window.location.pathname.startsWith('/results')) return true;
                    await delay(200);
                }
            }
        }

        if (fallbackUrl) window.location.assign(fallbackUrl);
        return false;
    }

    async function navigateHome() {
        const logo =
            document.querySelector('a#logo') ||
            document.querySelector('ytd-topbar-logo-renderer a') ||
            document.querySelector('a[href="/"]');

        if (logo) {
            const clicked = await click(logo, { missChance: 0.04 });
            if (clicked) {
                await delay(rand(500, 1100));
                return true;
            }
        }

        window.location.assign('https://www.youtube.com/');
        return false;
    }

    // ---------------------------------------------------------------
    // Idle / presence
    // ---------------------------------------------------------------
    function isIdle() {
        return Date.now() - state.lastActivity > 5_000;
    }

    async function microMove() {
        if (!config.enabled || state.typing) return;
        const x = clamp(state.x + gauss(0, 55), 20, window.innerWidth - 20);
        const y = clamp(state.y + gauss(0, 40), 20, window.innerHeight - 20);
        await moveTo(x, y, { maxSteps: 9 });
    }

    function presence() {
        touch();
        dispatchMove(state.x, state.y, 0, 0);
    }

    // ---------------------------------------------------------------
    // In-video behavior
    // ---------------------------------------------------------------
    function currentVideo() {
        return document.querySelector('#movie_player video') || document.querySelector('video');
    }

    function playerIsAd() {
        const player = document.querySelector('#movie_player, .html5-video-player');
        return Boolean(player && player.classList.contains('ad-showing'));
    }

    function stopWatchBehavior() {
        if (!state.watch) return;
        for (const timer of state.watch.timers) clearTimeout(timer);
        state.watch.stopped = true;
        state.watch = null;
    }

    async function maybePauseResume() {
        const video = currentVideo();
        if (!video || playerIsAd() || video.paused || video.ended) return;
        if (!chance(0.55)) return;

        try {
            video.pause();
        } catch {
            return;
        }
        await delay(rand(1_800, 9_000));
        if (state.watch?.stopped) return;
        try {
            await video.play();
        } catch {
            // ignore
        }
    }

    async function maybeSeekBack() {
        const video = currentVideo();
        if (!video || playerIsAd() || video.paused) return;
        if (video.currentTime < 45 || !chance(0.3)) return;

        const back = rand(4, 16);
        try {
            video.currentTime = Math.max(0, video.currentTime - back);
        } catch {
            // ignore
        }
    }

    async function maybeVolume() {
        const video = currentVideo();
        if (!video || video.muted || !chance(0.4)) return;
        try {
            video.volume = clamp(video.volume + gauss(0, 0.12), 0.25, 0.95);
        } catch {
            // ignore
        }
    }

    async function maybeSpeed() {
        const video = currentVideo();
        if (!video || playerIsAd() || !chance(0.12)) return;
        const rate = pick([1.25, 1.5]);
        if (!rate) return;

        try {
            video.playbackRate = rate;
        } catch {
            return;
        }

        const restore = setTimeout(() => {
            const current = currentVideo();
            if (current && !state.watch?.stopped) {
                try {
                    current.playbackRate = 1;
                } catch {
                    // ignore
                }
            }
        }, rand(45_000, 150_000));

        if (state.watch) state.watch.timers.push(restore);
    }

    async function maybeFullscreen() {
        const video = currentVideo();
        if (!video || playerIsAd() || !chance(0.12)) return;

        // Controls auto-hide; hover the player first so the button has a real box.
        const player = document.querySelector('#movie_player');
        if (player) {
            await hover(player);
            await delay(rand(250, 600));
        }

        const button = document.querySelector('.ytp-fullscreen-button');
        if (!button) return;
        await click(button, { missChance: 0.02 });

        const exit = setTimeout(() => {
            if (document.fullscreenElement) {
                document.exitFullscreen?.().catch(() => {});
            }
        }, rand(60_000, 240_000));

        if (state.watch) state.watch.timers.push(exit);
    }

    async function maybeScrollComments() {
        if (!chance(0.35)) return;
        const before = window.scrollY;
        await scrollBy(rand(500, 1100));
        await delay(rand(2_500, 9_000));
        await scrollBy(before - window.scrollY, { overshoot: false });
    }

    function watchBehavior() {
        stopWatchBehavior();
        if (!config.enabled) return null;

        const controller = { stopped: false, timers: [] };
        state.watch = controller;

        const later = (fn, ms) => {
            const timer = setTimeout(() => {
                if (!controller.stopped) void fn();
            }, scale(ms));
            controller.timers.push(timer);
        };

        const loop = (fn, minMs, maxMs) => {
            const step = () => {
                if (controller.stopped) return;
                later(() => {
                    fn();
                    step();
                }, rand(minMs, maxMs));
            };
            step();
        };

        loop(microMove, 9_000, 26_000);
        loop(() => hover(document.querySelector('#movie_player')), 22_000, 65_000);
        loop(maybePauseResume, 45_000, 150_000);
        loop(maybeSeekBack, 60_000, 190_000);
        loop(maybeVolume, 90_000, 260_000);
        loop(maybeScrollComments, 120_000, 320_000);
        later(maybeSpeed, rand(30_000, 90_000));
        later(maybeFullscreen, rand(60_000, 220_000));

        return controller;
    }

    // ---------------------------------------------------------------
    // Breaks / fatigue
    // ---------------------------------------------------------------
    function shouldTakeBreak() {
        return config.enabled && Date.now() >= state.nextBreakAt;
    }

    async function takeBreak() {
        state.nextBreakAt = Date.now() + rand(40, 95) * 60_000;
        const video = currentVideo();
        const wasPlaying = Boolean(video && !video.paused);

        if (wasPlaying) {
            try {
                video.pause();
            } catch {
                // ignore
            }
        }

        await delay(rand(45_000, 210_000));

        if (wasPlaying) {
            const current = currentVideo();
            try {
                await current?.play();
            } catch {
                // ignore
            }
        }
    }

    /**
     * New accounts should engage less than warmed-up ones.
     */
    function warmupFactor() {
        const sessions = state.sessions || 0;
        if (sessions < 3) return 0.6;
        if (sessions < 10) return 0.8;
        return 1;
    }

    // ---------------------------------------------------------------
    // "Not interested" on a feed card
    // ---------------------------------------------------------------
    async function maybeNotInterested() {
        if (!config.enabled || !chance(0.16)) return false;

        const cards = Array.from(document.querySelectorAll('ytd-rich-item-renderer')).slice(0, 8);
        const card = pick(cards);
        if (!card) return false;

        const menuButton = card.querySelector('#menu button, ytd-menu-renderer button, button[aria-label*="Action menu"]');
        if (!menuButton) return false;

        try {
            await hover(card);
            await click(menuButton, { missChance: 0.02 });
            await delay(rand(500, 1_100));

            const items = Array.from(document.querySelectorAll('ytd-menu-service-item-renderer, tp-yt-paper-item'));
            const target = items.find((item) => /not interested/i.test(item.textContent || ''));
            if (!target) {
                pressKey('Escape');
                return false;
            }

            await click(target, { missChance: 0.02 });
            await delay(rand(600, 1_400));
            return true;
        } catch {
            return false;
        }
    }

    // ---------------------------------------------------------------
    // Public API
    // ---------------------------------------------------------------
    window.__HUMAN__ = {
        init,
        get enabled() {
            return config.enabled;
        },
        get intensity() {
            return config.intensity;
        },
        rand,
        randInt,
        chance,
        pick,
        gauss,
        delay,
        touch,
        presence,
        moveTo,
        moveToElement,
        hover,
        click,
        type,
        pressKey,
        scrollBy,
        scrollToElement,
        navigateTo,
        navigateHome,
        search,
        watchBehavior,
        stopWatchBehavior,
        shouldTakeBreak,
        takeBreak,
        warmupFactor,
        maybeNotInterested
    };
})();
