/**
 * YouTube Niche Filter - Background Service Worker
 * Handles extension lifecycle, message routing, and brain API calls
 * 
 * All API calls go through the background worker to avoid CORS issues
 */

// Import shared modules
importScripts('brain.js', 'youtube-api.js', 'ratio-matcher.js');

// ============================================
// Extension Installation
// ============================================
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        console.log('[Niche Filter] Extension installed');

        // Set default settings
        chrome.storage.local.set({
            selectedCategory: '',
            keywordInput: '',
            selectedNiche: '',
            customKeywords: '',
            useBrain: true, // Enable AI brain by default
            brainApiKey: '', // Will use default from brain.js if empty
            channelListRaw: '',
            youtubeApiKey: '',
            channelResultsPerRun: 5,
            humanMode: true,
            humanIntensity: 1
        });

        // Initialize brain
        brain.initialize();

    } else if (details.reason === 'update') {
        console.log('[Niche Filter] Extension updated');
        brain.initialize();
    }
});

// Initialize brain on startup
brain.initialize();

// ============================================
// Message Handling - Central Router
// ============================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('[Background] Received message:', message.action);

    // Route to appropriate handler
    handleMessage(message, sender)
        .then(response => sendResponse(response))
        .catch(error => sendResponse({ success: false, error: error.message }));

    return true; // Keep channel open for async response
});

/**
 * Main message handler - routes all actions
 */
async function handleMessage(message, sender) {
    switch (message.action) {
        // ============================================
        // Brain Actions - AI-powered decisions
        // ============================================

        case 'brainAnalyzeVideo':
            return await handleBrainAnalyzeVideo(message);

        case 'brainAnalyzeBatch':
            return await handleBrainAnalyzeBatch(message);

        case 'brainGenerateComment':
            return await handleBrainGenerateComment(message);

        case 'brainGenerateSearchQueries':
            return await handleBrainGenerateSearchQueries(message);

        case 'brainGenerateKeywords':
            return await handleBrainGenerateKeywords(message);

        case 'brainGenerateSearchTitle':
            return await handleBrainGenerateSearchTitle(message);

        case 'brainThink':
            return await handleBrainThink(message);

        case 'brainTest':
            return await brain.test();

        case 'setBrainApiKey':
            await brain.setApiKey(message.apiKey);
            return { success: true };

        // ============================================
        // Settings Actions
        // ============================================

        case 'getSettings':
            return await chrome.storage.local.get([
                'selectedCategory',
                'keywordInput',
                'selectedNiche',
                'customKeywords',
                'useBrain',
                'brainApiKey',
                'channelListRaw',
                'youtubeApiKey',
                'channelResultsPerRun',
                'humanMode',
                'humanIntensity'
            ]);

        case 'saveSettings':
            await chrome.storage.local.set(message.settings);
            return { success: true };

        case 'getStats':
            return await handleGetStats();

        case 'resetStats':
            return await handleResetStats();

        case 'scanProgress':
            if (message.__fromBackgroundRelay) {
                return { success: true };
            }
            await handleScanProgress(message);
            return { success: true };

        case 'startChannelRatioScan':
            return await handleStartChannelRatioScan(message);

        // ============================================
        // Legacy/Direct Actions
        // ============================================

        default:
            return { success: true, message: 'Unknown action' };
    }
}

// ============================================
// Brain Handler Functions
// ============================================

const BRAIN_MATCH_CACHE_LIMIT = 400;
const brainMatchCache = new Map();

/**
 * Analyze a single video using the brain
 */
async function handleBrainAnalyzeVideo(message) {
    const { title, channel, niche, category, keywords, hashtags, isLive, categoryHints } = message;
    const resolvedCategory = category || niche || '';
    const safeHashtags = Array.isArray(hashtags) ? hashtags : [];
    const liveFlag = isLive === true;
    const safeHints = normalizeBrainList(categoryHints, 4);
    const safeKeywords = normalizeBrainList(keywords, 6);
    const cacheKey = buildBrainMatchCacheKey(title, resolvedCategory, safeHints);
    const cached = readBrainMatchCache(cacheKey);

    if (cached) {
        return {
            success: true,
            result: buildCachedAnalyzeResult(cached)
        };
    }

    const result = await brain.think('analyzeVideo', {
        title,
        channel,
        hashtags: safeHashtags,
        isLive: liveFlag,
        category: resolvedCategory,
        keywords: safeKeywords,
        categoryHints: safeHints
    });

    const normalized = buildCacheEntryFromBrainResult(result);
    if (cacheKey && normalized && result?.decision !== 'fallback' && result?.decision !== 'error') {
        writeBrainMatchCache(cacheKey, normalized);
    }

    return {
        success: true,
        result
    };
}

/**
 * Analyze multiple videos in batch using the brain
 */
async function handleBrainAnalyzeBatch(message) {
    const { videos, niche, category, keywords, categoryHints, learnedKeywords } = message;
    const resolvedCategory = category || niche || '';
    const safeLearned = normalizeBrainList(learnedKeywords, 25);
    const safeHints = normalizeBrainList(categoryHints, 4);
    // Keyword mode relies on these for matching, so keep more than the AI prompt needs.
    const safeKeywords = normalizeBrainList(keywords, 30);
    const safeVideos = Array.isArray(videos)
        ? videos.map((video) => ({
            title: String(video?.title || '')
                .replace(/\s+/g, ' ')
                .trim()
                .slice(0, 140)
        }))
        : [];

    const pendingEntries = [];
    const allMatches = [];

    for (let index = 0; index < safeVideos.length; index += 1) {
        const video = safeVideos[index];
        const cacheKey = buildBrainMatchCacheKey(video?.title, resolvedCategory, safeHints);
        const cached = readBrainMatchCache(cacheKey);

        if (cached) {
            allMatches.push({
                ...cached,
                index
            });
            continue;
        }

        pendingEntries.push({
            index,
            cacheKey,
            video
        });
    }

    const chunkSize = Math.min(16, Math.max(1, pendingEntries.length || 1));

    for (let offset = 0; offset < pendingEntries.length; offset += chunkSize) {
        const chunkEntries = pendingEntries.slice(offset, offset + chunkSize);
        const chunk = chunkEntries.map(entry => entry.video);

        try {
            const chunkResult = await brain.think('analyzeVideoBatch', {
                videos: chunk,
                category: resolvedCategory,
                keywords: safeKeywords,
                categoryHints: safeHints
            });

            const normalizedMatches = normalizeBatchMatches(chunkResult?.data?.matches, chunk, safeKeywords, safeLearned);

            for (let localIndex = 0; localIndex < normalizedMatches.length; localIndex += 1) {
                const entry = chunkEntries[localIndex];
                const normalized = normalizedMatches[localIndex];
                if (!entry || !normalized) continue;

                if (entry.cacheKey && normalized.brainFallback !== true) {
                    writeBrainMatchCache(entry.cacheKey, normalized);
                }

                allMatches.push({
                    ...normalized,
                    index: entry.index
                });
            }
        } catch (error) {
            for (let localIndex = 0; localIndex < chunkEntries.length; localIndex += 1) {
                const entry = chunkEntries[localIndex];
                const fallbackResult = buildFallbackBrainMatch(entry?.video, localIndex, safeKeywords, safeLearned);
                if (!entry || !fallbackResult) continue;

                allMatches.push({
                    ...fallbackResult,
                    index: entry.index
                });
            }
        }
    }

    allMatches.sort((a, b) => a.index - b.index);

    return {
        success: true,
        result: {
            decision: 'analyze',
            confidence: 60,
            reasoning: 'Analyzed batch titles',
            data: { matches: allMatches }
        }
    };
}

/**
 * Generate a comment using the brain
 */
async function handleBrainGenerateComment(message) {
    const { title, description, category, niche, keywords, style } = message;
    const resolvedCategory = category || niche || '';

    const result = await brain.think('generateComment', {
        title,
        description,
        category: resolvedCategory,
        keywords,
        style
    });

    return {
        success: true,
        result
    };
}

/**
 * Ask the brain for words that typically appear in this niche's video titles
 */
async function handleBrainGenerateKeywords(message) {
    const { category, keywords } = message;

    const result = await brain.think('generateKeywords', {
        category: category || '',
        keywords: keywords || []
    });

    return {
        success: true,
        result
    };
}

/**
 * Generate YouTube search queries using the brain
 */
async function handleBrainGenerateSearchQueries(message) {
    const { category, keywords, purpose } = message;

    const result = await brain.think('generateSearchQueries', {
        category: category || '',
        keywords: keywords || [],
        purpose: purpose || ''
    });

    return {
        success: true,
        result
    };
}

/**
 * Generate one YouTube search title based on watched home-feed videos
 */
async function handleBrainGenerateSearchTitle(message) {
    const { category, keywords, watchedTitles } = message;
    const safeTitles = Array.isArray(watchedTitles) ? watchedTitles.filter(Boolean).slice(-6) : [];

    const result = await brain.think('generateSearchTitle', {
        category: category || '',
        keywords: keywords || [],
        watchedTitles: safeTitles
    });

    return {
        success: true,
        result
    };
}

/**
 * Generic brain thinking request
 */
async function handleBrainThink(message) {
    const { action, context } = message;

    const result = await brain.think(action, context);

    return {
        success: true,
        result
    };
}

/**
 * Keyword-based scoring fallback
 */
function calculateKeywordScore(title, keywords) {
    if (!keywords || !Array.isArray(keywords)) return 0;

    const titleLower = (title || '').toLowerCase();
    let score = 0;

    for (const keyword of keywords) {
        const keywordLower = keyword.toLowerCase();

        const isGeneric = isGenericKeyword(keywordLower);
        const exactPoints = isGeneric ? 15 : 40;
        const partialPoints = isGeneric ? 8 : 20;

        // Exact word/phrase match (higher score)
        const wordPattern = new RegExp(`\\b${escapeRegex(keywordLower)}\\b`, 'i');
        if (wordPattern.test(titleLower)) {
            score += exactPoints;
            continue;
        }

        // Partial match (lower score)
        if (titleLower.includes(keywordLower)) {
            score += partialPoints;
        }
    }

    return Math.min(score, 100);
}

function isGenericKeyword(keywordLower) {
    return (
        keywordLower === 'tech' ||
        keywordLower === 'tutorial' ||
        keywordLower === 'how to' ||
        keywordLower === 'learn' ||
        keywordLower === 'course' ||
        keywordLower === 'review' ||
        keywordLower === 'trending'
    );
}

function buildMatchText(video) {
    return video?.title || '';
}

function normalizeBrainList(values, limit, maxLength = 40) {
    if (!Array.isArray(values)) return [];

    const seen = new Set();
    const result = [];

    for (const value of values) {
        const clean = String(value || '')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, maxLength);

        if (!clean) continue;

        const key = clean.toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        result.push(clean);

        if (result.length >= limit) break;
    }

    return result;
}

function clampBrainScore(value, fallback = 0) {
    const score = Number(value);
    if (!Number.isFinite(score)) return fallback;
    return Math.max(0, Math.min(100, Math.round(score)));
}

function resolveBrainRelevant(value, score = 0) {
    if (value === true || value === 'true' || value === 1 || value === '1') return true;
    if (value === false || value === 'false' || value === 0 || value === '0') return false;
    return score >= 60;
}

function buildBrainMatchCacheKey(title, category, hints = []) {
    const cleanTitle = String(title || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const cleanCategory = String(category || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const cleanHints = normalizeBrainList(hints, 4).map(item => item.toLowerCase()).sort().join('|');

    if (!cleanTitle || !cleanCategory) return '';
    return `${cleanCategory}::${cleanHints}::${cleanTitle}`;
}

function readBrainMatchCache(key) {
    if (!key || !brainMatchCache.has(key)) return null;

    const value = brainMatchCache.get(key);
    brainMatchCache.delete(key);
    brainMatchCache.set(key, value);

    return { ...value };
}

function writeBrainMatchCache(key, value) {
    if (!key || !value) return;

    if (brainMatchCache.has(key)) {
        brainMatchCache.delete(key);
    }

    brainMatchCache.set(key, { ...value });

    while (brainMatchCache.size > BRAIN_MATCH_CACHE_LIMIT) {
        const oldestKey = brainMatchCache.keys().next().value;
        brainMatchCache.delete(oldestKey);
    }
}

function buildFallbackBrainMatch(video, index, keywords, learnedKeywords = []) {
    const text = buildMatchText(video);
    // Learned niche words count half, so a title needs one of the user's keywords
    // or two learned words to be picked.
    const score = Math.min(
        100,
        calculateKeywordScore(text, keywords) + Math.floor(calculateKeywordScore(text, learnedKeywords) / 2)
    );
    return {
        index,
        score,
        relevant: score >= 40,
        brainFallback: true
    };
}

function buildCacheEntryFromBrainResult(result) {
    const score = clampBrainScore(result?.data?.score ?? result?.confidence, 0);
    const relevant = resolveBrainRelevant(result?.data?.relevant, score);

    if (typeof relevant !== 'boolean') return null;

    return {
        score,
        relevant,
        brainFallback: result?.brainFallback === true
    };
}

function buildCachedAnalyzeResult(cached) {
    return {
        decision: cached.relevant ? 'approve' : 'reject',
        confidence: clampBrainScore(cached.score, 0),
        reasoning: 'Cached decision',
        data: {
            score: clampBrainScore(cached.score, 0),
            relevant: cached.relevant === true
        }
    };
}

function normalizeBatchMatches(matches, videos, keywords, learnedKeywords = []) {
    const normalized = new Map();

    if (Array.isArray(matches)) {
        for (const match of matches) {
            const rawIndex = typeof match?.index === 'string'
                ? Number.parseInt(match.index, 10)
                : match?.index;

            if (!Number.isFinite(rawIndex) || rawIndex < 0 || rawIndex >= videos.length) {
                continue;
            }

            const score = clampBrainScore(match?.score ?? match?.confidence, 0);
            normalized.set(rawIndex, {
                score,
                relevant: resolveBrainRelevant(match?.relevant, score),
                brainFallback: match?.brainFallback === true
            });
        }
    }

    return videos.map((video, index) => {
        if (normalized.has(index)) {
            return normalized.get(index);
        }

        return buildFallbackBrainMatch(video, index, keywords, learnedKeywords);
    });
}

/**
 * Escape special regex characters
 */
function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ============================================
// Progress Relay + Channel Ratio Scan
// ============================================

const CHANNEL_SCAN_DEFAULT_DAYS = 30;
const CHANNEL_SCAN_DEFAULT_RESULTS = 5;
const CHANNEL_SCAN_MAX_RECENT_VIDEOS = 200;
const CHANNEL_SCAN_STEP_DELAY_MS = 350;

async function handleScanProgress(message) {
    const relayPayload = {
        ...message,
        __fromBackgroundRelay: true
    };
    sendRuntimeMessageSafely(relayPayload);
}

function sendRuntimeMessageSafely(payload) {
    try {
        chrome.runtime.sendMessage(payload, () => {
            void chrome.runtime.lastError;
        });
    } catch (_) {
        // No active listeners (e.g. popup closed)
    }
}

function notifyChannelScanProgress(payload) {
    sendRuntimeMessageSafely({
        action: 'channelScanProgress',
        __fromBackgroundRelay: true,
        ...payload
    });
}

function notifyChannelScanComplete(payload) {
    sendRuntimeMessageSafely({
        action: 'channelScanComplete',
        __fromBackgroundRelay: true,
        ...payload
    });
}

function sleep(ms) {
    if (!Number.isFinite(ms) || ms <= 0) return Promise.resolve();
    return new Promise((resolve) => setTimeout(resolve, ms));
}

function clampInt(value, min, max, fallback) {
    const parsed = Number.parseInt(String(value ?? ''), 10);
    if (!Number.isFinite(parsed)) return fallback;
    if (parsed < min) return min;
    if (parsed > max) return max;
    return parsed;
}

function parseUniqueChannels(rawLines) {
    const lines = String(rawLines || '')
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean);
    const seen = new Set();
    const unique = [];

    for (const line of lines) {
        const key = line.toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        unique.push(line);
    }

    return unique;
}

function classifyChannelError(error) {
    const message = String(error?.message || '').toLowerCase();
    if (message.includes('resolve channel') || message.includes('unable to resolve')) {
        return 'invalid_channel';
    }
    return 'api_error';
}

function buildEmptyChannelResult(channelInput) {
    return {
        inputChannel: channelInput,
        resolvedChannelId: '',
        resolvedChannelTitle: '',
        goldenRatio: null,
        topPopular: [],
        recentCandidateCount: 0,
        recentCandidates: [],
        closestMatches: [],
        status: 'api_error',
        error: ''
    };
}

function buildChannelProgress(index, total, channel, stage, extra = {}) {
    return {
        index,
        total,
        channel,
        stage,
        ...extra
    };
}

async function handleStartChannelRatioScan(message) {
    if (!youtubeApi || !ratioMatcher) {
        return { success: false, error: 'Channel ratio modules failed to load' };
    }

    const rawChannels = message.channelsRaw ?? message.channelListRaw ?? '';
    const apiKey = String(message.apiKey ?? message.youtubeApiKey ?? '').trim();
    const channels = parseUniqueChannels(rawChannels);
    const resultsPerChannel = clampInt(
        message.resultsPerChannel,
        1,
        10,
        CHANNEL_SCAN_DEFAULT_RESULTS
    );
    const days = clampInt(message.days, 1, 365, CHANNEL_SCAN_DEFAULT_DAYS);

    if (!apiKey) {
        return { success: false, error: 'YouTube API key is required' };
    }

    if (channels.length === 0) {
        return { success: false, error: 'Add at least one channel (one per line)' };
    }

    await chrome.storage.local.set({
        channelListRaw: rawChannels,
        youtubeApiKey: apiKey,
        channelResultsPerRun: resultsPerChannel
    });

    const processedAt = new Date().toISOString();
    const publishedAfter = new Date(Date.now() - (days * 24 * 60 * 60 * 1000));
    const results = [];
    const total = channels.length;

    notifyChannelScanProgress({
        stage: 'start',
        total,
        days,
        resultsPerChannel
    });

    for (let i = 0; i < channels.length; i += 1) {
        const inputChannel = channels[i];
        const index = i + 1;
        const channelResult = buildEmptyChannelResult(inputChannel);

        notifyChannelScanProgress(buildChannelProgress(index, total, inputChannel, 'resolving'));

        try {
            const resolved = await youtubeApi.resolveChannelId(inputChannel, apiKey);
            channelResult.resolvedChannelId = resolved.channelId || '';
            channelResult.resolvedChannelTitle = resolved.title || '';

            notifyChannelScanProgress(
                buildChannelProgress(index, total, inputChannel, 'popular', {
                    resolvedChannelId: channelResult.resolvedChannelId
                })
            );

            const popularVideos = await youtubeApi.getTopPopularVideos(
                channelResult.resolvedChannelId,
                3,
                apiKey
            );

            if (!Array.isArray(popularVideos) || popularVideos.length === 0) {
                channelResult.status = 'no_popular_data';
                channelResult.error = 'No popular videos found for this channel';
                results.push(channelResult);
                notifyChannelScanProgress(buildChannelProgress(index, total, inputChannel, 'done', {
                    status: channelResult.status
                }));
                await sleep(CHANNEL_SCAN_STEP_DELAY_MS);
                continue;
            }

            const goldenResult = ratioMatcher.computeGoldenRatioFromPopular(popularVideos);
            channelResult.goldenRatio = goldenResult.goldenRatio;
            channelResult.topPopular = goldenResult.topPopular;

            notifyChannelScanProgress(buildChannelProgress(index, total, inputChannel, 'recent'));

            const recentVideos = await youtubeApi.getRecentVideos(channelResult.resolvedChannelId, {
                apiKey,
                publishedAfter,
                maxVideos: CHANNEL_SCAN_MAX_RECENT_VIDEOS
            });
            channelResult.recentCandidateCount = Array.isArray(recentVideos) ? recentVideos.length : 0;
            channelResult.recentCandidates = Array.isArray(recentVideos)
                ? recentVideos.slice(0, 30)
                : [];

            if (!Array.isArray(recentVideos) || recentVideos.length === 0) {
                channelResult.status = 'no_recent_videos';
                channelResult.error = `No videos published in the last ${days} days`;
                results.push(channelResult);
                notifyChannelScanProgress(buildChannelProgress(index, total, inputChannel, 'done', {
                    status: channelResult.status
                }));
                await sleep(CHANNEL_SCAN_STEP_DELAY_MS);
                continue;
            }

            notifyChannelScanProgress(buildChannelProgress(index, total, inputChannel, 'ranking'));

            channelResult.closestMatches = ratioMatcher.findClosestVideos(
                recentVideos,
                channelResult.goldenRatio,
                resultsPerChannel
            );
            channelResult.status = 'ok';

            results.push(channelResult);
            notifyChannelScanProgress(buildChannelProgress(index, total, inputChannel, 'done', {
                status: channelResult.status,
                matched: channelResult.closestMatches.length
            }));
        } catch (error) {
            channelResult.status = classifyChannelError(error);
            channelResult.error = String(error?.message || 'Unknown channel scan error');
            results.push(channelResult);
            notifyChannelScanProgress(buildChannelProgress(index, total, inputChannel, 'done', {
                status: channelResult.status,
                error: channelResult.error
            }));
        }

        await sleep(CHANNEL_SCAN_STEP_DELAY_MS);
    }

    const summary = {
        total,
        successful: results.filter((item) => item.status === 'ok').length,
        failed: results.filter((item) => item.status !== 'ok').length
    };

    notifyChannelScanComplete({
        processedAt,
        days,
        resultsPerChannel,
        summary,
        results
    });

    return {
        success: true,
        processedAt,
        days,
        resultsPerChannel,
        summary,
        results
    };
}

// ============================================
// Stats Handler Functions
// ============================================

const STATS_KEYS = {
    totalVideosWatched: 'stats_totalVideosWatched',
    totalLikes: 'stats_totalLikes',
    totalComments: 'stats_totalComments',
    totalShares: 'stats_totalShares',
    totalSubscribes: 'stats_totalSubscribes',
    totalWatchTimeSeconds: 'stats_totalWatchTimeSeconds',
    totalSessions: 'stats_totalSessions',
    lastSessionDate: 'stats_lastSessionDate'
};

async function handleGetStats() {
    try {
        const result = await chrome.storage.local.get(Object.values(STATS_KEYS));
        return {
            success: true,
            stats: {
                totalVideosWatched: result[STATS_KEYS.totalVideosWatched] || 0,
                totalLikes: result[STATS_KEYS.totalLikes] || 0,
                totalComments: result[STATS_KEYS.totalComments] || 0,
                totalShares: result[STATS_KEYS.totalShares] || 0,
                totalSubscribes: result[STATS_KEYS.totalSubscribes] || 0,
                totalWatchTimeSeconds: result[STATS_KEYS.totalWatchTimeSeconds] || 0,
                totalSessions: result[STATS_KEYS.totalSessions] || 0,
                lastSessionDate: result[STATS_KEYS.lastSessionDate] || null
            }
        };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function handleResetStats() {
    try {
        await chrome.storage.local.remove(Object.values(STATS_KEYS));
        return { success: true };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

// ============================================
// Tab Update Listener
// ============================================
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url?.includes('youtube.com')) {
        console.log('[Niche Filter] YouTube tab loaded:', tabId);
    }
});

console.log('[Background] Service worker loaded with Brain engine');
