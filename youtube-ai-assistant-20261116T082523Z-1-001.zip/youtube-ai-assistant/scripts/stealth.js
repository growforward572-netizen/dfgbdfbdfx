/**
 * YouTube Niche Filter - Stealth Layer (MAIN world, document_start)
 *
 * Runs in the page's own JavaScript context before YouTube boots, so the
 * fingerprints YouTube reads are already patched by the time its bot checks run.
 *
 * Everything here is defensive: if a patch fails, the page keeps working.
 */
(() => {
    'use strict';

    if (window.__nicheStealthApplied) return;
    window.__nicheStealthApplied = true;

    const defineGetter = (target, prop, value) => {
        try {
            Object.defineProperty(target, prop, {
                get: () => value,
                configurable: true,
                enumerable: true
            });
        } catch {
            // ignore
        }
    };

    const defineIfMissing = (target, prop, value) => {
        try {
            if (target[prop] === undefined) defineGetter(target, prop, value);
        } catch {
            // ignore
        }
    };

    // ---------------------------------------------------------------
    // The single biggest automation tell.
    // ---------------------------------------------------------------
    defineGetter(Navigator.prototype, 'webdriver', false);

    // ---------------------------------------------------------------
    // Navigator surface: headless/automation profiles report odd values.
    // ---------------------------------------------------------------
    try {
        if (!navigator.languages || navigator.languages.length === 0) {
            defineGetter(navigator, 'languages', ['en-US', 'en']);
        }
    } catch {
        // ignore
    }

    defineIfMissing(Navigator.prototype, 'platform', 'Win32');
    defineIfMissing(Navigator.prototype, 'vendor', 'Google Inc.');
    defineIfMissing(Navigator.prototype, 'pdfViewerEnabled', true);
    defineIfMissing(Navigator.prototype, 'doNotTrack', null);
    defineIfMissing(Navigator.prototype, 'maxTouchPoints', 0);

    try {
        if (!Number.isFinite(navigator.hardwareConcurrency) || navigator.hardwareConcurrency < 4) {
            defineGetter(navigator, 'hardwareConcurrency', 8);
        }
    } catch {
        // ignore
    }

    try {
        if (!Number.isFinite(navigator.deviceMemory) || navigator.deviceMemory < 4) {
            defineGetter(navigator, 'deviceMemory', 8);
        }
    } catch {
        // ignore
    }

    try {
        if (!navigator.connection) {
            defineGetter(navigator, 'connection', {
                effectiveType: '4g',
                rtt: 50,
                downlink: 10,
                downlinkMax: Infinity,
                saveData: false,
                type: 'wifi',
                onchange: null,
                addEventListener() {},
                removeEventListener() {}
            });
        }
    } catch {
        // ignore
    }

    // A real user has usually never answered the notification prompt.
    try {
        if (window.Notification && Notification.permission === 'denied') {
            defineGetter(Notification, 'permission', 'default');
        }
    } catch {
        // ignore
    }

    // ---------------------------------------------------------------
    // Permissions API: automation profiles report "denied" for
    // notifications, which is a well-known headless signature.
    // ---------------------------------------------------------------
    try {
        const originalQuery = Permissions.prototype.query;
        Permissions.prototype.query = function query(descriptor) {
            return originalQuery.call(this, descriptor).then((status) => {
                if (descriptor && descriptor.name === 'notifications' && status.state === 'denied') {
                    return new Proxy(status, {
                        get(target, prop) {
                            if (prop === 'state') return 'prompt';
                            const value = target[prop];
                            return typeof value === 'function' ? value.bind(target) : value;
                        }
                    });
                }
                return status;
            });
        };
    } catch {
        // ignore
    }

    // ---------------------------------------------------------------
    // WebGL: only override software renderers (SwiftShader/llvmpipe).
    // ---------------------------------------------------------------
    try {
        const spoof = (original) => function getParameter(parameter) {
            const result = original.call(this, parameter);
            if (parameter === 37445) return 'Google Inc. (NVIDIA)';
            if (parameter === 37446) {
                if (typeof result === 'string' && !/swiftshader|software|llvmpipe|mesa/i.test(result)) {
                    return result;
                }
                return 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER Direct3D11 vs_5_0 ps_5_0, D3D11)';
            }
            return result;
        };

        if (window.WebGLRenderingContext) {
            WebGLRenderingContext.prototype.getParameter = spoof(WebGLRenderingContext.prototype.getParameter);
        }
        if (window.WebGL2RenderingContext) {
            WebGL2RenderingContext.prototype.getParameter = spoof(WebGL2RenderingContext.prototype.getParameter);
        }
    } catch {
        // ignore
    }

    // ---------------------------------------------------------------
    // Window geometry: headless reports 0x0 outer size.
    // ---------------------------------------------------------------
    try {
        if (!window.outerWidth) defineGetter(window, 'outerWidth', window.innerWidth + 16);
        if (!window.outerHeight) defineGetter(window, 'outerHeight', window.innerHeight + 88);
        if (!window.screenX && !window.screenY) {
            defineGetter(window, 'screenX', 96);
            defineGetter(window, 'screenY', 64);
        }
    } catch {
        // ignore
    }

    // ---------------------------------------------------------------
    // chrome.* surface that every normal Chrome page has.
    // ---------------------------------------------------------------
    try {
        if (!window.chrome) defineGetter(window, 'chrome', {});

        if (window.chrome) {
            if (!window.chrome.runtime) {
                window.chrome.runtime = {
                    id: 'nichefilterstealthpagemarker',
                    connect() {
                        return { onMessage: { addListener() {} }, postMessage() {}, disconnect() {} };
                    },
                    sendMessage() {},
                    getManifest() {
                        return {};
                    }
                };
            }
            if (!window.chrome.app) {
                window.chrome.app = {
                    isInstalled: false,
                    InstallState: { DISABLED: 'disabled', INSTALLED: 'installed', NOT_INSTALLED: 'not_installed' },
                    RunningState: { CANNOT_RUN: 'cannot_run', READY_TO_RUN: 'ready_to_run', RUNNING: 'running' },
                    getDetails() {
                        return null;
                    },
                    getIsInstalled() {
                        return false;
                    },
                    runningState() {
                        return 'cannot_run';
                    }
                };
            }
            if (!window.chrome.csi) {
                window.chrome.csi = () => ({ onloadT: performance.timing?.domContentLoadedEventEnd || 0, startE: performance.timing?.navigationStart || 0, pageT: performance.now(), tran: 15 });
            }
            if (!window.chrome.loadTimes) {
                window.chrome.loadTimes = () => ({
                    commitLoadTime: (performance.timing?.responseStart || 0) / 1000,
                    connectionInfo: 'h2',
                    finishDocumentLoadTime: (performance.timing?.domContentLoadedEventEnd || 0) / 1000,
                    finishLoadTime: (performance.timing?.loadEventEnd || 0) / 1000,
                    firstPaintTime: (performance.timing?.responseStart || 0) / 1000,
                    firstPaintAfterLoadTime: 0,
                    navigationType: 'Other',
                    npnNegotiatedProtocol: 'h2',
                    requestTime: (performance.timing?.navigationStart || 0) / 1000,
                    startLoadTime: (performance.timing?.navigationStart || 0) / 1000,
                    wasAlternateProtocolAvailable: false,
                    wasFetchedViaSpdy: true,
                    wasNpnNegotiated: true
                });
            }
        }
    } catch {
        // ignore
    }

    // ---------------------------------------------------------------
    // Driver leftovers.
    // ---------------------------------------------------------------
    for (const key of [
        '__nightmare',
        '_phantom',
        'callPhantom',
        '__selenium_unwrapped',
        '__selenium_evaluate',
        '__webdriver_evaluate',
        '__webdriver_script_function',
        '__webdriver_script_func',
        '__webdriver_script_fn',
        '__fxdriver_evaluate',
        '__driver_unwrapped',
        '__webdriver_unwrapped',
        '__lastWatirAlert',
        '__lastWatirConfirm',
        '__lastWatirPrompt'
    ]) {
        try {
            if (key in window) delete window[key];
        } catch {
            // ignore
        }
    }

    // ---------------------------------------------------------------
    // document.hasFocus(): automation windows are often unfocused while
    // still visible. YouTube pauses/behaves differently when unfocused.
    // ---------------------------------------------------------------
    try {
        const originalHasFocus = Document.prototype.hasFocus;
        Document.prototype.hasFocus = function hasFocus() {
            if (document.visibilityState === 'visible') return true;
            return originalHasFocus.call(this);
        };
    } catch {
        // ignore
    }
})();
