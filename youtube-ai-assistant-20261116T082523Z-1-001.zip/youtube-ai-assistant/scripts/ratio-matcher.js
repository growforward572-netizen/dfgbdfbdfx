/**
 * Golden ratio calculator for youtube-ai-assistant.
 * Computes comment-to-view ratio from top popular videos,
 * then ranks recent videos by proximity to that ratio.
 * Exposes self.ratioMatcher.
 */
(function initRatioMatcher(globalScope) {

    function toPositiveNum(value, fallback = 0) {
        const num = Number(value);
        if (!Number.isFinite(num) || num < 0) return fallback;
        return num;
    }

    function commentViewRatio(video) {
        const views = toPositiveNum(video.viewCount, 0);
        const comments = toPositiveNum(video.commentCount, 0);
        if (views === 0) return 0;
        return comments / views;
    }

    /**
     * Compute the "golden ratio" from a set of popular videos.
     * Returns the average comment-to-view ratio and the input videos
     * annotated with their individual ratios.
     *
     * @param {Array} popularVideos - Videos with viewCount and commentCount
     * @returns {{ goldenRatio: number, topPopular: Array }}
     */
    function computeGoldenRatioFromPopular(popularVideos) {
        const videos = Array.isArray(popularVideos) ? popularVideos : [];
        if (videos.length === 0) {
            return { goldenRatio: 0, topPopular: [] };
        }

        let sum = 0;
        const topPopular = videos.map((video) => {
            const ratio = commentViewRatio(video);
            sum += ratio;
            return {
                videoId: video.videoId || '',
                title: video.title || '',
                url: video.url || '',
                viewCount: toPositiveNum(video.viewCount, 0),
                commentCount: toPositiveNum(video.commentCount, 0),
                ratio
            };
        });

        const goldenRatio = sum / videos.length;
        return { goldenRatio, topPopular };
    }

    /**
     * Rank recent videos by how close their comment-to-view ratio is
     * to the golden ratio, and return the top N closest matches.
     *
     * @param {Array} recentVideos - Videos with viewCount and commentCount
     * @param {number} goldenRatio - Target ratio from computeGoldenRatioFromPopular
     * @param {number} count - Number of closest matches to return
     * @returns {Array} Closest matches sorted by ratio distance (ascending)
     */
    function findClosestVideos(recentVideos, goldenRatio, count) {
        const videos = Array.isArray(recentVideos) ? recentVideos : [];
        const target = Number.isFinite(goldenRatio) ? goldenRatio : 0;
        const limit = Math.max(1, Math.min(50, Number(count) || 5));

        const scored = videos.map((video) => {
            const ratio = commentViewRatio(video);
            const distance = Math.abs(ratio - target);
            return {
                videoId: video.videoId || '',
                title: video.title || '',
                url: video.url || '',
                publishedAt: video.publishedAt || '',
                viewCount: toPositiveNum(video.viewCount, 0),
                commentCount: toPositiveNum(video.commentCount, 0),
                ratio,
                distance
            };
        });

        scored.sort((a, b) => a.distance - b.distance);
        return scored.slice(0, limit);
    }

    globalScope.ratioMatcher = {
        computeGoldenRatioFromPopular,
        findClosestVideos
    };
})(self);
