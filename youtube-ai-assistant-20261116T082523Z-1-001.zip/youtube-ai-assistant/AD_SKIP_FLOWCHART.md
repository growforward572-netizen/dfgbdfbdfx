# Ad Skip Logic - Visual Flowchart

## 🔄 Complete Flow Diagram

```
┌─────────────────────────────────────────────┐
│         AD DETECTED ON VIDEO                │
└─────────────────────────────────────────────┘
                    ↓
        ┌───────────────────────┐
        │   Log: "Ad detected"  │
        └───────────────────────┘
                    ↓
        ┌───────────────────────┐
        │   WAIT 5 SECONDS      │  ← Let skip button appear
        │   (initialWaitMs)     │
        └───────────────────────┘
                    ↓
        ┌───────────────────────┐
        │  Is ad still playing? │
        └───────────────────────┘
               YES ↓       NO ↓
                   │         └──→ ┌──────────────────────────┐
                   │              │ Ad finished during wait  │
                   │              │ (5-6 sec unskippable ad) │
                   │              │ Log: "Ad finished"       │
                   │              └──────────────────────────┘
                   │                          ↓
                   │                       [DONE]
                   │
    ╔══════════════════════════════════════╗
    ║    RETRY LOOP (3 attempts max)      ║
    ╚══════════════════════════════════════╝
                   │
                   ↓
    ┌──────────────────────────────────────┐
    │  ATTEMPT 1/3: Search for skip button │
    │  Check every 500ms for 3 seconds     │
    └──────────────────────────────────────┘
                   ↓
    ┌──────────────────────────────────────┐
    │         Skip button found?           │
    └──────────────────────────────────────┘
           YES ↓              NO ↓
               │                  │
               │                  ↓
               │         ┌─────────────────────────┐
               │         │ Log: "Button not found" │
               │         │ (attempt X/3)           │
               │         └─────────────────────────┘
               │                  ↓
               │         ┌─────────────────────────┐
               │         │   More attempts left?   │
               │         └─────────────────────────┘
               │            YES ↓         NO ↓
               │                │            │
               │         ┌──────────────┐   │
               │         │ Wait 2 sec   │   │
               │         └──────────────┘   │
               │                │            │
               │                └──→ RETRY  │
               │                             │
               ↓                             ↓
    ┌──────────────────────┐    ┌────────────────────────┐
    │   CLICK BUTTON       │    │  All retries failed!   │
    │   Log: "Clicking..."  │    │  WATCH FULL AD         │
    └──────────────────────┘    └────────────────────────┘
               ↓                             ↓
    ┌──────────────────────┐         ┌─────────────────┐
    │  Wait 1 second       │         │ Wait for ad to  │
    │  (verify delay)      │         │ finish playing  │
    └──────────────────────┘         └─────────────────┘
               ↓                             ↓
    ┌──────────────────────┐              [DONE]
    │  Check: Is ad gone?  │
    └──────────────────────┘
       YES ↓          NO ↓
           │              │
           ↓              ↓
    ┌─────────────┐  ┌──────────────────────────┐
    │  ✅ SUCCESS │  │ ⚠️ Click failed!         │
    │  "Skipped!" │  │ "Ad still playing"       │
    └─────────────┘  └──────────────────────────┘
           ↓                      ↓
        [DONE]          ┌──────────────────┐
                        │ More attempts?   │
                        └──────────────────┘
                           YES ↓      NO ↓
                               │         │
                        ┌──────────┐    │
                        │ Wait 2s  │    │
                        └──────────┘    │
                               │         │
                               └→ RETRY │
                                         ↓
                              ┌──────────────────┐
                              │  WATCH FULL AD   │
                              └──────────────────┘
                                         ↓
                                      [DONE]
```

---

## 🎯 Key Decision Points

### Decision 1: After Initial Wait
```
Wait 5 seconds
    ↓
Is ad still playing?
├─ NO  → Ad was unskippable (5-6 sec) → Done ✅
└─ YES → Continue to skip attempts
```

### Decision 2: Button Detection
```
Search for button (3 seconds)
    ↓
Button found?
├─ YES → Click button → Verify
└─ NO  → Retry or give up
```

### Decision 3: Verification
```
Click button → Wait 1 second
    ↓
Is ad gone?
├─ YES → Success! ✅
└─ NO  → Failed, retry ⚠️
```

### Decision 4: Retry Logic
```
Attempt failed
    ↓
More attempts left?
├─ YES → Wait 2 seconds → Retry
└─ NO  → Watch full ad
```

---

## 📋 Timeline Examples

### Example 1: Perfect Skip (Fast)
```
0:00 - Ad starts
0:00 - Extension detects ad
0:05 - Wait complete
0:05 - Search for button
0:05 - Button found immediately
0:05 - Click button
0:06 - Verify: Ad stopped ✅
0:06 - Total time: 6 seconds
```

### Example 2: Retry Needed (Slower)
```
0:00 - Ad starts
0:00 - Extension detects ad
0:05 - Wait complete
0:05 - Search for button (3 seconds)
0:08 - Button not found ❌
0:08 - Wait 2 seconds before retry
0:10 - Retry: Search again
0:11 - Button found! 
0:11 - Click button
0:12 - Verify: Ad stopped ✅
0:12 - Total time: 12 seconds
```

### Example 3: Watch Full Ad (Failed)
```
0:00 - Ad starts
0:00 - Extension detects ad
0:05 - Wait complete
0:05-0:08 - Attempt 1: Not found ❌
0:10-0:13 - Attempt 2: Click failed ❌
0:15-0:18 - Attempt 3: Click failed ❌
0:18 - Give up, watch ad
0:30 - Ad finishes naturally
0:30 - Total time: 30 seconds
```

---

## 🔍 Button Detection Strategies

### Strategy 1: Known Selectors (30+)
```javascript
Try each of 30+ selectors:
- .ytp-ad-skip-button-modern ✓
- .ytp-skip-ad-button ✓
- button[aria-label*="Skip"] ✓
- ... (27 more)
```

### Strategy 2: Text Search
```javascript
Search all buttons for text:
- "Skip Ad" ✓
- "Skip Ads" ✓
- "Skip" ✓
```

### Strategy 3: Container Search
```javascript
Look inside ad overlays:
- .ytp-ad-player-overlay
  └─ Find any button with "skip"
```

### Strategy 4: Class Pattern
```javascript
Find any element with "skip" in class:
- [class*="skip"]
  └─ Must be a button
  └─ Must have "skip" in text
```

---

## ⚡ Performance Metrics

| Metric | Value |
|--------|-------|
| **Initial Wait** | 5 seconds |
| **Button Search** | 0.5-3 seconds per attempt |
| **Verification** | 1 second |
| **Retry Delay** | 2 seconds |
| **Max Attempts** | 3 |
| **Worst Case** | ~20 seconds before giving up |
| **Best Case** | ~6 seconds (immediate skip) |
| **Average** | ~8 seconds (1-2 attempts) |

---

## 🎨 State Diagram

```
┌─────────┐
│  IDLE   │
└─────────┘
     ↓
     │ Ad detected
     ↓
┌─────────┐
│ WAITING │ (5 seconds)
└─────────┘
     ↓
┌─────────┐
│SEARCHING│ (up to 3 attempts)
└─────────┘
     ↓
┌─────────┐
│CLICKING │
└─────────┘
     ↓
┌─────────┐
│VERIFYING│ (1 second)
└─────────┘
     ↓
     ├─→ ✅ Success → IDLE
     └─→ ❌ Failed → RETRYING or WATCHING
```

---

## 🐛 Debug Checkpoints

At each checkpoint, check console logs:

**Checkpoint 1: Ad Detection**
```
Expected: "[Niche Filter] Ad detected"
If missing: Ad detection failed
```

**Checkpoint 2: Initial Wait**
```
Expected: "[Niche Filter] Skip attempt 1/3"
If missing: Code didn't reach retry loop
```

**Checkpoint 3: Button Search**
```
Expected: "[Niche Filter] Skip button found with selector: ..."
Or: "[Niche Filter] Skip button not found on attempt 1"
```

**Checkpoint 4: Click**
```
Expected: "[Niche Filter] Clicking skip button..."
If missing: Button visibility check failed
```

**Checkpoint 5: Verification**
```
Expected: "[Niche Filter] Ad successfully skipped and verified"
Or: "[Niche Filter] Skip button clicked but ad still playing"
```

---

**Use this flowchart to understand exactly what's happening!** 🎯
