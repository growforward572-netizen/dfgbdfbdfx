# Quick Start Guide: Custom Categories

## Step-by-Step Tutorial

### 1️⃣ Open Settings
```
Click extension icon → Click ⚙️ Settings button → Scroll down to "🏷️ Custom Categories"
```

### 2️⃣ Add Your First Category

**Example 1: With Keywords**
```
Category Name:    Woodworking
Keywords:         carpentry, wood, tools, furniture, DIY, crafts

→ Click "➕ Add Category"
```

**Example 2: Without Keywords (AI will understand)**
```
Category Name:    Coffee Brewing
Keywords:         (leave empty)

→ Click "➕ Add Category"
```

### 3️⃣ Use Your Custom Category
```
1. Close Settings panel
2. Select your category from dropdown (it has a 🏷️ icon)
3. Navigate to YouTube.com
4. Click "Scan Feed"
```

### 4️⃣ Watch It Work!
```
✓ AI analyzes videos based on your category
✓ Opens matching video automatically
✓ Watches for 7-14 minutes
✓ Engages (likes, comments, subscribes)
✓ Returns home and picks next video
✓ Continues for 45-55 minutes
```

## Visual Layout

```
┌─────────────────────────────────────────┐
│  🏷️ Custom Categories                   │
├─────────────────────────────────────────┤
│                                          │
│  Category Name                           │
│  ┌────────────────────────────────────┐ │
│  │ e.g., Cooking, Travel, Cars...     │ │
│  └────────────────────────────────────┘ │
│  Enter a unique category name            │
│                                          │
│  Keywords (Optional)                     │
│  ┌────────────────────────────────────┐ │
│  │ e.g., recipe, chef, food, cooking  │ │
│  └────────────────────────────────────┘ │
│  Comma-separated keywords                │
│                                          │
│  [ ➕ Add Category ]                     │
│                                          │
│  ┌────────────────────────────────────┐ │
│  │ 🍳 Cooking                         │ │
│  │ recipe, chef, food...      [🗑️]   │ │
│  ├────────────────────────────────────┤ │
│  │ ✈️ Travel                          │ │
│  │ vacation, trip, tourism... [🗑️]   │ │
│  └────────────────────────────────────┘ │
│                                          │
└─────────────────────────────────────────┘
```

## Dropdown Display

```
┌─────────────────────────────────────┐
│ Select a category              ▼   │
├─────────────────────────────────────┤
│ 💻 Tech & Programming               │
│ 🎮 Gaming                           │
│ 💰 Finance & Crypto                 │
│ 💪 Fitness & Health                 │
│ 📈 Business & Entrepreneurship      │
│ 📚 Education                        │
│ 🎬 Entertainment                    │
│ 🎵 Music                            │
│ ──────────────                      │  ← Separator
│ 🏷️ Cooking                          │  ← Custom
│ 🏷️ Travel                           │  ← Custom
│ 🏷️ Woodworking                      │  ← Custom
└─────────────────────────────────────┘
```

## Common Use Cases

### 🎯 Niche Hobbies
```
Category: Model Trains
Keywords: train, railroad, locomotive, scenery, HO scale, N scale
```

### 🌍 Languages
```
Category: Japanese Learning
Keywords: japanese, nihongo, kanji, hiragana, language, learn
```

### 🎨 Creative Skills
```
Category: Digital Art
Keywords: drawing, illustration, procreate, photoshop, tutorial
```

### 🏠 Home Improvement
```
Category: Gardening
Keywords: plants, flowers, garden, grow, seeds, soil, organic
```

### 💼 Professional Topics
```
Category: Real Estate Investing
Keywords: property, investment, rental, flip, passive income
```

## Pro Tips

### 💡 Tip 1: Start Broad, Then Narrow
```
❌ Don't: "Specific plant growing techniques"
✅ Do:   "Gardening" + keywords: "plant, grow, garden, soil"
```

### 💡 Tip 2: Use Common YouTube Terms
```
Think about how YouTubers title their videos:
- "tutorial" instead of "instruction"
- "how to" instead of "guide"
- "tips" instead of "advice"
```

### 💡 Tip 3: Include Variations
```
Category: Fitness
Keywords: workout, exercise, gym, training, bodybuilding, weightlifting
        ↑ Different words for same concept
```

### 💡 Tip 4: Test Without Keywords First
```
1. Add category without keywords
2. Run a scan
3. If results are good → Done!
4. If results are poor → Add specific keywords
```

## Troubleshooting

### ❓ Not finding videos?
```
→ Add more specific keywords
→ Check if content exists on YouTube for your niche
→ Try broader category name
```

### ❓ Finding wrong videos?
```
→ Add negative keywords (not supported yet, use more specific positive ones)
→ Make category name more specific
→ Use technical/niche terms in keywords
```

### ❓ Category disappeared?
```
→ Refresh popup (close and reopen)
→ Check if you're logged into same Chrome profile
```

## Keyboard Shortcuts

- **Enter** in Category Name field → Add category
- **Enter** in Keywords field → Add category
- **Tab** → Move between fields

## Limits

- ✅ Unlimited custom categories
- ✅ Unlimited keywords per category
- ✅ Category names: 1-100 characters
- ✅ Keywords: Comma-separated, any length

---

**Need help?** Check `CUSTOM_CATEGORIES.md` for detailed documentation!
