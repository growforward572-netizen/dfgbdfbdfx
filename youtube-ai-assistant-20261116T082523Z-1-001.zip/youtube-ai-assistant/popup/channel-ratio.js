/**
 * Channel Viral Ratio – popup UI controller.
 * Manages the #channel-ratio-section in popup.html:
 *   - Loads/saves channel list and API key from chrome.storage
 *   - Sends startChannelRatioScan to background on button click
 *   - Listens for channelScanProgress / channelScanComplete messages
 *   - Renders progress and result cards
 */
(function initChannelRatio() {
    // ---- DOM refs ----
    const channelInput   = document.getElementById('channel-list-input');
    const apiKeyInput    = document.getElementById('youtube-api-key');
    const scanBtn        = document.getElementById('channel-scan-btn');
    const progressEl     = document.getElementById('channel-progress');
    const resultsEl      = document.getElementById('channel-results');

    if (!scanBtn) return; // section not in DOM

    const STORAGE_KEYS = {
        channelList: 'channelListRaw',
        apiKey: 'youtubeApiKey'
    };

    // ---- Helpers ----

    function show(el)  { el && el.classList.remove('hidden'); }
    function hide(el)  { el && el.classList.add('hidden'); }

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.appendChild(document.createTextNode(String(str)));
        return div.innerHTML;
    }

    function formatNumber(n) {
        const num = Number(n) || 0;
        if (num >= 1_000_000) return (num / 1_000_000).toFixed(1) + 'M';
        if (num >= 1_000) return (num / 1_000).toFixed(1) + 'K';
        return String(num);
    }

    function formatRatio(ratio) {
        if (!Number.isFinite(ratio)) return '—';
        return (ratio * 100).toFixed(4) + '%';
    }

    // ---- Persist inputs ----

    async function loadSavedInputs() {
        try {
            const data = await chrome.storage.local.get([
                STORAGE_KEYS.channelList,
                STORAGE_KEYS.apiKey
            ]);
            if (data[STORAGE_KEYS.channelList] && channelInput) {
                channelInput.value = data[STORAGE_KEYS.channelList];
            }
            if (data[STORAGE_KEYS.apiKey] && apiKeyInput) {
                apiKeyInput.value = data[STORAGE_KEYS.apiKey];
            }
        } catch (_) {
            // storage unavailable
        }
    }

    async function saveInputs() {
        try {
            await chrome.storage.local.set({
                [STORAGE_KEYS.channelList]: channelInput?.value || '',
                [STORAGE_KEYS.apiKey]: apiKeyInput?.value || ''
            });
        } catch (_) {
            // ignore
        }
    }

    // ---- Scan trigger ----

    let scanning = false;

    async function startScan() {
        if (scanning) return;

        const channelsRaw = (channelInput?.value || '').trim();
        const apiKey = (apiKeyInput?.value || '').trim();

        if (!apiKey) {
            showError('Please enter a YouTube API key.');
            return;
        }
        if (!channelsRaw) {
            showError('Please enter at least one channel.');
            return;
        }

        scanning = true;
        scanBtn.disabled = true;
        scanBtn.querySelector('.btn-text').textContent = 'Scanning…';
        hide(resultsEl);
        show(progressEl);
        progressEl.textContent = 'Starting scan…';

        await saveInputs();

        try {
            const response = await chrome.runtime.sendMessage({
                action: 'startChannelRatioScan',
                channelsRaw,
                youtubeApiKey: apiKey,
                resultsPerChannel: 5,
                days: 30
            });

            if (response && !response.success) {
                showError(response.error || 'Scan failed');
            }
        } catch (err) {
            showError(String(err.message || 'Failed to start scan'));
        } finally {
            scanning = false;
            scanBtn.disabled = false;
            scanBtn.querySelector('.btn-text').textContent = 'Analyze Channels';
        }
    }

    function showError(msg) {
        show(progressEl);
        progressEl.innerHTML = `<span class="error-text">${escapeHtml(msg)}</span>`;
    }

    // ---- Progress & completion listeners ----

    function handleProgress(message) {
        if (!progressEl) return;
        show(progressEl);

        const { stage, index, total, channel, status, error } = message;

        if (stage === 'start') {
            progressEl.textContent = `Scanning ${total} channel${total === 1 ? '' : 's'}…`;
            return;
        }

        const prefix = total ? `[${index}/${total}]` : '';

        switch (stage) {
            case 'resolving':
                progressEl.textContent = `${prefix} Resolving ${channel}…`;
                break;
            case 'popular':
                progressEl.textContent = `${prefix} Fetching popular videos…`;
                break;
            case 'recent':
                progressEl.textContent = `${prefix} Fetching recent videos…`;
                break;
            case 'ranking':
                progressEl.textContent = `${prefix} Ranking by golden ratio…`;
                break;
            case 'done':
                if (status === 'ok') {
                    progressEl.textContent = `${prefix} Done ✓`;
                } else {
                    progressEl.textContent = `${prefix} ${error || status || 'Error'}`;
                }
                break;
            default:
                progressEl.textContent = `${prefix} ${stage || '…'}`;
        }
    }

    function handleComplete(message) {
        hide(progressEl);
        show(resultsEl);
        renderResults(message);
    }

    // ---- Render results ----

    function renderResults(data) {
        if (!resultsEl) return;

        const { summary, results, days } = data;
        let html = '';

        // Summary bar
        if (summary) {
            html += `<div class="channel-summary">`;
            html += `Scanned <strong>${summary.total}</strong> channel${summary.total === 1 ? '' : 's'} `;
            html += `(${summary.successful} OK, ${summary.failed} failed) `;
            html += `— last ${days || 30} days`;
            html += `</div>`;
        }

        if (!Array.isArray(results) || results.length === 0) {
            html += `<p>No results.</p>`;
            resultsEl.innerHTML = html;
            return;
        }

        for (const ch of results) {
            html += renderChannelCard(ch);
        }

        resultsEl.innerHTML = html;
    }

    function renderChannelCard(ch) {
        const title = escapeHtml(ch.resolvedChannelTitle || ch.inputChannel);
        const statusClass = ch.status === 'ok' ? 'status-ok' : 'status-error';
        let html = `<div class="channel-card">`;
        html += `<div class="channel-card-header">`;
        html += `<strong>${title}</strong>`;
        html += `<span class="channel-status ${statusClass}">${escapeHtml(ch.status)}</span>`;
        html += `</div>`;

        if (ch.error) {
            html += `<p class="channel-error">${escapeHtml(ch.error)}</p>`;
        }

        if (Number.isFinite(ch.goldenRatio) && ch.goldenRatio > 0) {
            html += `<p class="golden-ratio">Golden Ratio: <strong>${formatRatio(ch.goldenRatio)}</strong></p>`;
        }

        // Top popular used to calculate golden ratio
        if (Array.isArray(ch.topPopular) && ch.topPopular.length > 0) {
            html += `<details class="popular-details"><summary>Top Popular (${ch.topPopular.length})</summary><ul>`;
            for (const v of ch.topPopular) {
                html += `<li>`;
                html += `<a href="${escapeHtml(v.url)}" target="_blank">${escapeHtml(v.title)}</a>`;
                html += ` — ${formatNumber(v.viewCount)} views, ${formatNumber(v.commentCount)} comments`;
                html += ` (${formatRatio(v.ratio)})`;
                html += `</li>`;
            }
            html += `</ul></details>`;
        }

        // Closest matches
        if (Array.isArray(ch.closestMatches) && ch.closestMatches.length > 0) {
            html += `<div class="closest-matches"><h4>Closest Matches</h4><ul>`;
            for (const v of ch.closestMatches) {
                html += `<li class="match-item">`;
                html += `<a href="${escapeHtml(v.url)}" target="_blank">${escapeHtml(v.title)}</a>`;
                html += `<span class="match-stats">`;
                html += `${formatNumber(v.viewCount)} views · ${formatNumber(v.commentCount)} comments`;
                html += ` · ratio ${formatRatio(v.ratio)}`;
                html += `</span>`;
                html += `</li>`;
            }
            html += `</ul></div>`;
        }

        html += `</div>`;
        return html;
    }

    // ---- Message listener ----

    chrome.runtime.onMessage.addListener((message) => {
        if (message?.__fromBackgroundRelay) {
            if (message.action === 'channelScanProgress') {
                handleProgress(message);
            } else if (message.action === 'channelScanComplete') {
                handleComplete(message);
            }
        }
    });

    // ---- Init ----

    scanBtn.addEventListener('click', startScan);
    loadSavedInputs();
})();
