/**
 * YouTube Niche Filter - Popup Script
 * Handles niche selection, brain settings, and communication with content script
 */

// ============================================
// DOM Elements
// ============================================
const nicheSelect = document.getElementById('niche-select');
const keywordInput = document.getElementById('keyword-input');
const scanBtn = document.getElementById('scan-btn');
const saveBtn = document.getElementById('save-btn');
const statusSection = document.getElementById('status-section');
const statusMessage = document.getElementById('status-message');
const resultsSection = document.getElementById('results-section');
const resultsList = document.getElementById('results-list');
const controlNote = document.querySelector('.control-note');

// Brain/Settings elements
const settingsToggle = document.getElementById('settings-toggle');
const killSwitchBtn = document.getElementById('kill-switch');
const settingsPanel = document.getElementById('settings-panel');
const brainStatus = document.getElementById('brain-status');
const brainToggle = document.getElementById('brain-toggle');
const apiKeyInput = document.getElementById('api-key');
const targetCyclesInput = document.getElementById('target-cycles');
const humanToggle = document.getElementById('human-toggle');
const humanIntensitySelect = document.getElementById('human-intensity');
const testBrainBtn = document.getElementById('test-brain-btn');
const signalYouTube = document.getElementById('signal-youtube');
const signalYouTubeValue = document.getElementById('signal-youtube-value');
const signalAutomation = document.getElementById('signal-automation');
const signalAutomationValue = document.getElementById('signal-automation-value');
const signalBrain = document.getElementById('signal-brain');
const signalBrainValue = document.getElementById('signal-brain-value');

// Stats elements
const toggleStatsBtn = document.getElementById('toggle-stats-btn');
const statsContent = document.getElementById('stats-content');
const resetStatsBtn = document.getElementById('reset-stats-btn');
const statVideos = document.getElementById('stat-videos');
const statWatchTime = document.getElementById('stat-watch-time');
const statLikes = document.getElementById('stat-likes');
const statComments = document.getElementById('stat-comments');
const statShares = document.getElementById('stat-shares');
const statSubscribes = document.getElementById('stat-subscribes');
const statSessions = document.getElementById('stat-sessions');

// Activity log and timer elements
const activityLog = document.getElementById('activity-log');
const clearLogBtn = document.getElementById('clear-log-btn');
const timersSection = document.getElementById('timers-section');
const timerReturnValue = document.getElementById('timer-return-value');
const timerSessionValue = document.getElementById('timer-session-value');
const timerReturnItem = document.getElementById('timer-return');
const timerSessionItem = document.getElementById('timer-session');

// Modal elements
const customCategoryModal = document.getElementById('custom-category-modal');
const modalCategoryNameInput = document.getElementById('modal-category-name');
const modalCategoryKeywordsInput = document.getElementById('modal-category-keywords');
const modalCloseBtn = document.getElementById('modal-close');
const modalCancelBtn = document.getElementById('modal-cancel');
const modalAddBtn = document.getElementById('modal-add');

// Timer state
let timerUpdateInterval = null;
let currentTimerState = {
  returnAt: 0,
  sessionEndsAt: 0,
  isActive: false
};

// Log entry tracking for real-time updates
let lastCountdownLogId = null;
let countdownUpdateInterval = null;

// Max log entries to keep
const MAX_LOG_ENTRIES = 100;

const CATEGORY_KEYWORDS = {
  tech: [
    'tech',
    'technology',
    'programming',
    'coding',
    'developer',
    'software',
    'app',
    'web',
    'ai',
    'machine learning',
    'data',
    'cloud',
    'devops',
    'saas',
    'startup'
  ],
  gaming: [
    'gaming',
    'gameplay',
    'stream',
    'streaming',
    'esports',
    'walkthrough',
    'review',
    'speedrun',
    'pc',
    'playstation',
    'xbox',
    'switch',
    'minecraft',
    'fortnite',
    'valorant',
    'roblox'
  ],
  finance: [
    'finance',
    'investing',
    'investment',
    'stocks',
    'stock market',
    'crypto',
    'bitcoin',
    'ethereum',
    'trading',
    'economy',
    'money',
    'budget',
    'wealth',
    'personal finance'
  ],
  fitness: [
    'fitness',
    'workout',
    'exercise',
    'gym',
    'training',
    'nutrition',
    'health',
    'weight loss',
    'cardio',
    'strength',
    'muscle',
    'yoga'
  ],
  business: [
    'business',
    'entrepreneur',
    'entrepreneurship',
    'startup',
    'marketing',
    'sales',
    'ecommerce',
    'strategy',
    'leadership',
    'productivity',
    'growth',
    'management'
  ],
  education: [
    'education',
    'tutorial',
    'how to',
    'learn',
    'course',
    'lesson',
    'guide',
    'explained',
    'tips',
    'training',
    'lecture'
  ],
  entertainment: [
    'entertainment',
    'comedy',
    'movie',
    'tv',
    'show',
    'reaction',
    'vlog',
    'trailer',
    'celebrity',
    'challenge',
    'prank'
  ],
  music: [
    'music',
    'song',
    'album',
    'lyrics',
    'cover',
    'live',
    'concert',
    'mix',
    'playlist',
    'instrumental',
    'producer',
    'beat'
  ]
};

// Automation state
let automationEnabled = true;
let isOnYouTube = true;
let activeScanId = null;
let activeScanStartedAt = 0;
let lastSelectedCategoryValue = '';
let currentActiveTab = null;

const BOOTSTRAP_STORAGE_KEYS = [
  'automationEnabled',
  'selectedCategory',
  'keywordInput',
  'selectedNiche',
  'customKeywords',
  'useBrain',
  'brainApiKey',
  'customCategories',
  'targetCycles',
  'humanMode',
  'humanIntensity'
];

// ============================================
// Initialization
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  void initializePopup();
});

async function initializePopup() {
  keywordInput.disabled = true;
  brainToggle.checked = true;
  brainToggle.disabled = true;
  updateBrainStatus();
  updateSettingsToggleState();
  syncStatsToggleButton();
  startTimerUpdates();

  const [storageResult, activeTabResult] = await Promise.allSettled([
    chrome.storage.local.get(BOOTSTRAP_STORAGE_KEYS),
    getActiveTab()
  ]);

  const bootstrapData = storageResult.status === 'fulfilled' ? storageResult.value : {};
  const bootstrapTab = activeTabResult.status === 'fulfilled' ? activeTabResult.value : null;

  await loadAutomationState(bootstrapData);
  await loadCustomCategories(bootstrapData);
  await loadSettings(bootstrapData);
  await checkYouTubeTab(bootstrapTab);

  lastSelectedCategoryValue = nicheSelect.value;
  updateScanButtonState();

  window.requestAnimationFrame(() => {
    document.body.classList.add('is-ready');
    setTimeout(() => {
      void Promise.allSettled([
        loadStats(),
        requestCurrentState(bootstrapTab)
      ]);
    }, 0);
  });
}

async function getActiveTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return setCurrentActiveTab(tab || null);
  } catch (error) {
    console.error('Error getting active tab:', error);
    return null;
  }
}

function setCurrentActiveTab(tab) {
  currentActiveTab = tab?.id ? tab : null;
  return currentActiveTab;
}

async function resolveActiveTab(tab = null) {
  if (tab?.id) {
    return setCurrentActiveTab(tab);
  }

  if (currentActiveTab?.id) {
    return currentActiveTab;
  }

  return getActiveTab();
}

chrome.runtime.onMessage.addListener((message) => {
  if (!message) return;
  
  if (message.action === 'scanProgress') {
    handleScanProgress(message);
    return;
  }
  
  if (message.action === 'activityLog') {
    addLogEntry(message.text, message.type || 'info');
    return;
  }
  
  if (message.action === 'timerUpdate') {
    updateTimerState(message);
    return;
  }
});

// ============================================
// Event Listeners
// ============================================

// Category selection change
nicheSelect.addEventListener('change', (e) => {
  const nextValue = e.target.value;

  if (nextValue === '__add_manually__') {
    e.target.value = lastSelectedCategoryValue;
    showCustomCategoryModal();
  } else {
    lastSelectedCategoryValue = nextValue;
    updateScanButtonState();
  }
});

// Keyword input
keywordInput.addEventListener('input', updateScanButtonState);

// Save settings button
saveBtn.addEventListener('click', saveSettings);

// Scan feed button
scanBtn.addEventListener('click', scanFeed);

// Settings toggle
settingsToggle.addEventListener('click', () => {
  settingsPanel.classList.toggle('hidden');
  updateSettingsToggleState();
});

// Emergency stop toggle
killSwitchBtn.addEventListener('click', async () => {
  try {
    if (automationEnabled) {
      await setAutomationEnabled(false);
      await broadcastStopToYouTubeTabs();
      showStatus('🛑', 'Automation stopped', 'success');
    } else {
      await setAutomationEnabled(true);
      showStatus('✅', 'Automation enabled', 'success');
    }
  } catch (error) {
    console.error('Error toggling automation:', error);
    showStatus('❌', 'Failed to toggle automation', 'error');
  }
});

// Brain toggle
brainToggle.addEventListener('change', () => {
  updateBrainStatus();
});

// Human behavior toggle + pace
humanToggle.addEventListener('change', () => {
  void chrome.storage.local.set({ humanMode: humanToggle.checked });
});

humanIntensitySelect.addEventListener('change', () => {
  const value = Number(humanIntensitySelect.value);
  void chrome.storage.local.set({ humanIntensity: Number.isFinite(value) ? value : 1 });
});

// Test brain button
testBrainBtn.addEventListener('click', testBrain);

// Clear activity log
clearLogBtn.addEventListener('click', () => {
  activityLog.innerHTML = '';
  addLogEntry('Log cleared', 'info');
});

// API key change - save on blur
apiKeyInput.addEventListener('blur', async () => {
  const value = apiKeyInput.value.trim();
  if (!value) return;

  if (!value.startsWith('nvapi-') && !value.startsWith('freellmapi-')) {
    showStatus('⚠️', 'Use a freellmapi- or nvapi- key', 'warning');
    return;
  }

  try {
    await chrome.runtime.sendMessage({
      action: 'setBrainApiKey',
      apiKey: value
    });
  } catch (error) {
    console.error('Error saving API key:', error);
  }
});

// Cycles per session - save on change
targetCyclesInput.addEventListener('change', () => {
  const value = clampTargetCycles(targetCyclesInput.value);
  targetCyclesInput.value = String(value);
  void chrome.storage.local.set({ targetCycles: value });
});

// Modal event listeners
modalCloseBtn.addEventListener('click', hideCustomCategoryModal);
modalCancelBtn.addEventListener('click', hideCustomCategoryModal);
modalAddBtn.addEventListener('click', addCustomCategoryFromModal);

// Close modal on background click
customCategoryModal.addEventListener('click', (e) => {
  if (e.target === customCategoryModal) {
    hideCustomCategoryModal();
  }
});

// Enter key to add category in modal
modalCategoryNameInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    addCustomCategoryFromModal();
  }
});

modalCategoryKeywordsInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    addCustomCategoryFromModal();
  }
});

// Escape key to close modal
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !customCategoryModal.classList.contains('hidden')) {
    hideCustomCategoryModal();
  }
});

// ============================================
// Functions
// ============================================

/**
 * Cycles per session: at least 2, at most 10.
 */
function clampTargetCycles(value) {
  const num = Math.floor(Number(value));
  if (!Number.isFinite(num)) return 2;
  return Math.max(2, Math.min(10, num));
}

/**
 * Load saved settings from Chrome storage
 */
async function loadSettings(bootstrapData = null) {
  try {
    const result = bootstrapData || await chrome.storage.local.get([
      'selectedCategory',
      'keywordInput',
      'selectedNiche',
      'customKeywords',
      'useBrain',
      'brainApiKey',
      'targetCycles',
      'humanMode',
      'humanIntensity'
    ]);

    const savedCategory = result.selectedCategory || result.selectedNiche || '';
    nicheSelect.value = savedCategory;
    lastSelectedCategoryValue = savedCategory;

    keywordInput.value = '';

    // Brain settings
    brainToggle.checked = true;
    if (result.brainApiKey && (result.brainApiKey.startsWith('nvapi-') || result.brainApiKey.startsWith('freellmapi-'))) {
      apiKeyInput.value = result.brainApiKey;
    } else {
      apiKeyInput.value = '';
    }

    if (result.useBrain === false) {
      void chrome.storage.local.set({ useBrain: true });
    }

    targetCyclesInput.value = String(clampTargetCycles(result.targetCycles));

    humanToggle.checked = result.humanMode !== false;
    const intensity = Number(result.humanIntensity);
    humanIntensitySelect.value = String([0.6, 1, 1.5, 1.9].includes(intensity) ? intensity : 1);

    updateScanButtonState();
  } catch (error) {
    console.error('Error loading settings:', error);
  }
}

/**
 * Load automation enabled/disabled state
 */
async function loadAutomationState(bootstrapData = null) {
  try {
    const result = bootstrapData || await chrome.storage.local.get(['automationEnabled']);
    automationEnabled = result.automationEnabled !== false;
    updateAutomationUI();
  } catch (error) {
    console.error('Error loading automation state:', error);
  }
}

async function setAutomationEnabled(enabled) {
  automationEnabled = enabled === true;
  await chrome.storage.local.set({ automationEnabled: automationEnabled });
  updateAutomationUI();
  updateScanButtonState();
}

function updateAutomationUI() {
  if (automationEnabled) {
    killSwitchBtn.classList.add('strobe');
    killSwitchBtn.classList.remove('is-disabled');
    killSwitchBtn.textContent = 'STOP';
    killSwitchBtn.title = 'Emergency Stop';
  } else {
    killSwitchBtn.classList.remove('strobe');
    killSwitchBtn.classList.add('is-disabled');
    killSwitchBtn.textContent = 'OFF';
    killSwitchBtn.title = 'Automation disabled (click to enable)';
  }

  updateOverviewSignals();
}

function setSignalState(signalEl, valueEl, state, text) {
  if (signalEl) {
    signalEl.dataset.state = state;
  }

  if (valueEl) {
    valueEl.textContent = text;
  }
}

function updateOverviewSignals() {
  setSignalState(
    signalYouTube,
    signalYouTubeValue,
    isOnYouTube ? 'ready' : 'warning',
    isOnYouTube ? 'YouTube ready' : 'Open YouTube'
  );

  setSignalState(
    signalAutomation,
    signalAutomationValue,
    automationEnabled ? 'ready' : 'muted',
    automationEnabled ? 'Armed' : 'Paused'
  );

  setSignalState(
    signalBrain,
    signalBrainValue,
    brainToggle.checked ? 'ready' : 'muted',
    brainToggle.checked ? 'AI + Keywords' : 'Off'
  );
}

function updateSettingsToggleState() {
  settingsToggle.classList.toggle('is-active', !settingsPanel.classList.contains('hidden'));
}

function syncStatsToggleButton() {
  const isExpanded = !statsContent.classList.contains('hidden');
  toggleStatsBtn.textContent = isExpanded ? '▲' : '▼';
  toggleStatsBtn.setAttribute('aria-expanded', String(isExpanded));
}

function getButtonTextElement(button) {
  return button?.querySelector('.btn-text') || button;
}

function setButtonText(button, text) {
  const target = getButtonTextElement(button);
  if (target) {
    target.textContent = text;
  }
}

function getSelectedCategoryLabel() {
  const selectedOption = nicheSelect.options[nicheSelect.selectedIndex];
  return selectedOption?.textContent?.trim() || 'Select a category';
}

function getScanButtonLabel() {
  const hasCategory = nicheSelect.value.trim().length > 0;

  if (!hasCategory) return 'Choose Category';
  if (!isOnYouTube) return 'Open YouTube';
  if (!automationEnabled) return 'Automation Off';

  const label = getSelectedCategoryLabel();
  return label.length > 22 ? `${label.slice(0, 22).trim()}...` : `Scan ${label}`;
}

function updateControlNote() {
  if (!controlNote) return;

  const hasCategory = nicheSelect.value.trim().length > 0;

  if (!hasCategory) {
    controlNote.textContent = 'Pick a category first. The assistant will use it as the primary routing signal.';
    return;
  }

  if (!isOnYouTube) {
    controlNote.textContent = 'Open the YouTube home feed in the active tab before launching a scan.';
    return;
  }

  if (!automationEnabled) {
    controlNote.textContent = 'Automation is paused. Turn it back on to allow new scans.';
    return;
  }

  controlNote.textContent = `Ready to scan ${getSelectedCategoryLabel()} and jump into the first strong match.`;
}

/**
 * Save settings to Chrome storage
 */
async function saveSettings() {
  try {
    const settings = {
      selectedCategory: nicheSelect.value,
      keywordInput: '',
      useBrain: true,
      humanMode: humanToggle.checked,
      humanIntensity: Number(humanIntensitySelect.value) || 1
    };

    // Save API key separately if provided
    if (apiKeyInput.value.trim()) {
      await chrome.runtime.sendMessage({
        action: 'setBrainApiKey',
        apiKey: apiKeyInput.value.trim()
      });
    }

    await chrome.storage.local.set(settings);
    showStatus('✅', 'Settings saved!', 'success');

    setTimeout(() => {
      statusSection.classList.add('hidden');
    }, 2000);
  } catch (error) {
    console.error('Error saving settings:', error);
    showStatus('❌', 'Failed to save settings', 'error');
  }
}

/**
 * Update brain status indicator
 */
function updateBrainStatus() {
  const isActive = brainToggle.checked;

  if (isActive) {
    brainStatus.classList.remove('inactive');
    brainStatus.querySelector('.brain-text').textContent = brainToggle.disabled
      ? 'AI Brain Active (NVIDIA, keyword fallback)'
      : 'AI Brain Active';
  } else {
    brainStatus.classList.add('inactive');
    brainStatus.querySelector('.brain-text').textContent = 'AI Brain Off';
  }

  updateOverviewSignals();
}

/**
 * Test brain connection
 */
async function testBrain() {
  testBrainBtn.disabled = true;
  testBrainBtn.classList.add('loading');
  setButtonText(testBrainBtn, 'Testing Connection');

  try {
    const response = await chrome.runtime.sendMessage({ action: 'brainTest' });

    if (response.success && response.keywordMode) {
      showStatus('ℹ️', 'No API key: running in keyword mode (no AI needed)', 'success');
    } else if (response.success) {
      showStatus('✅', `Brain connected (${response.model || 'AI'})`, 'success');
    } else {
      showStatus('❌', `Brain test failed: ${response.error}`, 'error');
    }
  } catch (error) {
    showStatus('❌', `Connection error: ${error.message}`, 'error');
  } finally {
    testBrainBtn.disabled = false;
    testBrainBtn.classList.remove('loading');
    setButtonText(testBrainBtn, 'Test Brain Connection');
  }
}

/**
 * Update scan button enabled/disabled state
 */
function updateScanButtonState() {
  const hasCategory = nicheSelect.value.trim().length > 0;
  scanBtn.disabled = !automationEnabled || !isOnYouTube || !hasCategory;

  if (!scanBtn.classList.contains('loading')) {
    setButtonText(scanBtn, getScanButtonLabel());
  }

  updateControlNote();
  updateOverviewSignals();
}

/**
 * Check if current tab is YouTube
 */
async function checkYouTubeTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    isOnYouTube = Boolean(tab?.url?.includes('youtube.com'));

    if (!isOnYouTube) {
      showStatus('⚠️', 'Please navigate to YouTube first', 'warning');
    }

    updateScanButtonState();
  } catch (error) {
    console.error('Error checking tab:', error);
  }
}

async function broadcastStopToYouTubeTabs() {
  try {
    const tabs = await chrome.tabs.query({
      url: ['*://www.youtube.com/*', '*://youtube.com/*', '*://*.youtube.com/*']
    });

    await Promise.all(
      (tabs || [])
        .filter(t => t?.id)
        .map(t => chrome.tabs.sendMessage(t.id, { action: 'stopAutomation', permanent: true }))
    );
  } catch (error) {
    // Ignore if some tabs don't have a content script yet.
    console.warn('Stop broadcast warning:', error);
  }
}

/**
 * Get keywords for the selected niche
 */
async function getKeywords(categoryValue) {
  const key = typeof categoryValue === 'string' ? categoryValue.trim() : '';
  if (!key) return [];

  // Check if it's a custom category
  if (key.startsWith('custom_')) {
    try {
      const result = await chrome.storage.local.get(['customCategories']);
      const customCategories = result.customCategories || [];
      const customCat = customCategories.find(cat => cat.id === key);
      if (customCat && Array.isArray(customCat.keywords) && customCat.keywords.length > 0) {
        return customCat.keywords.slice();
      }
      // Fallback to category name if no keywords
      return customCat ? [customCat.name.toLowerCase()] : [key];
    } catch (error) {
      console.error('Error loading custom category keywords:', error);
      return [key];
    }
  }

  // Default categories
  const keyLower = key.toLowerCase();
  const mapped = CATEGORY_KEYWORDS[keyLower];
  if (Array.isArray(mapped) && mapped.length > 0) {
    return mapped.slice();
  }

  return [key];
}

/**
 * Scan the YouTube feed for matching videos
 */
async function scanFeed() {
  const categoryValue = nicheSelect.value;
  const keywords = await getKeywords(categoryValue);
  const useBrainEnabled = true;
  const categoryLabel = nicheSelect.options[nicheSelect.selectedIndex]?.textContent || categoryValue;

  if (!categoryValue) {
    showStatus('⚠️', 'Please select a category', 'warning');
    return;
  }

  if (keywords.length === 0) {
    showStatus('⚠️', 'No keywords available for this category', 'warning');
    return;
  }

  const scanText = useBrainEnabled ? `AI analyzing ${categoryLabel}...` : 'Scanning feed...';
  showStatus('🧠', escapeHtml(scanText), 'loading');
  scanBtn.classList.add('loading');
  scanBtn.disabled = true;
  setButtonText(scanBtn, 'Scanning...');
  resultsSection.classList.add('hidden');
  activeScanId = createScanId();
  activeScanStartedAt = Date.now();

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.id) {
      throw new Error('No active tab found');
    }

    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'scanFeed',
      scanId: activeScanId,
      keywords: keywords,
      category: categoryValue,
      useBrainOverride: useBrainEnabled,
      // As soon as a single match is found, open it.
      autoOpen: true,
      // Run full cycles: home feed -> top channels -> Shorts.
      autoCycle: true,
      cycleMinMs: 60_000,
      cycleMaxMs: 120_000,

      // Session controls
      targetCycles: clampTargetCycles(targetCyclesInput.value),

      // Comment automation
      commentAssist: true,
      maxCommentsPerSession: 9999,
      commentCooldownMinMs: 8 * 60_000,
      commentCooldownMaxMs: 15 * 60_000
    });

    if (response.success) {
      if (response.opened && response.openedVideo?.url) {
        showStatus('▶️', 'Opened a matching video', 'success');
        return;
      }

      if (response.matches && response.matches.length > 0) {
        displayResults(response.matches, response.usedBrain);
        showStatus('✅', `Found ${response.matches.length} video(s)!`, 'success');
      } else {
        showStatus('😕', 'No matching videos found', 'warning');
      }
    } else {
      throw new Error(response.error || 'Unknown error');
    }
  } catch (error) {
    console.error('Error scanning feed:', error);

    if (error.message?.includes('Receiving end does not exist')) {
      showStatus('⚠️', 'Please refresh the YouTube page first', 'warning');
    } else {
      showStatus('❌', error.message || 'Failed to scan feed', 'error');
    }
  } finally {
    scanBtn.classList.remove('loading');
    updateScanButtonState();
    activeScanId = null;
    activeScanStartedAt = 0;
  }
}

function createScanId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function handleScanProgress(message) {
  if (!activeScanId || message.scanId !== activeScanId) return;

  const stage = message.stage || 'analyzing';
  const scanned = Number.isFinite(message.scanned) ? message.scanned : null;
  const title = typeof message.title === 'string' ? message.title.trim() : '';

  if (stage === 'start') {
    const label = message.category ? `AI analyzing ${message.category}...` : 'AI analyzing feed...';
    showStatus('🧠', escapeHtml(label), 'loading');
    return;
  }

  if (stage === 'analyzing') {
    const countText = scanned ? `Analyzing video ${scanned}` : 'Analyzing video';
    const titleText = title ? `: ${title}` : '';
    showStatus('🔍', escapeHtml(`${countText}${titleText}`), 'loading');
    return;
  }

  if (stage === 'opening') {
    const label = title ? `Opening: ${title}` : 'Opening matching video';
    showStatus('▶️', escapeHtml(label), 'success');
    return;
  }

  if (stage === 'watching') {
    const label = title ? `Watching: ${title}` : 'Watching video';
    showStatus('⏱️', escapeHtml(label), 'loading');
    return;
  }

  if (stage === 'returning') {
    showStatus('↩️', 'Returning to home feed', 'loading');
    return;
  }

  if (stage === 'complete') {
    if (message.opened) {
      showStatus('✅', 'Match found and opened', 'success');
      return;
    }
    const found = Number.isFinite(message.matches) ? message.matches : 0;
    const label = found > 0 ? `Found ${found} video(s)` : 'No matching videos found';
    showStatus(found > 0 ? '✅' : '😕', escapeHtml(label), found > 0 ? 'success' : 'warning');
    return;
  }

  if (stage === 'error') {
    const errorText = message.error ? String(message.error) : 'Scan failed';
    showStatus('❌', escapeHtml(errorText), 'error');
    return;
  }

  if (stage === 'stopped') {
    const reason = message.error ? String(message.error) : 'Automation stopped';
    showStatus('🛑', escapeHtml(reason), 'warning');
  }
}

/**
 * Display matching video results
 */
function displayResults(matches, usedBrain) {
  resultsList.innerHTML = '';

  matches.forEach((video, index) => {
    const item = document.createElement('div');
    item.className = 'result-item';

    const brainBadge = video.brainAnalyzed ? '<span class="brain-badge">AI</span>' : '';
    const scoreDisplay = video.score ? `<span class="score-badge">${video.score}%</span>` : '';

    item.innerHTML = `
      <div class="result-header">
        ${brainBadge}
        ${scoreDisplay}
      </div>
      <div class="result-title">${escapeHtml(video.title)}</div>
      <div class="result-channel">${escapeHtml(video.channel || 'Unknown channel')}</div>
    `;

    item.addEventListener('click', async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.tabs.sendMessage(tab.id, {
          action: 'openVideo',
          url: video.url
        });
        window.close();
      } catch (error) {
        console.error('Error opening video:', error);
      }
    });

    resultsList.appendChild(item);
  });

  resultsSection.classList.remove('hidden');
}

/**
 * Show status message
 */
function showStatus(icon, text, type = 'info') {
  statusMessage.innerHTML = `
    <span class="status-icon">${icon}</span>
    <span class="status-text">${text}</span>
  `;
  statusMessage.className = `status-message status-${type}`;
  statusSection.dataset.state = type;
  statusSection.classList.remove('hidden');
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ============================================
// Stats Functions
// ============================================

// Toggle stats panel visibility
toggleStatsBtn.addEventListener('click', () => {
  statsContent.classList.toggle('hidden');
  syncStatsToggleButton();
});

// Reset stats
resetStatsBtn.addEventListener('click', async () => {
  if (!confirm('Reset all stats? This cannot be undone.')) return;
  
  try {
    await chrome.runtime.sendMessage({ action: 'resetStats' });
    await loadStats();
    showStatus('✅', 'Stats reset', 'success');
  } catch (error) {
    console.error('Error resetting stats:', error);
    showStatus('❌', 'Failed to reset stats', 'error');
  }
});

/**
 * Load and display stats
 */
async function loadStats() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getStats' });
    
    if (!response?.success || !response.stats) {
      console.warn('Failed to load stats');
      return;
    }
    
    const stats = response.stats;
    
    // Update stat values
    statVideos.textContent = formatNumber(stats.totalVideosWatched);
    statWatchTime.textContent = formatWatchTime(stats.totalWatchTimeSeconds);
    statLikes.textContent = formatNumber(stats.totalLikes);
    statComments.textContent = formatNumber(stats.totalComments);
    statShares.textContent = formatNumber(stats.totalShares);
    statSubscribes.textContent = formatNumber(stats.totalSubscribes);
    statSessions.textContent = `${stats.totalSessions} session${stats.totalSessions === 1 ? '' : 's'}`;
    
  } catch (error) {
    console.error('Error loading stats:', error);
  }
}

/**
 * Format number for display (with K/M suffix for large numbers)
 */
function formatNumber(num) {
  if (!num || !Number.isFinite(num)) return '0';
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
}

/**
 * Format watch time in hours and minutes
 */
function formatWatchTime(seconds) {
  if (!seconds || !Number.isFinite(seconds) || seconds <= 0) return '0m';
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  return `${minutes}m`;
}

// ============================================
// Activity Log Functions
// ============================================

/**
 * Add entry to activity log
 */
function addLogEntry(text, type = 'info', entryId = null) {
  const timestamp = getTimestamp();
  
  // If entryId is provided, try to update existing entry
  if (entryId) {
    const existingEntry = document.getElementById(`log-${entryId}`);
    if (existingEntry) {
      existingEntry.textContent = `[${timestamp}] ${text}`;
      existingEntry.className = `log-entry log-${type}`;
      activityLog.scrollTop = activityLog.scrollHeight;
      return entryId;
    }
  }
  
  // Create new entry
  const entry = document.createElement('div');
  entry.className = `log-entry log-${type}`;
  entry.textContent = `[${timestamp}] ${text}`;
  
  if (entryId) {
    entry.id = `log-${entryId}`;
  }
  
  activityLog.appendChild(entry);
  
  // Remove old entries if too many
  while (activityLog.children.length > MAX_LOG_ENTRIES) {
    activityLog.removeChild(activityLog.firstChild);
  }
  
  // Auto-scroll to bottom
  activityLog.scrollTop = activityLog.scrollHeight;
  
  return entryId;
}

/**
 * Get current timestamp string
 */
function getTimestamp() {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  return `${hours}:${minutes}:${seconds}`;
}

/**
 * Update handleScanProgress to also log to activity
 */
const originalHandleScanProgress = handleScanProgress;
handleScanProgress = function(message) {
  // Log to activity terminal
  logScanProgress(message);
  // Original handling
  originalHandleScanProgress.call(this, message);
};

function logScanProgress(message) {
  const stage = message.stage || '';
  const title = message.title ? truncateText(message.title, 40) : '';
  
  switch (stage) {
    case 'start':
      addLogEntry(`Scanning feed for: ${message.category || 'videos'}...`, 'action');
      break;
    case 'analyzing': {
      const count = message.scanned || '';
      addLogEntry(`Analyzing video ${count}${title ? ': ' + title : ''}`, 'brain');
      break;
    }
    case 'opening':
      addLogEntry(`Opening: ${title || 'matching video'}`, 'success');
      break;
    case 'watching':
      addLogEntry(`Watching: ${title || 'video'}`, 'watch');
      break;
    case 'returning':
      addLogEntry('Returning to home feed...', 'action');
      break;
    case 'complete':
      if (message.opened) {
        addLogEntry('Match found and opened!', 'success');
      } else {
        const found = message.matches || 0;
        addLogEntry(found > 0 ? `Found ${found} video(s)` : 'No matches found', found > 0 ? 'success' : 'info');
      }
      break;
    case 'error':
      addLogEntry(`Error: ${message.error || 'Unknown error'}`, 'error');
      break;
    case 'stopped':
      addLogEntry(`Stopped: ${message.error || 'Automation stopped'}`, 'error');
      break;
  }
}

function truncateText(text, maxLength) {
  if (!text || text.length <= maxLength) return text;
  return text.slice(0, maxLength - 3) + '...';
}

// ============================================
// Countdown Log Updates
// ============================================

/**
 * Start a countdown log entry that updates in real-time
 */
function startCountdownLog(message, targetTime, type = 'timer') {
  // Clear any existing countdown
  stopCountdownLog();
  
  // Generate unique ID
  lastCountdownLogId = `countdown-${Date.now()}`;
  
  // Update function
  const updateCountdown = () => {
    const now = Date.now();
    const remaining = Math.max(0, targetTime - now);
    
    if (remaining <= 0) {
      stopCountdownLog();
      return;
    }
    
    const seconds = Math.ceil(remaining / 1000);
    const countdownText = `${message} in ${seconds}s`;
    
    addLogEntry(countdownText, type, lastCountdownLogId);
  };
  
  // Initial update
  updateCountdown();
  
  // Update every second
  countdownUpdateInterval = setInterval(updateCountdown, 1000);
}

/**
 * Stop the countdown log updates
 */
function stopCountdownLog() {
  if (countdownUpdateInterval) {
    clearInterval(countdownUpdateInterval);
    countdownUpdateInterval = null;
  }
  lastCountdownLogId = null;
}

// ============================================
// Timer Functions
// ============================================

/**
 * Update timer state from content script
 */
function updateTimerState(message) {
  currentTimerState = {
    returnAt: message.returnAt || 0,
    sessionEndsAt: message.sessionEndsAt || 0,
    isActive: message.isActive === true
  };
  
  if (currentTimerState.isActive) {
    timersSection.classList.remove('hidden');
    
    // Start countdown log if we have a return time
    if (currentTimerState.returnAt > Date.now()) {
      startCountdownLog('Returning to home feed', currentTimerState.returnAt, 'timer');
    }
  } else {
    timersSection.classList.add('hidden');
    stopCountdownLog();
  }
  
  updateTimerDisplay();
}

/**
 * Start periodic timer updates
 */
function startTimerUpdates() {
  if (timerUpdateInterval) {
    clearInterval(timerUpdateInterval);
  }
  
  timerUpdateInterval = setInterval(() => {
    updateTimerDisplay();
  }, 1000);
}

/**
 * Update timer display values
 */
function updateTimerDisplay() {
  const now = Date.now();
  
  // Return home timer
  if (currentTimerState.returnAt > 0) {
    const remaining = Math.max(0, currentTimerState.returnAt - now);
    timerReturnValue.textContent = formatCountdown(remaining);
    
    // Add urgent class if under 30 seconds
    if (remaining > 0 && remaining < 30000) {
      timerReturnItem.classList.add('timer-urgent');
    } else {
      timerReturnItem.classList.remove('timer-urgent');
    }
  } else {
    timerReturnValue.textContent = '--:--';
    timerReturnItem.classList.remove('timer-urgent');
  }
  
  // Session end timer
  if (currentTimerState.sessionEndsAt > 0) {
    const remaining = Math.max(0, currentTimerState.sessionEndsAt - now);
    timerSessionValue.textContent = formatCountdown(remaining);
    
    // Add urgent class if under 5 minutes
    if (remaining > 0 && remaining < 300000) {
      timerSessionItem.classList.add('timer-urgent');
    } else {
      timerSessionItem.classList.remove('timer-urgent');
    }
  } else {
    timerSessionValue.textContent = '--:--';
    timerSessionItem.classList.remove('timer-urgent');
  }
}

/**
 * Format countdown in MM:SS or HH:MM:SS
 */
function formatCountdown(ms) {
  if (!ms || ms <= 0) return '0:00';
  
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  
  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

/**
 * Request current state from content script
 */
async function requestCurrentState() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !tab.url?.includes('youtube.com')) return;
    
    const response = await chrome.tabs.sendMessage(tab.id, { action: 'getTimerState' });
    if (response) {
      updateTimerState(response);
      
      // Also log current status
      if (response.isActive && response.stage) {
        addLogEntry(`Currently: ${response.stage}`, 'info');
      }
    }
  } catch (error) {
    // Content script not ready yet, ignore
  }
}

// ============================================
// Custom Category Management
// ============================================

/**
 * Show the custom category modal
 */
function showCustomCategoryModal() {
  modalCategoryNameInput.value = '';
  modalCategoryKeywordsInput.value = '';
  customCategoryModal.classList.remove('hidden');
  setTimeout(() => modalCategoryNameInput.focus(), 100);
}

/**
 * Hide the custom category modal
 */
function hideCustomCategoryModal() {
  customCategoryModal.classList.add('hidden');
}

/**
 * Load custom categories from storage and populate dropdown
 */
async function loadCustomCategories() {
  try {
    const result = await chrome.storage.local.get(['customCategories']);
    const customCategories = result.customCategories || [];
    
    // Update dropdown with custom categories
    updateCategoryDropdown(customCategories);
  } catch (error) {
    console.error('Error loading custom categories:', error);
  }
}

/**
 * Update the category dropdown to include custom categories
 */
function updateCategoryDropdown(customCategories) {
  // Get current selection
  const currentValue = nicheSelect.value;
  
  // Find the "Add manually" option
  const addManuallyOption = nicheSelect.querySelector('option[value="__add_manually__"]');
  
  // Remove all custom category options (but keep default ones and "Add manually")
  const customOptions = nicheSelect.querySelectorAll('option[data-custom="true"]');
  customOptions.forEach(opt => opt.remove());
  
  // Add custom categories before "Add manually"
  if (customCategories.length > 0) {
    const fragment = document.createDocumentFragment();
    
    // Add separator
    const separator = document.createElement('option');
    separator.disabled = true;
    separator.textContent = '──────────';
    separator.dataset.custom = 'true';
    fragment.appendChild(separator);
    
    // Add custom categories
    customCategories.forEach(cat => {
      const option = document.createElement('option');
      option.value = cat.id;
      option.textContent = `🏷️ ${cat.name}`;
      option.dataset.custom = 'true';
      fragment.appendChild(option);
    });
    
    // Insert before "Add manually" option
    nicheSelect.insertBefore(fragment, addManuallyOption);
  }
  
  // Restore selection if still valid
  if (currentValue && currentValue !== '__add_manually__') {
    const stillExists = Array.from(nicheSelect.options).some(opt => opt.value === currentValue);
    if (stillExists) {
      nicheSelect.value = currentValue;
      lastSelectedCategoryValue = currentValue;
    }
  }
}

/**
 * Add a custom category from modal
 */
async function addCustomCategoryFromModal() {
  const name = modalCategoryNameInput.value.trim();
  const keywordsText = modalCategoryKeywordsInput.value.trim();
  
  if (!name) {
    showStatus('⚠️', 'Please enter a category name', 'warning');
    modalCategoryNameInput.focus();
    return;
  }
  
  // Generate category ID (lowercase, no spaces)
  const id = `custom_${name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
  
  // Parse keywords (comma-separated)
  let keywords = [];
  if (keywordsText) {
    keywords = keywordsText
      .split(',')
      .map(k => k.trim())
      .filter(k => k.length > 0);
  } else {
    // AI will generate keywords based on category name
    keywords = await generateKeywordsForCategory(name);
  }
  
  try {
    // Get existing custom categories
    const result = await chrome.storage.local.get(['customCategories']);
    const customCategories = result.customCategories || [];
    
    // Check if category already exists
    const exists = customCategories.some(cat => cat.id === id || cat.name.toLowerCase() === name.toLowerCase());
    if (exists) {
      showStatus('⚠️', 'Category already exists', 'warning');
      modalCategoryNameInput.focus();
      return;
    }
    
    // Add new category
    const newCategory = {
      id,
      name,
      keywords
    };
    
    customCategories.push(newCategory);
    
    // Save to storage
    await chrome.storage.local.set({ customCategories });
    
    // Update UI
    updateCategoryDropdown(customCategories);
    
    // Hide modal
    hideCustomCategoryModal();
    
    // Select the new category
    nicheSelect.value = id;
    lastSelectedCategoryValue = id;
    updateScanButtonState();
    
    showStatus('✅', `Category "${name}" added!`, 'success');
    setTimeout(() => statusSection.classList.add('hidden'), 2000);
  } catch (error) {
    console.error('Error adding custom category:', error);
    showStatus('❌', 'Failed to add category', 'error');
  }
}

/**
 * Generate keywords locally so adding custom categories stays instant.
 */
async function generateKeywordsForCategory(categoryName) {
  const cleaned = String(categoryName || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s/&-]+/g, ' ')
    .replace(/[/-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleaned) {
    return [];
  }

  const parts = cleaned.split(' ').filter(word => word.length > 2);
  const keywords = new Set([cleaned]);

  parts.forEach(word => keywords.add(word));

  if (parts.length >= 2) {
    keywords.add(parts.slice(0, 2).join(' '));
    keywords.add(parts.slice(-2).join(' '));
  }

  return Array.from(keywords).slice(0, 8);
}
