# Custom Categories Feature

## Overview
The YouTube AI Assistant now supports **custom categories**, allowing you to target any niche beyond the default categories.

## How to Use

### Adding a Custom Category

1. **Open the Extension Popup**
   - Click the extension icon in Chrome

2. **Open Settings**
   - Click the ⚙️ (Settings) button in the header

3. **Scroll to "Custom Categories" Section**
   - You'll see input fields for:
     - **Category Name** (Required)
     - **Keywords** (Optional)

4. **Enter Category Information**
   - **Category Name**: Enter a descriptive name (e.g., "Cooking", "Travel", "Cars")
   - **Keywords**: Optionally add comma-separated keywords (e.g., "recipe, chef, food, cooking")
     - If left empty, the AI will automatically work with just the category name

5. **Click "➕ Add Category"**
   - The category will appear in the dropdown with a 🏷️ icon
   - It will also appear in the list below for management

### Using a Custom Category

1. **Select from Dropdown**
   - Custom categories appear at the bottom of the dropdown
   - They have a 🏷️ icon prefix for easy identification

2. **Scan Feed**
   - Click "Scan Feed" as normal
   - The AI will analyze videos based on your custom category

### Deleting a Custom Category

1. **Open Settings**
2. **Scroll to Custom Categories List**
3. **Click 🗑️ (Delete)** next to the category you want to remove
4. **Confirm deletion**

## How It Works

### With Keywords
If you provide keywords, the AI uses them as hints to better understand what videos match your category.

**Example:**
- Category: "Gardening"
- Keywords: "plants, flowers, garden, grow, seeds, soil"

### Without Keywords
If you don't provide keywords, the AI analyzes videos based purely on the category name. The AI is smart enough to understand context!

**Example:**
- Category: "Woodworking"
- Keywords: (empty)
- AI will automatically understand videos about woodworking, carpentry, etc.

## Technical Details

### Storage
- Custom categories are stored in `chrome.storage.local`
- They persist across browser sessions
- Each category has:
  - **ID**: Auto-generated (e.g., `custom_cooking`)
  - **Name**: Display name
  - **Keywords**: Array of keyword strings

### AI Integration
- Custom categories work identically to default categories
- The Brain (Kimi K2.5) analyzes video titles using the category context
- Keywords are passed as hints to improve accuracy

### Category Format
The AI receives custom categories in this format:
```
Category: "Cooking (keywords: recipe, chef, food, cooking)"
```

Or without keywords:
```
Category: "Travel"
```

## Examples

### Custom Category Ideas

1. **Niche Hobbies**
   - Amateur Radio
   - Model Trains
   - Coin Collecting
   - Calligraphy

2. **Specific Interests**
   - Vintage Cars
   - Mechanical Keyboards
   - Coffee Brewing
   - Urban Photography

3. **Learning Topics**
   - Spanish Language
   - Quantum Physics
   - Piano Lessons
   - Photography Tips

4. **Professional Fields**
   - Real Estate
   - Interior Design
   - Digital Marketing
   - 3D Printing

## Limitations

- Category names must be unique
- Maximum of 100 custom categories (recommended)
- Keywords are comma-separated strings
- Category IDs are auto-generated and cannot be changed

## Tips for Best Results

1. **Use Specific Names**
   - ✅ "Italian Cooking" instead of "Food"
   - ✅ "DSLR Photography" instead of "Cameras"

2. **Add Relevant Keywords**
   - Include variations and related terms
   - Include common abbreviations
   - Include technical terms if applicable

3. **Test and Refine**
   - Try scanning with your category
   - If results aren't good, add more specific keywords
   - Delete and recreate if needed

## Troubleshooting

**Category not appearing in dropdown?**
- Refresh the popup by closing and reopening it
- Check if it appears in the custom categories list

**Not finding matching videos?**
- Try adding more keywords
- Make sure keywords are relevant to YouTube content
- Check if there are actually videos in that niche on YouTube

**Category name already exists?**
- Each category must have a unique name
- Delete the old one first, or use a slightly different name
